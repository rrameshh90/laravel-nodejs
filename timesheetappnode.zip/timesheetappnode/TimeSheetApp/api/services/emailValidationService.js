var validate = require('validator');

var emailExistence = require('email-existence');
var Promise = require("bluebird");



module.exports = {


validateEmailAddress:function(options){


return new Promise(function(resolve,reject){
       try{
      if(validate.isEmail(options.email)){
        

        emailExistence.check(options.email,function(err,responds){


            if(!err){
                     resolve({
                          statusCode:200,statusInfo:{
                              message:'sucess',
                              info:{}
                          },result:responds
                     });
            }
            else{
                reject({statusCode:500,statusInfo:{message:'faild',nfo:err},result:{}});
            }
        });


      }else{
        resolve({statusCode:400,statusInfo:{message:'invalid mail id',info:{email:email}},result:{}});
      }
    }catch(err){
        reject({statusCode:500,statusInfo:{message:'faild',nfo:err},result:{}});
    }


});

}




};