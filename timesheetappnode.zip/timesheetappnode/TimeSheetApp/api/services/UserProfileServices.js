function softDeleteHelper(obj, isDelete) {

    return new Promise(function (resolve, reject) {
        obj.isDeleted = isDelete;

        obj.save(function (err) {
            if (err) {
                reject(err);
            }
            resolve(obj);
        });
    });

}

module.exports = {

    isValidUser: function (options) {
        return new Promise(function (resolve, reject) {
            try {
                UserProfile.findOne({ email: options.email, isDeleted: false }).then(function (result) {

                    if (!_.isUndefined(result)) {
                        if (result.role == 3) {
                            Associate.findOne({ profileId: result.id }).then(function (resultAssociate) {
                                if (!_.isUndefined(resultAssociate)) {
                                    result.associateId = resultAssociate.id;
                                    resolve({ StatusCode: 200, StatusInfo: { message: 'sucess', info: {} }, result: result });
                                } else {
                                    resolve({ StatusCode: 400, StatusInfo: { message: 'data itegrity problem!!!', info: {} }, result: result });

                                }

                            }).catch(function (errAssociate) {
                                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                            });
                        } else {
                            resolve({ StatusCode: 200, StatusInfo: { message: 'sucess', info: {} }, result: result });
                        }

                    } else {
                        resolve({ StatusCode: 400, StatusInfo: { message: 'user is not regitsterd with this app ask management to register!!!', info: {} }, result: result });
                    }
                }).catch(function (err) {
                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                });
            } catch (err) {
                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
            }
        });
    },
    isAdmin: function (options) {
        return new Promise(function (resolve, reject) {
            try {
                console.log(options)
                UserProfile.findOne({ email: options.email, isDeleted: false }).then(function (result) {


                    if (!_.isUndefined(result)) {
                        if (result.role == '1') {

                            resolve({ StatusCode: 200, StatusInfo: { message: 'sucess', info: {} }, result: result });
                        }
                        else {
                            resolve({ StatusCode: 401, StatusInfo: { message: 'user is not not admin', info: {} }, result: result });
                        }
                    } else {
                        resolve({ StatusCode: 404, StatusInfo: { message: 'user is not regitsterd with this app ask management to register!!!', info: {} }, result: result });
                    }
                }).catch(function (err) {
                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                });
            } catch (err) {

                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
            }
        });

    },
    isAdminById: function (options) {
        return new Promise(function (resolve, reject) {
            try {
                console.log(options)
                UserProfile.findOne({ id: options.id, isDeleted: false }).then(function (result) {


                    if (!_.isUndefined(result)) {
                        if (result.role == '1') {

                            resolve({ StatusCode: 200, StatusInfo: { message: 'sucess', info: {} }, result: result });
                        }
                        else {
                            resolve({ StatusCode: 401, StatusInfo: { message: 'user is not not admin', info: {} }, result: result });
                        }
                    } else {
                        resolve({ StatusCode: 404, StatusInfo: { message: 'user is not regitsterd with this app ask management to register!!!', info: {} }, result: result });
                    }
                }).catch(function (err) {
                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                });
            } catch (err) {

                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
            }
        });

    },
    isManager: function (options) {
        return new Promise(function (resolve, reject) {
            try {

                console.log('inside ismanager service');
                sails.log.info(options);
                UserProfile.findOne({ id: options.id, isDeleted: false }).then(function (result) {

                    console.log('>>>isManager>>UserProfile.finsOne.then');
                    sails.log.info('>>>>>>>>> is manager findone result  ' + result);
                    if (!_.isUndefined(result)) {
                        if (result.role == '2') {
                            resolve({ StatusCode: 200, StatusInfo: { message: 'sucess', info: {} }, result: result });
                        }
                        else {
                            resolve({ StatusCode: 401, StatusInfo: { message: 'user is not a manager', info: {} }, result: result });
                        }
                    } else {
                        console.log('inside ismanager service is result undefind else');
                        resolve({ StatusCode: 404, StatusInfo: { message: 'user is not regitsterd with this app ask management to register!!!', info: {} }, result: {} });
                    }
                }).catch(function (err) {
                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                });
            } catch (err) {
                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
            }
        });

    },
    createUserProfile: function (options) {
        return new Promise(async function (resolve, reject) {
            try {

                var profile = await UserProfile.findOne({ email: options.email });
                if (!_.isUndefined(profile)) {

                    if (profile.isDeleted) {

                        resolve({
                            StatusCode: 400, StatusInfo: {
                                message: 'user is already present but deleted , please restore with the same email id',
                                info: options,
                            }, result: {}
                        });

                    } else {
                        resolve({
                            StatusCode: 400, StatusInfo: {
                                message: 'there is already one active user with this mail id',
                                info: options,
                            }, result: {}
                        });
                    }

                } else {

                    UserProfile.create(options).then(function (result) {

                        if (result.role == '1') {
                            //create Management

                            Management.create({ profileId: result.id, Managers: [] }).then(function (result2) {
                                resolve({ StatusCode: 201, StatusInfo: { message: 'sucess', info: {} }, result: result });
                            }).catch(function (err) {
                                UserProfile.distroy({ id: result.id }).then(function (result) {
                                    if (err.status == 400 || err.error == 'E_VALIDATION') {
                                        resolve({
                                            StatusCode: 400, StatusInfo: {
                                                message: err.toString(),
                                                info: err.invalidAttributes,
                                            }, result: {}
                                        });
                                    }
                                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                                }).catch(function (err1) {
                                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err.furterError = err1s }, result: {} });
                                });

                            });
                        }
                        if (result.role == '2') {
                            //create Manager
                            Manager.create({ profileId: result.id, Projects: [], teams: [] }).then(function (result2) {
                                resolve({ StatusCode: 201, StatusInfo: { message: 'sucess', info: {} }, result: result });
                            }).catch(function (err) {
                                UserProfile.distroy({ id: result.id }).then(function (result) {
                                    if (err.status == 400 || err.error == 'E_VALIDATION') {
                                        resolve({
                                            StatusCode: 400, StatusInfo: {
                                                message: err.toString(),
                                                info: err.invalidAttributes,
                                            }, result: {}
                                        });
                                    }
                                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                                }).catch(function (err1) {
                                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err.furterError = err1s }, result: {} });
                                });
                            });
                        }
                        if (result.role == '3') {
                            //create associate
                            Associate.create({ profileId: result.id, Projects: [], teams: [], tasks: [] }).then(function (result2) {
                                resolve({ StatusCode: 201, StatusInfo: { message: 'sucess', info: {} }, result: result });
                            }).catch(function (err) {
                                UserProfile.distroy({ id: result.id }).then(function (result) {
                                    if (err.status == 400 || err.error == 'E_VALIDATION') {
                                        resolve({
                                            StatusCode: 400, StatusInfo: {
                                                message: err.toString(),
                                                info: err.invalidAttributes,
                                            }, result: {}
                                        });
                                    }
                                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                                }).catch(function (err1) {
                                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err.furterError = err1s }, result: {} });
                                });
                            });
                        }


                    }).catch(function (err) {
                        if (err.status == 400 || err.error == 'E_VALIDATION') {
                            console.log(err);
                            resolve({
                                StatusCode: 400, StatusInfo: {

                                    message: err.toString(),
                                    info: err.invalidAttributes,
                                }, result: {}
                            });
                        }
                        reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                    });
                }
            } catch (err) {
                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
            }
        });
    },

    getUserDetailsByProfileId: function (options) {

        return new Promise(function (resolve, reject) {
            try {
                UserProfile.findOne({ id: options.id }).then(function (result) {


                    resolve({ StatusCode: 200, StatusInfo: { message: 'sucess', info: {} }, result: result });

                }).catch(function (err) {
                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                });

            } catch (err) {
                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
            }

        });
    },

    getAssociates: function () {

        return new Promise(async function (resolve, reject) {


            try {

                        var profile = await UserProfile.find({role:3,isDeleted:false});

                Associate.find({ isDeleted: false }).populate('profileId').then(function (result) {

                    resolve({ StatusCode: 200, StatusInfo: { message: 'sucess', info: {} }, result: result });

                }).catch(function (err) {
                    reject({ StatusCode: 500, StatusInfo: { message: err.toString(), info: err }, result: {} });
                });

            } catch (err) {
                reject({ StatusCode: 500, StatusInfo: { message: err.toString(), info: err }, result: {} });
            }



        });

    },
    getManager: function (options) {
        return new Promise(function (resolve, reject) {
            try {
                Manager.find({ id: options.id, isDeleted: false }).populate('Projects').then(function (result) {
                    resolve({ StatusCode: 200, StatusInfo: { message: 'sucess', info: {} }, result: result });
                }).catch(function (err) {
                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                });
            } catch (err) {
                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
            }
        });
    },
    getAllEmployess: function () {



        return new Promise(function (resolve, reject) {
            try {

                UserProfile.find({ isDeleted: false }).then(function (result) {

                    resolve({
                        StatusCode: 200,
                        StatusInfo: {
                            message: 'sucess',
                            info: {}
                        },
                        result: result
                    });

                }).catch(function (err) {

                    reject({
                        StatusCode: 500,
                        StatusInfo: {
                            message: 'faild',
                            info: err
                        },
                        result: {}
                    });

                });

            } catch (err) {
                reject({ StatusCode: 500, StatusInfo: { message: 'faild', info: err }, result: {} });
            }
        });
    },
    getAssociateById: function (options) {
        return new Promise( async function (resolve, reject) {
            try {

               var resultAssociate = await Associate.findOne({ profileId: options.loggedInUserId, isDeleted: false }).populate('tasks',{where:{isTicket:false}}).populate('Projects').populate('profileId');

                    if (!_.isUndefined(resultAssociate)) {

                        resolve({

                            StatusCode: 200,
                            StatusInfo: {

                                message: 'sucess',
                                info: {}
                            },
                            result: resultAssociate

                        });
                    } else {
                        resolve({

                            StatusCode: 404,
                            StatusInfo: {

                                message: 'no such associate',
                                info: options
                            },
                            result: {}

                        });
                    }
             




            } catch (err) {
                reject({ StatusCode: 500, StatusInfo: { message: 'faild', info: err }, result: {} });
            }


        });
    },
    getProfileDetailsWithProfileId: function (options) {


        return new Promise(function (resolve, reject) {
            console.log('hdhdhdhdhd');
            try {
                sails.log.debug('>>>>>>>>>>>>>>>>>>options  ' + JSON.stringify(options));
                UserProfile.findOne({ select: ['id', 'name', 'email', 'designation'] }).where({ id: options.profileId, isDeleted: false }).then(function (result) {

                    if (!_.isUndefined(result)) {
                        resolve({ StatusCode: 200, StatusInfo: { message: 'sucess', info: {} }, result: result });
                    } else {
                        resolve({ StatusCode: 400, StatusInfo: { message: 'user is not regitsterd with this app ask management to register!!!', info: {} }, result: result });
                    }
                }).catch(function (err) {
                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                });
            } catch (err) {
                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
            }

        });

    },

    editUserDetails: async function (options) {

        try {
            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                },


            };


            var result = await UserProfile.update({ id: options.profileIdToEdit, isDeleted: false }).set({
                name: options.name,
                email: options.email,
                designation: options.designation
            });

            responds.StatusCode = 200;
            responds.StatusInfo.message = 'sucess';

            responds.result = result;
            return responds

        } catch (err) {
            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            };
            return responds;
        }




    },
    softDeletUser: async function (options) {

        try {

            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                }

            };

            var profile = await UserProfile.findOne({ id: options.profileIdToDelete });

            if (!_.isUndefined(profile)) {

                if (!profile.isDeleted) {

                    switch (profile.role) {

                        case 1:
                            await UserProfile.update({ id: profile.id }).set({ isDeleted: true });
                            try {

                                await Management.update({ profileId: profile.id }).set({ isDeleted: true });

                                var associate = await Associate.findOne({ profileId: profile.id, isDeleted:false});
                                var manager =await Associate.findOne({ profileId: profile.id,isDeleted:false });
                                if(!_.isUndefined(associate)){
                                    await Associate.update({ profileId: profile.id }).set({ isDeleted: true });
                                }
                                responds.StatusCode = 200;
                                responds.StatusInfo.message = 'sucess';

                                return responds

                            } catch (e) {

                                try {
                                    await UserProfile.update({ id: profile.id }).set({ isDeleted: false });
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'faild';
                                    responds.StatusInfo.info = e;


                                } catch (er) {
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'in consistend data added in database while deleting user';
                                    responds.StatusInfo.info = er;


                                }


                            }

                            break;
                        case 2:

                            await UserProfile.update({ id: profile.id }).set({ isDeleted: true });
                            try {

                                await Manager.update({ profileId: profile.id }).set({ isDeleted: true });
                                responds.StatusCode = 200;
                                responds.StatusInfo.message = 'sucess';


                            } catch (e) {

                                try {
                                    await UserProfile.update({ id: profile.id }).set({ isDeleted: false });
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'faild';
                                    responds.StatusInfo.info = e;


                                } catch (er) {
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'in consistend data added in database while deleting user';
                                    responds.StatusInfo.info = er;


                                }


                            }

                            break;

                        case 3:

                            await UserProfile.update({ id: profile.id }).set({ isDeleted: true });
                            try {

                                await Associate.update({ profileId: profile.id }).set({ isDeleted: true });
                                responds.StatusCode = 200;
                                responds.StatusInfo.message = 'sucess';



                            } catch (e) {

                                try {
                                    await UserProfile.update({ id: profile.id }).set({ isDeleted: false });
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'faild';
                                    responds.StatusInfo.info = e;


                                } catch (er) {
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'in consistend data added in database while deleting user';
                                    responds.StatusInfo.info = er;


                                }


                            }

                            break;



                        default:
                            responds.StatusCode = 400;
                            responds.StatusInfo.message = 'some problem with user role';
                            responds.StatusInfo.info = options;

                    }
                    return responds
                } else {

                    responds.StatusCode = 400;
                    responds.StatusInfo.message = 'profile is already deleted';
                    responds.StatusInfo.info = options;
                    return responds

                }

            } else {
                responds.StatusCode = 400;
                responds.StatusInfo.message = 'there is no user with provided profile id';
                responds.StatusInfo.info = options;
                return responds
            }

        } catch (err) {
            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            };
            return responds;
        }

    },

    restoreUser: async function (options) {

        try {

            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                }

            };

            var profile = await UserProfile.findOne({ email: options.profileEmailToReStore });

            if (!_.isUndefined(profile)) {

                if (profile.isDeleted) {

                    switch (profile.role) {

                        case 1:
                            await UserProfile.update({ id: profile.id }).set({ isDeleted: false });
                            try {

                                await Management.update({ profileId: profile.id }).set({ isDeleted: false });
                                responds.StatusCode = 200;
                                responds.StatusInfo.message = 'sucess';



                            } catch (e) {

                                try {
                                    await UserProfile.update({ id: profile.id }).set({ isDeleted: true });
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'faild';
                                    responds.StatusInfo.info = e;


                                } catch (er) {
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'in consistent data added in database while restoring user';
                                    responds.StatusInfo.info = er;


                                }


                            }

                            break;
                        case 2:

                            await UserProfile.update({ id: profile.id }).set({ isDeleted: false });
                            try {

                                await Manager.update({ profileId: profile.id }).set({ isDeleted: false });
                                responds.StatusCode = 200;
                                responds.StatusInfo.message = 'sucess';



                            } catch (e) {

                                try {
                                    await UserProfile.update({ id: profile.id }).set({ isDeleted: true });
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'faild';
                                    responds.StatusInfo.info = e;


                                } catch (er) {
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'in consistend data added in database while restoring user';
                                    responds.StatusInfo.info = er;


                                }


                            }

                            break;

                        case 3:

                            await UserProfile.update({ id: profile.id }).set({ isDeleted: false });
                            try {

                                await Associate.update({ profileId: profile.id }).set({ isDeleted: false });
                                responds.StatusCode = 200;
                                responds.StatusInfo.message = 'sucess';



                            } catch (e) {

                                try {
                                    await UserProfile.update({ id: profile.id }).set({ isDeleted: true });
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'faild';
                                    responds.StatusInfo.info = e;


                                } catch (er) {
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'in consistend data added in database while restoring user';
                                    responds.StatusInfo.info = er;


                                }


                            }

                            break;



                        default:
                            responds.StatusCode = 400;
                            responds.StatusInfo.message = 'some problem with user role';
                            responds.StatusInfo.info = options;

                    }
                    return responds
                } else {

                    responds.StatusCode = 400;
                    responds.StatusInfo.message = 'profile is already active';
                    responds.StatusInfo.info = options;
                    return responds

                }

            } else {
                responds.StatusCode = 400;
                responds.StatusInfo.message = 'there is no user with provided profile id';
                responds.StatusInfo.info = options;
                return responds
            }

        } catch (err) {
            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            };
            return responds;
        }


    },

    isAssociateByid: function (options) {
        return new Promise(function (resolve, reject) {
            try {

                Associate.findOne({ profileId: options.id, isDeleted: false }).then(function (resultAssociate) {

                    if (!_.isUndefined(resultAssociate)) {
                        resolve({ StatusCode: 200, StatusInfo: { message: 'sucess', info: {} }, result: resultAssociate });
                    }
                    else {
                        resolve({ StatusCode: 400, StatusInfo: { message: 'logged in user is not associate', info: options }, result: {} });
                    }
                }).catch(function (errAssociate) {
                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: errAssociate }, result: {} });
                });

            } catch (err) {
                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
            }
        });
    },

    getManagerDetailsByManagerId: async function (options) {
        try {

            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                },
                result: {}

            };


            var manager = await Manager.findOne({ id: options.managerId, isDeleted: false }).populate('profileId');

            if (!_.isUndefined(manger)) {

                responds.StatusCode = 200;
                responds.StatusInfo.message = 'sucess';
                responds.result = manger;
                return responds

            } else {
                responds.StatusCode = 400;
                responds.StatusInfo.message = 'there is no user with this id';
                responds.StatusInfo.info = options;
                return responds
            }
        } catch (err) {
            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            };
            return responds;
        }
    },

    editRole: async function (options) {


        try {

            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                },
                result: {}

            };

            var profile = await UserProfile.findOne({ email: options.email });
            if (!_.isUndefined(profile)) {

                if (profile.id == options.loggedInUserId) {
                    responds.StatusCode = 400;
                    responds.StatusInfo.message = 'you cant change your role yourself';
                    responds.StatusInfo.info = options;
                    return responds
                }

                switch (profile.role) {
                    case 1:

                        var management = await Management.findOne({ profileId: profile.id });
                        if (!_.isUndefined(management)) {

                            if (profile.role == options.role) {
                                responds.StatusCode = 400;
                                responds.StatusInfo.message = 'same role';
                                responds.StatusInfo.info = options;
                                return responds
                            }

                            await UserProfile.update({ id: profile.id }).set({ role: options.role });

                            try {

                                switch (options.role) {
                                    case '2':
                                        var entrycheck = await Manager.findOne({ profileId: profile.id });
                                        if (_.isUndefined(entrycheck)) {
                                            await Manager.create({ profileId: profile.id });
                                            responds.StatusCode = 200;
                                            responds.StatusInfo.message = 'changed the role from managemnt to Manager';
                                            responds.StatusInfo.info = options;
                                            responds.result = profile;
                                            return responds
                                        }

                                        responds.StatusInfo.message = 'changed the role from managemnt to Manager';
                                        responds.StatusInfo.info = options;
                                        responds.result = profile;
                                        return responds
                                        break;


                                    case '3':
                                        var entrycheck = await Associate.findOne({ profileId: profile.id });
                                        if (_.isUndefined(entrycheck)) {
                                            await Associate.create({ profileId: profile.id });
                                            responds.StatusCode = 200;
                                            responds.StatusInfo.message = 'changed the role from managemnt to Associate';
                                            responds.StatusInfo.info = options;
                                            responds.result = profile;
                                            return responds
                                        }
                                        responds.StatusCode = 200;
                                        responds.StatusInfo.message = 'changed the role from managemnt to Associate';
                                        responds.StatusInfo.info = options;
                                        responds.result = profile;
                                        return responds
                                        break;
                                    default:
                                        try {

                                            await UserProfile.update({ id: profile.id }).set({ role: profile.role });
                                            responds.StatusCode = 400;
                                            responds.StatusInfo.message = 'wrong role';
                                            responds.StatusInfo.info = options;
                                            return responds
                                        } catch (er) {
                                            responds.StatusCode = 500;
                                            responds.StatusInfo.message = 'the user role is changed incorrectly';
                                            responds.StatusInfo.info = er;
                                            return responds
                                        }
                                }

                            } catch (e) {
                                try {
                                    await UserProfile.update({ id: profile.id }).set({ role: profile.role });
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'faild';
                                    responds.StatusInfo.info = e;
                                    return responds
                                } catch (e3) {

                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'faild: there is wrong update in the database';
                                    responds.StatusInfo.info = e3;
                                    return responds

                                }


                            }


                        } else {

                            responds.StatusCode = 400;
                            responds.StatusInfo.message = 'user is not createed in proper way, consult the application admin';
                            responds.StatusInfo.info = options;
                            return responds

                        }

                        break;
                    case 2:

                        var manager =await Manager.findOne({ profileId: profile.id });
                        if (!_.isUndefined(manager)) {

                               

                            if (profile.role == options.role) {
                                responds.StatusCode = 400;
                                responds.StatusInfo.message = 'same role';
                                responds.StatusInfo.info = options;
                                return responds
                            }
                            var canChange = true

                            var projects = await Project.find({manager:manager.id});
                            var timesheets = await TimeSheetEntries.find({approvelManager:manager.id, isApproved:false});
                            if(!_.isUndefined(projects) && _.isArray(projects) && projects.length){

                                for(var project of projects){
                                    if(project.state == 1 || project.state ==2 || project.state == 3 ){
                                        canChange = false;
                                    
                                    }
                                }

                            }
                            if(!_.isUndefined(timesheets) && _.isArray(timesheets) && projects.timesheets){
                                
                                canChange = false;
                               

                            }

                                 if(canChange){
                            await UserProfile.update({ id: profile.id }).set({ role: options.role });

                            try {

                                switch (options.role) {
                                    case '1':

                                    
                                        
                                        var entrycheck = await Management.findOne({ profileId: profile.id });
                                        if(_.isUndefined(entrycheck)){

                                            await Management.create({ profileId: profile.id });
                                            responds.StatusCode = 200;
                                            responds.StatusInfo.message = 'changed the role from Manager  to managemnt  ';
                                            responds.StatusInfo.info = options;
                                            responds.result = profile;
                                            return responds

                                        }

                                        responds.StatusCode = 200;
                                        responds.StatusInfo.message = 'changed the role from Manager  to managemnt  ';
                                        responds.StatusInfo.info = options;
                                        responds.result = profile;
                                        return responds

                                        break;


                                    case '3':
                                    var entrycheck = await Associate.findOne({ profileId: profile.id });
                                    if(_.isUndefined(entrycheck)){
                                        await Associate.create({ profileId: profile.id });
                                        responds.StatusCode = 200;
                                        responds.StatusInfo.message = 'changed the role from managemnt to Associate';
                                        responds.StatusInfo.info = options;
                                        responds.result = profile;
                                        return responds
                                    }
                                        
                                        responds.StatusCode = 200;
                                        responds.StatusInfo.message = 'changed the role from managemnt to Associate';
                                        responds.StatusInfo.info = options;
                                        responds.result = profile;
                                        return responds
                                        break;
                                    default:
                                        try {

                                            await UserProfile.update({ id: profile.id }).set({ role: profile.role });
                                            responds.StatusCode = 400;
                                            responds.StatusInfo.message = 'wrong role';
                                            responds.StatusInfo.info = options;
                                            return responds
                                        } catch (er) {
                                            responds.StatusCode = 500;
                                            responds.StatusInfo.message = 'the user role is changed wrongly';
                                            responds.StatusInfo.info = er;
                                            return responds
                                        }
                                }

                            } catch (e) {
                                try {
                                    await UserProfile.update({ id: profile.id }).set({ role: profile.role });
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'faild';
                                    responds.StatusInfo.info = e;
                                    return responds
                                } 
                                catch (e3) {

                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'faild: there is wrong update in the database';
                                    responds.StatusInfo.info = e3;
                                    return responds

                                }


                            }
                        }else{
                            
                            responds.StatusCode = 400;
                            responds.StatusInfo.message = 'cant change role of this manager';
                            responds.StatusInfo.info = options;
                            return responds
                        }


                        } else {

                            responds.StatusCode = 400;
                            responds.StatusInfo.message = 'user is not createed in proper way, consult the application admin';
                            responds.StatusInfo.info = options;
                            return responds

                        }

                        break;
                    case 3:

                        var associate = await Associate.findOne({ profileId: profile.id });
                        if (!_.isUndefined(associate)) {

                            if (profile.role == options.role) {
                                responds.StatusCode = 400;
                                responds.StatusInfo.message = 'same role';
                                responds.StatusInfo.info = options;
                                return responds
                            }

                            await UserProfile.update({ id: profile.id }).set({ role: options.role });

                            try {

                                switch (options.role) {
                                    case '1':
                                    var entrycheck = await Management.findOne({ profileId: profile.id });
                                    if(_.isUndefined(entrycheck)){

                                        await Management.create({ profileId: profile.id });
                                        responds.StatusCode = 200;
                                        responds.StatusInfo.message = 'changed the role from Manager  to managemnt  ';
                                        responds.StatusInfo.info = options;
                                        responds.result = profile;
                                        return responds


                                    }
                                        
                                        responds.StatusCode = 200;
                                        responds.StatusInfo.message = 'changed the role from Manager  to managemnt  ';
                                        responds.StatusInfo.info = options;
                                        responds.result = profile;
                                        return responds

                                        break;


                                    case '2':
                                    var entrycheck = await Manager.findOne({ profileId: profile.id });
                                    if(_.isUndefined(entrycheck)){
                                        await Manager.create({ profileId: profile.id });
                                        responds.StatusCode = 200;
                                        responds.StatusInfo.message = 'changed the role from managemnt to Associate';
                                        responds.StatusInfo.info = options;
                                        responds.result = profile;
                                        return responds
                                    }
                                    responds.StatusCode = 200;
                                    responds.StatusInfo.message = 'changed the role from managemnt to Associate';
                                    responds.StatusInfo.info = options;
                                    responds.result = profile;
                                    return responds
                                        break;
                                    default:
                                        try {

                                            await UserProfile.update({ id: profile.id }).set({ role: profile.role });
                                            responds.StatusCode = 400;
                                            responds.StatusInfo.message = 'wrong role';
                                            responds.StatusInfo.info = options;
                                            return responds
                                        } catch (er) {
                                            responds.StatusCode = 500;
                                            responds.StatusInfo.message = 'the user role is changed wrongly';
                                            responds.StatusInfo.info = er;
                                            return responds
                                        }
                                }

                            } catch (e) {
                                try {
                                    await UserProfile.update({ id: profile.id }).set({ role: profile.role });
                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'faild';
                                    responds.StatusInfo.info = e;
                                    return responds
                                } catch (e3) {

                                    responds.StatusCode = 500;
                                    responds.StatusInfo.message = 'faild: there is wrong update in the database';
                                    responds.StatusInfo.info = e3;
                                    return responds

                                }


                            }


                        } else {

                            responds.StatusCode = 400;
                            responds.StatusInfo.message = 'user is not createed in proper way, consult the application admin';
                            responds.StatusInfo.info = options;
                            return responds

                        }
                        break;
                    default:
                        responds.StatusCode = 400;
                        responds.StatusInfo.message = 'problem with user role entry';
                        responds.StatusInfo.info = options;
                        return responds

                }

            } else {

                responds.StatusCode = 400;
                responds.StatusInfo.message = 'there is no user with this email';
                responds.StatusInfo.info = options;
                return responds
            }



        } catch (err) {
            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            };
            return responds;
        }
    }

};