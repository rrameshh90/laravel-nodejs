
var dateHandler = require('date-fns');
var isBefore = require('date-fns/is_before');
var isValid = require('date-fns/is_valid');
var isEqual = require('date-fns/is_equal');
var isAfter = require('date-fns/is_after');
var Format = require('date-fns/format');
var isToday = require('date-fns/is_today');
var isThisMonth = require('date-fns/is_this_month');


function saveRecords(record) {

    return new Promise(function (resolve, reject) {

        if (!_.isUndefined(record)) {

            record.save(function (err) {
                if (err) {
                    reject(err);
                } else {
                    resolve(record);
                }
            })

        } else {
            reject({ error: 'records is not defind for save' });
        }

    });
}


function checkArray(array, keyVal) {
    return new Promise(function (resolve, reject) {
        try {

            var obj = {};

            for (var i = 0; i < array.length; i++) {
                if (array[i] == keyVal) {
                    
                    obj = array[i];
                    resolve(obj)
                }
            }
            
            resolve();
        } catch (err) {
            reject(err);
        }

    });
}
function checkArryForId(array, keyVal) {
    console.log('>>>>>>>>>in side checkArryForId function');
    return new Promise(function (resolve, reject) {
        console.log('>>>>>>>>>in side checkArryForId function promise');

        checkArray(array, keyVal).then(function (obj) {

           
                   
            if (!_.isUndefined(obj)) {

               
                resolve({ status: true });


            } else {
                reject({ status: false });


            }
        }).catch(function (err) {


            reject({ status: true,error:err });

        });








    });
}

function getIdListFromObjectArray2(objetArray) {
    //sails.log.debug('>>>>>>>>>>[getIdListFromObjectArray]----->>(parameter):'+JSON.stringify(objetArray));


    return new Promise(function (resolve,reject) {

        try {
            var responds = _.map(objetArray, 'id');
            sails.log.debug('>>>>>>>>>>[getIdListFromObjectArray2]----->>(responds):'+JSON.stringify(responds));
           // throw (responds);
            resolve(responds);
            
        } catch (err) {
            sails.log.debug('>>>>>>>>>>[getIdListFromObjectArray2]----->>(err):'+JSON.stringify(err));
            reject(err);
        }
    });
}

function getIdListFromObjectArray(objetArray) {
    //sails.log.debug('>>>>>>>>>>[getIdListFromObjectArray]----->>(parameter):'+JSON.stringify(objetArray));


    return new Promise(function (resolve,reject) {

        try {
            var responds = _.map(objetArray, 'id');
            sails.log.debug('>>>>>>>>>>[getIdListFromObjectArray]----->>(responds):'+JSON.stringify(responds));
           // throw (responds);
            resolve(responds);
            
        } catch (err) {
            sails.log.debug('>>>>>>>>>>[getIdListFromObjectArray]----->>(err):'+JSON.stringify(err));
            reject(err);
        }
    });
}
var validateDateForTimeSheetEntry =  function (options) {

    return new Promise(function (resolve, reject) {

        try {
                    
                var timeSheetEntryDate = new Date(options.dateAndTime);

                var todayString = new Date().toUTCString().split(" ").slice(0, 4).join(" ");

                var today = new Date(todayString);

                        var resulTask = options.tasks;   

                        var taskStartDate = new Date(Format(new Date(resulTask.startDate), 'YYYY-MM-DD'));
                        var taskEndDate = new Date(Format(new Date(resulTask.endDate), 'YYYY-MM-DD'));
                        sails.log.debug('>>>>>>[validateDateForTimeSheetEntry]----->resulTask.startDate:'+Format(new Date(resulTask.startDate), 'YYYY-MM-DD'));
                        sails.log.debug('>>>>>>[validateDateForTimeSheetEntry]----->resulTask.endDate:'+Format(new Date(resulTask.startDate), 'YYYY-MM-DD'));
                        
                sails.log.debug('>>>>>>[validateDateForTimeSheetEntry]----->timeSheetEntryDate:'+timeSheetEntryDate+' ->today:'+today+'->taskStartDate:'+taskStartDate+'->taskEndDate:'+taskEndDate);
                        sails.log.debug('>>>>>>[validateDateForTimeSheetEntry]----->isToday(timeSheetEntryDate):'+isToday(timeSheetEntryDate));
                        sails.log.debug('>>>>>>[validateDateForTimeSheetEntry]----->isAfter(timeSheetEntryDate, taskEndDate):'+isAfter(timeSheetEntryDate, taskEndDate));
                        sails.log.debug('>>>>>>[validateDateForTimeSheetEntry]----->isBefore(timeSheetEntryDate, taskStartDate):'+isBefore(timeSheetEntryDate, taskStartDate));
                        if (isToday(timeSheetEntryDate)) {
                            //time sheet entrers today's date
                            if (!isAfter(timeSheetEntryDate, taskEndDate) && !isBefore(timeSheetEntryDate, taskStartDate)) {
                               
                              //check
                              
                              TimeSheetEntries.find().where({associateId:options.associateId}).then(function(resultSum){
                                
                                if(!_.isUndefined(resultSum) && _.isArray(resultSum) && resultSum.length){
                                    sails.log.debug('>>>>>>[validateDateForTimeSheetEntry]----->there is already timesheet entries for this user: '+ JSON.stringify(resultSum));

                                       var resulSum2 =[];
                                    for(var entry of resultSum){

                                        
                                            var entrytime = new Date(Format(new Date(entry.DateAndTime),'YYYY-MM-DD'))
                                            sails.log.debug('>>>>>>[validateDateForTimeSheetEntry]----->:(isEqual(timeSheetEntryDate,entry.DateAndTime) :'+ timeSheetEntryDate + ' == ' + entrytime + ' :: '+ isEqual(timeSheetEntryDate,entrytime));
                                        if(isEqual(timeSheetEntryDate,entrytime)){
                                            resulSum2.push(entry);
                                        }

                                    }
                                    sails.log.debug('>>>>>>[validateDateForTimeSheetEntry]----->:result sum 2 length :'+ resulSum2.length);
                                    if(resulSum2.length){
                                       
                                    var resultSumHoursArray =_.map(resulSum2,'hours');
                                    var HourSum = 0;
                                    resultSumHoursArray.forEach(function(hr){
                                        HourSum = HourSum + hr;
                                        
    
                                    });
    
                                   
    
                                    if(HourSum <= 24 ){
                                        var hoursDeff = 24 - HourSum;
                                                 if(options.hours <= hoursDeff){
    
                                                    if(resulTask.state == 4 || resulTask.state == 5){
                                                        reject({
                                                            StatusCode: 400,
                                                            StatusInfo: {
                                                                message: 'time sheet can only be enterd for the task that are not closed or deleted',
                                                                info: JSON.stringify(options)
                                                            },
                                                            result: {}
                                                        });
                                                       }
                                                       sails.log.debug('>>>>>>>>>>>>>>>>>>>>>>hors Array :'+JSON.stringify(resultSumHoursArray));
                                                        resolve(options);
    
                                                 }else{
                                                    reject({
                                                        StatusCode: 400,
                                                        StatusInfo: {
                                                            message: 'can not enter more than 24 hours in a day',
                                                            info: JSON.stringify(options)
                                                        },
                                                        result: {}
                                                    });
                                                 }
                                    
    
    
                                              }else{
    
    
                                                
                                    reject({
                                        StatusCode: 400,
                                        StatusInfo: {
                                            message: 'can not enter more than 24 hours in a day',
                                            info: JSON.stringify(options)
                                        },
                                        result: {}
                                    });
    
                                              }
    
                                          }else{

                                            if(options.hours <= 24){

                                    


                                                if(resulTask.state == 4 || resulTask.state == 5){
                                                    reject({
                                                        StatusCode: 400,
                                                        StatusInfo: {
                                                            message: 'time sheet can only be enterd for the task that are not closed or deleted',
                                                            info: JSON.stringify(options)
                                                        },
                                                        result: {}
                                                    });
                                                   }
                                                   
                                                    resolve(options);
                                                }else{
                                                    reject({
                                                        StatusCode: 400,
                                                        StatusInfo: {
                                                            message: 'can not enter more than 24 hours',
                                                            info: JSON.stringify(options)
                                                        },
                                                        result: {}
                                                    });
                                                }



                                          }
    

                                }else{

                                    if(options.hours <= 24){

                                    


                                    if(resulTask.state == 4 || resulTask.state == 5){
                                        reject({
                                            StatusCode: 400,
                                            StatusInfo: {
                                                message: 'time sheet can only be enterd for the task that are not closed or deleted',
                                                info: JSON.stringify(options)
                                            },
                                            result: {}
                                        });
                                       }
                                       
                                        resolve(options);
                                    }else{
                                        reject({
                                            StatusCode: 400,
                                            StatusInfo: {
                                                message: 'can not enter more than 24 hours',
                                                info: JSON.stringify(options)
                                            },
                                            result: {}
                                        });
                                    }
                                }
                               

                              }).catch(function(errSum){

                                reject({
                                    StatusCode: 500,
                                    StatusInfo: {
                                        message: 'faild',
                                        info: JSON.stringify(errSum)
                                    },
                                    result: {}
                                });
                                  

                              });


                            } else {
        
                                reject({
                                    StatusCode: 400,
                                    StatusInfo: {
                                        message: 'date is not between task\'s start date and end date',
                                        info: JSON.stringify(options)
                                    },
                                    result: {}
                                });
        
                            }
        
                        } else {
                            //time sheet enters not today's date
        
                            if (isAfter(timeSheetEntryDate, today)) {
                                //entry date is after today
                                reject({
                                    StatusCode: 400,
                                    StatusInfo: {
                                        message: 'date should not be in future',
                                        info: JSON.stringify(options)
                                    },
                                    result: {}
                                });
                            } else {
                                //entry date is not after today
                                if (isBefore(timeSheetEntryDate, today)) {
                                    //entry date is before today
        
                                    if (!isAfter(timeSheetEntryDate, taskEndDate) && !isBefore(timeSheetEntryDate, taskStartDate)) {

                                        sails.log.debug('>>>>> entry date before today>>>>>>>>>>: '+ JSON.stringify(timeSheetEntryDate));
                                        
                                        TimeSheetEntries.find().where({associateId:options.associateId}).then(function(resultSum){
                                          
                                            if(!_.isUndefined(resultSum) && _.isArray(resultSum) && resultSum.length) {
                                            var resulSum2 =[];
                                            for(var entry of resultSum){
        
                                                
                                                    var entrytime = new Date(Format(new Date(entry.DateAndTime),'YYYY-MM-DD'))
                                                    sails.log.debug('>>>>>>[validateDateForTimeSheetEntry]----->:(isEqual(timeSheetEntryDate,entry.DateAndTime) :'+ timeSheetEntryDate + ' == ' + entrytime + ' :: '+ isEqual(timeSheetEntryDate,entrytime));
                                                if(isEqual(timeSheetEntryDate,entrytime)){
                                                    resulSum2.push(entry);
                                                }
        
                                            }

                                            if(resulSum2.length){
                                            
                                           

                                                var resultSumHoursArray =_.map(resulSum2,'hours');
                                                var HourSum = 0;
                                                resultSumHoursArray.forEach(function(hr){
                                                    HourSum = HourSum + hr;
                                                    
    
                                                });
    
                                               
    
                                                if(HourSum <= 24 ){
                                                    var hoursDeff = 24 - HourSum;
                                                             if(options.hours <= hoursDeff){
    
                                                                if(resulTask.state == 4 || resulTask.state == 5){
                                                                    reject({
                                                                        StatusCode: 400,
                                                                        StatusInfo: {
                                                                            message: 'time sheet can only be enterd for the task that are not closed or deleted',
                                                                            info: JSON.stringify(options)
                                                                        },
                                                                        result: {}
                                                                    });
                                                                   }
                                                                   sails.log.debug('>>>>>>>>>>>>>>>>>>>>>>hors Array :'+JSON.stringify(resultSumHoursArray));
                                                                    resolve(options);
    
                                                             }else{
                                                                reject({
                                                                    StatusCode: 400,
                                                                    StatusInfo: {
                                                                        message: 'can not enter more than 24 hours in a day',
                                                                        info: JSON.stringify(options)
                                                                    },
                                                                    result: {}
                                                                });
                                                             }
                                                
      
                                                }else{
      
      
                                                  
                                      reject({
                                          StatusCode: 400,
                                          StatusInfo: {
                                              message: 'can not enter more than 24 hours in a day',
                                              info: JSON.stringify(options)
                                          },
                                          result: {}
                                      });
      
                                                }
      
                                            }else{


                                                if(options.hours <= 24){
                                                    if(resulTask.state == 4 || resulTask.state == 5){
                                                        reject({
                                                            StatusCode: 400,
                                                            StatusInfo: {
                                                                message: 'time sheet can only be enterd for the task that are not closed or deleted',
                                                                info: JSON.stringify(options)
                                                            },
                                                            result: {}
                                                        });
                                                       }
                                                       
                                                        resolve(options);
                                                    }else{
                                                        reject({
                                                            StatusCode: 400,
                                                            StatusInfo: {
                                                                message: 'can not enter more than 24 hours',
                                                                info: JSON.stringify(options)
                                                            },
                                                            result: {}
                                                        });
                                                    }


                                            }
      
      

                                            }
                                            else{

                                                if(options.hours <= 24){
                                                if(resulTask.state == 4 || resulTask.state == 5){
                                                    reject({
                                                        StatusCode: 400,
                                                        StatusInfo: {
                                                            message: 'time sheet can only be enterd for the task that are not closed or deleted',
                                                            info: JSON.stringify(options)
                                                        },
                                                        result: {}
                                                    });
                                                   }
                                                   
                                                    resolve(options);
                                                }else{
                                                    reject({
                                                        StatusCode: 400,
                                                        StatusInfo: {
                                                            message: 'can not enter more than 24 hours',
                                                            info: JSON.stringify(options)
                                                        },
                                                        result: {}
                                                    });
                                                }
                                            }
                                            
                                           
                                }).catch(function(errSum){
  
                                  reject({
                                      StatusCode: 500,
                                      StatusInfo: {
                                          message: 'faild',
                                          info: JSON.stringify(errSum)
                                      },
                                      result: {}
                                  });
                                    
  
                                });
  
  
                                    } else {
        
                                        reject({
                                            StatusCode: 400,
                                            StatusInfo: {
                                                message: 'date is not between task\'s start date and end date',
                                                info: JSON.stringify(options)
                                            },
                                            result: {}
                                        });
        
                                    }
        
                                } else {
                                    //date is not today, after today , before today
        
                                    reject({
                                        StatusCode: 400,
                                        StatusInfo: {
                                            message: 'there is problem with the date',
                                            info: JSON.stringify(options)
                                        },
                                        result: {}
                                    });
        
                                }
        
                            }
        
                        }
        

        } catch (err) {
            reject(err);
        }
    });


}

var checkTaskWithTimeSheetEntryDetails = function (options) {
      sails.log.debug('>>>>>>>[checkTaskWithTimeSheetEntryDetails]---->start of function');

    return new Promise(function (resolve, reject) {
        try {


                

            Task.findOne({ id: options.taskId,isTicket:false}).populate('assignedTo').populate('projectId').then(function(resultTask){


                if(!_.isUndefined(resultTask)){


                             if(!_.isUndefined(resultTask.assignedTo)){


                                var idArray = _.map(resultTask.assignedTo,'id');
                               if(!_.isUndefined(idArray)){

                                    checkArryForId(idArray,options.associateId).then(function(resulCheckArrayTask){
                                        options.tasks = resultTask;
                                        sails.log.debug('>>>>>>>[checkTaskWithTimeSheetEntryDetails]---->resolve'+JSON.stringify(options)); 
                                                    resolve(options);
                                    }).catch(function(errCheckArrayTask){
                                        if(errCheckArrayTask.status){

                                            sails.log.debug('>>>>>>>[checkTaskWithTimeSheetEntryDetails]---->array check(else)'); 
                                            reject({
                                                StatusCode: 500,
                                                StatusInfo: {
                                                    message: 'err occuerd',
                                                    info: JSON.stringify(errCheckArrayTask)
                                                },
                                                result: {}
                                            });

                                        }else{

                                            sails.log.debug('>>>>>>>[checkTaskWithTimeSheetEntryDetails]---->array check(else)'); 
                                            reject({
                                                StatusCode: 400,
                                                StatusInfo: {
                                                    message: 'there is no such a associate in task',
                                                    info: JSON.stringify(options)
                                                },
                                                result: {}
                                            });
                                        }
                                    });

                               }else{

                                sails.log.debug('>>>>>>>[checkTaskWithTimeSheetEntryDetails]---->check the assigend user in task for null(else2)'); 
                                reject({
                                    StatusCode: 400,
                                    StatusInfo: {
                                        message: 'there is no such a associate in task',
                                        info: JSON.stringify(options)
                                    },
                                    result: {}
                                });

                               }



                             }else{
                                sails.log.debug('>>>>>>>[checkTaskWithTimeSheetEntryDetails]---->check the assigend user in task for null(else)'); 
                                reject({
                                    StatusCode: 400,
                                    StatusInfo: {
                                        message: 'there is no such a associate in task',
                                        info: JSON.stringify(options)
                                    },
                                    result: {}
                                });

                             }



                }else{

                    sails.log.debug('>>>>>>>[checkTaskWithTimeSheetEntryDetails]---->check the task result for null(else)'); 
                    reject({
                        StatusCode: 400,
                        StatusInfo: {
                            message: 'there is no such a task',
                            info: JSON.stringify(options)
                        },
                        result: {}
                    });
                }
                



            }).catch(function(errTask){
                sails.log.debug('>>>>>>>[checkTaskWithTimeSheetEntryDetails]---->err while query the task'); 
                reject({
                    StatusCode: 500,
                    StatusInfo: {
                        message: 'error occuerd',
                        info: JSON.stringify(errTask)
                    },
                    result: {}
                });

            });


               
        } catch (err) {
            sails.log.debug('>>>>>>>[checkTaskWithTimeSheetEntryDetails]---->main catch'); 
            reject(err);


        }



    });
}

var checkProjctWithTimeSheetEntryDetails = function (options) {

    sails.log.debug('>>>>>>>[checkProjctWithTimeSheetEntryDetails]-->start of function');
    return new Promise(function (resolve, reject) {


        try {

            Project.findOne({ id: options.projectId }).populate('tasks').populate('manager').populate('membares').then(function (resultProject) {






                if (!_.isUndefined(resultProject)) {

                    if (!_.isUndefined(resultProject.tasks)) {
                        getIdListFromObjectArray(resultProject.tasks).then(function(resultTaskIdArray) {
                            if(!_.isUndefined(resultTaskIdArray)){
                              checkArryForId(resultTaskIdArray,options.taskId).then(function(resultCheckAray){
                                if(!_.isUndefined(resultProject.membares)){
                                    sails.log.debug('>>>>>>>>>>>>>>[checkProjctWithTimeSheetEntryDetails]---->start of checking project members');
                                    getIdListFromObjectArray(resultProject.membares).then(function(resultAssociateIdArray){
                                                       if(!_.isUndefined(resultAssociateIdArray)){

                                                        checkArryForId(resultAssociateIdArray,options.associateId).then(function(resultCheckAray2){
                                                                    options.approvelManager = resultProject.manager.id;
                                                                    resolve(options);
                                                        }).catch(function(errCheckArray2){

                                                            if(errCheckArray2.status){

                                                                reject({
                                                                    StatusCode: 500,
                                                                    StatusInfo: {
                                                                        message: 'error occuerd',
                                                                        info: JSON.stringify(errCheckArray2)
                                                                    },
                                                                    result: {}
                                                                }); 

                                                            }else{

                                                                reject({
                                                                    StatusCode: 400,
                                                                    StatusInfo: {
                                                                        message: 'member is not present in this project',
                                                                        info: JSON.stringify(options)
                                                                    },
                                                                    result: {}
                                                                }); 

                                                            }
 
                                                        });

                                                       }else{
                                                        reject({
                                                            StatusCode: 400,
                                                            StatusInfo: {
                                                                message: 'there is no members in this project',
                                                                info: JSON.stringify(options)
                                                            },
                                                            result: {}
                                                        }); 
                                                       }
                                    }).catch(function(errAssociateIdArray){
                                        reject({
                                            StatusCode: 500,
                                            StatusInfo: {
                                                message: 'error occuerd',
                                                info: JSON.stringify(errtAssociateIdArray)
                                            },
                                            result: {}
                                        }); 
                                    });   
                                }else{
                                    sails.log.debug('>>>>>>>>>>>>>>[checkProjctWithTimeSheetEntryDetails]---->start of checking project members (else)');
                                    reject({
                                        StatusCode: 400,
                                        StatusInfo: {
                                            message: 'there is no members in this project',
                                            info: JSON.stringify(options)
                                        },
                                        result: {}
                                    }); 
                                }
                              }).catch(function(errCheckArray){
                                  if(errCheckArray.status){
                                    reject({
                                        StatusCode: 500,
                                        StatusInfo: {
                                            message: 'error occuerd',
                                            info: JSON.stringify(resultCheckAray)
                                        },
                                        result: {}
                                    });

                                  }else{
                                    reject({
                                        StatusCode: 400,
                                        StatusInfo: {
                                            message: ' tasks is not in this project',
                                            info: JSON.stringify(options)
                                        },
                                        result: {}
                                    }); 
                                  }

                              });
                            }else{

                                reject({
                                    StatusCode: 400,
                                    StatusInfo: {
                                        message: 'there is no tasks in this project',
                                        info: JSON.stringify(options)
                                    },
                                    result: {}
                                });

                            }
                            

                        }).catch(function (errTaskArrayId) {
                            sails.log.debug('>>>>>>>[checkProjctWithTimeSheetEntryDetails]-->err while getting task id array');
                            reject({
                                StatusCode: 500,
                                StatusInfo: {
                                    message: 'an error occuerd',
                                    info: JSON.stringify(errTaskArrayId)
                                },
                                result: {}
                            });
                        });
                    } else {
                        sails.log.debug('>>>>>>>[checkProjctWithTimeSheetEntryDetails]-->task is not present');
                        reject({
                            StatusCode: 400,
                            StatusInfo: {
                                message: 'there is no tasks in this project',
                                info: JSON.stringify(options)
                            },
                            result: {}
                        });

                    }














                } else {
                    sails.log.debug('>>>>>>>[checkProjctWithTimeSheetEntryDetails]-->project id not present');
                    reject({
                        StatusCode: 400,
                        StatusInfo: {
                            message: 'project id is not present in the database',
                            info: JSON.stringify(options)
                        },
                        result: {}
                    });

                }



            }).catch(function (errProject) {

                sails.log.debug('>>>>>>>[checkProjctWithTimeSheetEntryDetails]-->err in project query');
                reject({
                    StatusCode: 500,
                    StatusInfo: {
                        message: 'an error occuerd',
                        info: JSON.stringify(errProject)
                    },
                    result: {}
                });
            });





        } catch (err) {

            sails.log.debug('>>>>>>>[checkProjctWithTimeSheetEntryDetails]-->main catch');
            reject(err);
        }




    });

}

var timeSheetEntryFn = function saveSingleTimeSheetEntry(options) {


             sails.log.debug('>>>>>>>[timeSheetEntryFn]-->start of function');
                      
    return new Promise(function (resolve, reject) {


        try {

            if (_.isUndefined(options) ||_.isUndefined(options.hours) || _.isUndefined(options.projectId) || _.isUndefined(options.taskId) || _.isUndefined(options.dateAndTime) | _.isUndefined(options.comments) || _.isUndefined(options.associateId)) {
               
                sails.log.debug('>>>>>>>[timeSheetEntryFn]-->input validation');
                reject({

                    StatusCode: 400,
                    StatusInfo: {
                        message: 'reqierd fields are missing',
                        info: options
                    },
                    result: {}
                });
            }
                
            checkProjctWithTimeSheetEntryDetails(options).then(function(resultOptionsProject){

                checkTaskWithTimeSheetEntryDetails(resultOptionsProject).then(function(resulTaskCheck){

                    validateDateForTimeSheetEntry(resulTaskCheck).then(async function(resultDateValidation){
                           
                    //    try{

                    //     var timesheets = await TimeSheetEntries.find({TaskId:resultDateValidation.taskId});

                    //    }catch(e){
                    //     reject(e);

                    //    }
              TimeSheetEntries.create({
                  ProjectId:resultDateValidation.projectId,
                  TaskId:resultDateValidation.taskId,
                  DateAndTime:resultDateValidation.dateAndTime,
                  comments:resultDateValidation.comments,
                  associateId:resultDateValidation.associateId,
                  approvelManager:resultDateValidation.approvelManager,
                  hours:resultDateValidation.hours
                }).then(async function(resultTimeSheetEntry){
                    // if(_.isUndefined(timesheets)){
                    //     // try{
                    //     //      await Task.update({id:resultTimeSheetEntry.TaskId}).set({state:2});
                    //     //      resolve(resultTimeSheetEntry);
                    //     // }catch(e2){
                    //     //     resolve(resultTimeSheetEntry);
                    //     // }
                    //    
                    // }
                    resolve(resultTimeSheetEntry);
                   
                }).catch(function(errTimeSheetEntry){
                    reject(errTimeSheetEntry);
                });

                    }).catch(function(errDateValidation){
                        sails.log.debug('>>>>>>>[timeSheetEntryFn]-->date check');
                        reject(errDateValidation);
                    });

                }).catch(function(errTaskCheck){
                    sails.log.debug('>>>>>>>[timeSheetEntryFn]-->task Check');
                    reject(errTaskCheck);
                });

            }).catch(function(errOptionsProjects){
                sails.log.debug('>>>>>>>[timeSheetEntryFn]-->Project Check');
                reject(errOptionsProjects);
            });


            //   TimeSheetEntries.create({
            //       ProjectId:options.projectId,
            //       TaskId:options.taskId,
            //       DateAndTime:options.dateAndTime,
            //       comments:optoins.comments,
            //       associateId:options.associateId,
            //       approvelManager:optons.approvelManager,
            //     }).then(function(resultTimeSheetEntry){
            //         resolve(resultTimeSheetEntry);
            //     }).catch(function(errTimeSheetEntry){
            //         reject(errTimeSheetEntry);
            //     });


        } catch (err) {
            sails.log.debug('>>>>>>>[timeSheetEntryFn]-->main catch');
            reject(err);
        }



    });

}



module.exports = {

    saveSingleTimeSheetEntries: function (options) {

        return new Promise( async function (resolve, reject) {
            try {

                if (_.isArray(options.timeSheetEntries) && options.timeSheetEntries.length) {

                              
                    Promise.all(options.timeSheetEntries.map(timeSheetEntryFn)).then(function (result) {

                      
                        resolve({
                            StatusCode: 201,
                            StatusInfo: {
                                message: 'sucess',
                                info: {}
                            },
                            result: result

                        });

                    }).catch(function (err) {

                        sails.log.debug('>>>>>>>[saveSingleTimeSheetEntries]-->array entries -->promise all catch');

                        reject({

                                
                            StatusCode: 500,
                            StatusInfo: {

                                message: 'faild',
                                info: JSON.stringify(err)
                            },
                            result: {}


                        });


                    });



                } else {


                    timeSheetEntryFn(options.timeSheetEntries).then(function (result) {

                        resolve({
                            StatusCode: 201,
                            StatusInfo: {
                                message: 'sucess',
                                info: {}
                            },
                            result: result
                        });

                    }).catch(function (err) {

                        reject({
                            StatusCode: 500,
                            StatusInfo: {
                                message: 'faild',
                                info: err
                            },
                            result: {}

                        });

                    });

                }

            } catch (err) {

                reject({
                    StatusCode: 500,
                    StatusInfo: {
                        message: 'faild',
                        info: err
                    },
                    result: {}

                });
            }


        });
    },
    getSavedTimeSheetEntry:function(options){
        return new Promise(function(resolve,reject){
            try{

                Associate.findOne({profileId:options.loggedInUserId, isDeleted:false}).then(function(resultAssociate){
                          if(!_.isUndefined(resultAssociate)){
                              
                                   TimeSheetEntries.find({associateId:resultAssociate.id ,isSubmitted:false}).populate('ProjectId').populate('TaskId').populate('ticket').then(function(resultTimeSheetEntries){
                                  
                                    resultTimeSheetEntries.forEach(function(entry){
                                      delete entry.associateId;
                                      delete entry.approvelManager;
                                      delete entry.isSubmitted;
                                      delete entry.isApproved;
                                      delete entry.isRejected;
                                      delete entry.createdAt;
                                      delete entry.updatedAt;
                                      
                                  });

                                  
                               

                                    if(!_.isUndefined(resultTimeSheetEntries)){

                                        resolve({
                                            StatusCode: 200,
                                            StatusInfo: {
                                                message: 'sucess',
                                                info: options
                                            },
                                            result: resultTimeSheetEntries
                                        });

                                    }else{

                                        resolve({
                                            StatusCode: 404,
                                            StatusInfo: {
                                                message: 'there is no time sheet entry for this user',
                                                info: options
                                            },
                                            result: {}
                                        });

                                    }
                                   }).catch(function(errTimeSheetEntry){
                                    reject({
                                        StatusCode: 500,
                                        StatusInfo: {
                                            message: 'faild',
                                            info: errTimeSheetEntry
                                        },
                                        result: {}
                                    });

                                   });

                          }else{
                            resolve({
                                StatusCode: 400,
                                StatusInfo: {
                                    message: 'there is no associate with this id',
                                    info: options
                                },
                                result: {}
                            });
                          }

                }).catch(function(errAssociate){
                    
                reject({
                    StatusCode: 500,
                    StatusInfo: {
                        message: 'faild',
                        info: errAssociate
                    },
                    result: {}
                });
            });

            }catch(err){

                reject({
                    StatusCode: 500,
                    StatusInfo: {
                        message: 'faild',
                        info: err
                    },
                    result: {}

                });

            }
        
    });
},

editSavedTimeSheet:function(options){
    return new Promise(function(resolve,reject){
        try{

            TimeSheetEntries.findOne({id:options.entryId,associateId:options.associateId,isSubmitted:false,isApproved:false}).then(function(resultTimeSheetEntry){
                         
                if(!_.isUndefined(resultTimeSheetEntry)){


                               

                                if(options.hours >24){

                                    
                    resolve({
                        StatusCode: 400,
                        StatusInfo: {
                            message: 'hours can not more than 24 ',
                            info: options
                        },
                        result: {}
        
                    });

                                }

                                TimeSheetEntries.find({DateAndTime:resultTimeSheetEntry.DateAndTime,associateId:options.associateId}).then( async function(resultTimeEntries){

                                              if(!_.isUndefined(resultTimeEntries)){

                                                var totalHr = 0;

                                                _.map(resultTimeEntries,'hours').forEach(function(hr){

                                                    totalHr = totalHr+hr;

                                                });

                                             

                                                if(totalHr <=24){

 
                                                    var totalHrSecondary = totalHr - resultTimeSheetEntry.hours;
                                                    var hrDiff = 24 - totalHrSecondary;

                                                    if(options.hours <= hrDiff){


                                                     

                                                        try{
                                                            await TimeSheetEntries.update({id:resultTimeSheetEntry.id}).set({comments:options.comments,hours: options.hours});
                                                            resolve({
                                                                StatusCode: 200,
                                                                StatusInfo: {
                                                                    message: 'sucess',
                                                                    info: {}            
                                                                },                  
                                                                result: resultTimeSheetEntry
                                                            });
                                                    
                                                    }catch(e){

                                                        reject({
                                                            StatusCode: 500,
                                                            StatusInfo: {
                                                                message: 'faild',
                                                                info: e
                                                            },
                                                            result: {}
                                            
                                                        });
                    

                                                    }
        
                                                        



                                                    }else{
                                                        resolve({
                                                            StatusCode: 400,
                                                            StatusInfo: {
                                                                message: 'can not enter more than 24 hours',
                                                                info: options
                                                            },
                                                            result: {}
                                            
                                                        });
                                                    }

                                                       

                                                
                                                }else{

                                                    resolve({
                                                        StatusCode: 400,
                                                        StatusInfo: {
                                                            message: 'hours is more than 24 now meet admin',
                                                            info: options
                                                        },
                                                        result: {}
                                        
                                                    });
                                        
                                                  

                                                }

                                                   

                                              }else{

                                                
                                                try{
                                                    await TimeSheetEntries.update({id:resultTimeSheetEntry.id}).set({comments:options.comments,hours: options.hours});
                                                    resolve({
                                                        StatusCode: 200,
                                                        StatusInfo: {
                                                            message: 'sucess',
                                                            info: {}            
                                                        },                  
                                                        result: resultTimeSheetEntry
                                                    });
                                            
                                            }catch(e){

                                                reject({
                                                    StatusCode: 500,
                                                    StatusInfo: {
                                                        message: 'faild',
                                                        info: e
                                                    },
                                                    result: {}
                                    
                                                });
            

                                            }

                                                

                                              }



                                }).catch();

                           


                }else{

                    resolve({
                        StatusCode: 400,
                        StatusInfo: {
                            message: 'there is no Time Sheet With Provided details',
                            info: options
                        },
                        result: {}
        
                    });

                }
            }).catch(function(errTimeSheetEntry){
                reject({
                    StatusCode: 500,
                    StatusInfo: {
                        message: 'faild',
                        info: errTimeSheetEntry
                    },
                    result: {}
    
                });
            });

        }catch(err){

            reject({
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            });

        }
    });
},
deleteTimeSheetEntry:function(options){

    return new Promise(function(resolve,reject){

        try{

            TimeSheetEntries.findOne({id:options.entryId,isSubmitted:false,isApproved:false}).then(function(resultTimeEntry){

                if(!_.isUndefined(resultTimeEntry)){

                         if(resultTimeEntry.associateId==options.associateId){

                            TimeSheetEntries.destroy({id:options.entryId,isSubmitted:false,isApproved:false}).then(function(resultDelete){

                                resolve({
                                    StatusCode: 200,
                                    StatusInfo: {
                                        message: 'sucess',
                                        info: {}
                                    },
                                    result: resultDelete
                    
                                });


                                

                            }).catch(function(errDelete){

                                reject({
                                    StatusCode: 500,
                                    StatusInfo: {
                                        message: 'faild',
                                        info: errDelete
                                    },
                                    result: {}
                    
                                });

                            });

                         }else{
                            resolve({
                                StatusCode: 400,
                                StatusInfo: {
                                    message: 'time sheet entry is not belongs to associatId',
                                    info: options
                                },
                                result: {}
                
                            });
                         }
                    

                }else{

                    resolve({
                        StatusCode: 400,
                        StatusInfo: {
                            message: 'there is no time sheet entry with provided id that can be deleted',
                            info: options
                        },
                        result: {}
        
                    });

                }

            }).catch(function(errTimeSheetEntry){
                reject({
                    StatusCode: 500,
                    StatusInfo: {
                        message: 'faild',
                        info: errTimeSheetEntry
                    },
                    result: {}
    
                });

            });

        }catch(er){
            
            reject({
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            });
        }
         
    });
},
submitTimeSheet:function(options){
    return new Promise(function(resolve,reject){
        try{

                      if(_.isUndefined(options.associateId)){

                        resolve({
                            StatusCode: 500,
                            StatusInfo: {
                                message: 'faild',
                                info: options
                            },
                            result: {}
            
                        });

                      }
                    sails.log.debug('>>>>>[submitTimeSheet] >>>>>.options'+ JSON.stringify(options));
            TimeSheetEntries.findOne({id:options.entryId,isSubmitted:false,isApproved:false,associateId:options.associateId}).then(function(resultTimeEntry){

                if(!_.isUndefined(resultTimeEntry)){
                    var entryDate = new Date(Format(new Date(resultTimeEntry.DateAndTime), 'YYYY-MM-DD'));
                  

                    sails.log.debug('>>>>>[submitTimeSheet] entry date: '+JSON.stringify(entryDate));
                    sails.log.debug('>>>>>[submitTimeSheet] entry date vs today month: '+isThisMonth(entryDate));

                     
                    if(isThisMonth(entryDate)){

                        SubmittedTimeSheets.create({timeSheetId:resultTimeEntry.id,submittedDate:Format(new Date(),'YYYY-MM-DD')}).then(async function(resultSubmittedTimeSheet){

                            
                                
                            try{
                                await TimeSheetEntries.update({id:resultTimeEntry.id}).set({isSubmitted:true});
                                sails.log.debug('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>7');
                                resolve({
                                    StatusCode: 200,
                                    StatusInfo: {
                                        message: 'sucess',
                                        info: {}
                                    },
                                    result: {}
                    
                                });

                            
                            }catch(e){

                                sails.log.debug('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>8');



                                SubmittedTimeSheets.destroy({id:resultSubmittedTimeSheet.id}).then(async function(resultdestroy){
                                    sails.log.debug('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>6');

                                    try{
                                        await TimeSheetEntries.update({id:resultTimeEntry.id}).set({isSubmitted:false});
                                        reject({
                                        
                                            StatusCode: 500,
                                            StatusInfo: {
                                                message: 'faild',
                                                info: e
                                            },
                                            result: {}
                            
                                        });
                                    }catch(e1){

                                        reject({
                                            StatusCode: 500,
                                            StatusInfo: {
                                                message: 'missleading time sheet sumbit is done which have to delete by the db admin',
                                                info: e1
                                            },
                                            result: {}
                            
                                        });

                                    }
                                  

                                }).catch(function(errDestory){
                                    sails.log.debug('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>5');

                                    reject({
                                        StatusCode: 500,
                                        StatusInfo: {
                                            message: 'missleading time sheet sumbit is done which have to delete by the db admin',
                                            info: resultSubmittedTimeSheet
                                        },
                                        result: {}
                        
                                    });

                                });

                            }


                          
                            
                        }).catch(function(errSubmittedTimeSheet){

                            sails.log.debug('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>3');

                            reject({
                                StatusCode: 500,
                                StatusInfo: {
                                    message: 'faild',
                                    info: errSubmittedTimeSheet
                                },
                                result: {}
                
                            });

                        });

                    }else{
                        resolve({
                            StatusCode: 400,
                            StatusInfo: {
                                message: 'only can submit the time from this month',
                                info: options
                            },
                            result: {}
            
                        });
                    }




                }else{

                    resolve({
                        StatusCode: 400,
                        StatusInfo: {
                            message: 'there is no time sheet entry with provided details that can be sumbitted',
                            info: options
                        },
                        result: {}
        
                    });

                }

            }).catch(function(errTimeSheetEntry){

                sails.log.debug('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>2');
                reject({
                    StatusCode: 500,
                    StatusInfo: {
                        message: 'faild',
                        info: errTimeSheetEntry
                    },
                    result: {}
    
                });
            });

        }catch(err){






            sails.log.debug('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>1');
            reject({
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            });

        }

    });
},

getSubmittedTimeSheet:function(options){
    return new Promise(function(resolve,reject){
        try{

            UserProfile.findOne({id:options.loggedInUserId,isDeleted:false}).then(function(resultProfile){

                if(!_.isUndefined(resultProfile)){

                    if(resultProfile.role == 2){

                        Manager.findOne({profileId:resultProfile.id,isDeleted:false}).then(function(resultManger){

                            if(!_.isUndefined(resultManger)){

                                TimeSheetEntries.find({approvelManager:resultManger.id,isSubmitted:true,isApproved:false,isRejected:false}).populate('ProjectId').populate('TaskId').populate('associateId').populate('approvelManager').populate('ticket').then(function(resultTimeEntries){
                                    
                                   if(!_.isUndefined(resultTimeEntries)){

                                    sails.log.debug('>>>>>>>>>>>>>[getSubmittedTimeSheet] >>'+ JSON.stringify(resultTimeEntries));
                                    resolve({
                                        StatusCode: 200,
                                        StatusInfo: {
                                            message: 'sucess',
                                            info: {}
                                        },
                                        result: resultTimeEntries
                        
                                    });

                                   }else{
                                    resolve({
                                        StatusCode: 400,
                                        StatusInfo: {
                                            message: 'there is no time sheet submite for this manager',
                                            info: options
                                        },
                                        result: {}
                        
                                    });
                                   }
                                }).catch(function(errTimeSheetEntry){
                                    reject({
                                        StatusCode: 500,
                                        StatusInfo: {
                                            message: 'faild',
                                            info: errManager
                                        },
                                        result: {}
                        
                                    });

                                });

                            }else{
                                resolve({
                                    StatusCode: 400,
                                    StatusInfo: {
                                        message: 'user registraion problem',
                                        info: options
                                    },
                                    result: {}
                    
                                });
                            }

                        }).catch(function(errManager){
                            reject({
                                StatusCode: 500,
                                StatusInfo: {
                                    message: 'faild',
                                    info: errManager
                                },
                                result: {}
                
                            });

                        });

                    }

                    if(resultProfile.role == 3){

                        Associate.findOne({profileId:resultProfile.id}).then(function(resultAssociate){


                            if(!_.isUndefined(resultAssociate)){

                                TimeSheetEntries.find({associateId:resultAssociate.id,isSubmitted:true,isApproved:false,isRejected:false}).populate('ProjectId').populate('TaskId').populate('associateId').populate('approvelManager').populate('ticket').then(function(resultTimeEntries){

                                    if(!_.isUndefined(resultTimeEntries)){

                                        resolve({
                                            StatusCode: 200,
                                            StatusInfo: {
                                                message: 'sucess',
                                                info: {}
                                            },
                                            result:resultTimeEntries
                            
                                        });

                                    }else{

                                        resolve({
                                            StatusCode: 400,
                                            StatusInfo: {
                                                message: 'no time sheets where submitted so far',
                                                info: options
                                            },
                                            result: {}
                            
                                        });

                                    }

                                }).catch(function(errTimeSheetEntry){

                                    reject({
                                        StatusCode: 500,
                                        StatusInfo: {
                                            message: 'faild',
                                            info: errAssociate
                                        },
                                        result: {}
                        
                                    });

                                });

                            }else{

                                resolve({
                                    StatusCode: 400,
                                    StatusInfo: {
                                        message: 'there is problem with role creation in back end',
                                        info: options
                                    },
                                    result: {}
                    
                                });

                            }



                        }).catch(function(errAssociate){

                            reject({
                                StatusCode: 500,
                                StatusInfo: {
                                    message: 'faild',
                                    info: errAssociate
                                },
                                result: {}
                
                            });

                        });

                    }

                  




                }else{

                    resolve({
                        StatusCode: 400,
                        StatusInfo: {
                            message: 'there is no user with this user id',
                            info: options
                        },
                        result: {}
        
                    });

                }

            }).catch(function(errProfile){
                reject({
                    StatusCode: 500,
                    StatusInfo: {
                        message: 'faild',
                        info: errProfile
                    },
                    result: {}
    
                });
            });

        }catch(err){

            
            reject({
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            });

        }
    });
},
approveTimeSheet:function(options){
    return new Promise(function(resolve,reject){
        try{
            

            Manager.findOne({profileId:options.loggedInUserId, isDeleted:false}).then(function(resultManager){


                if(!_.isUndefined(resultManager)){

                    TimeSheetEntries.findOne({id:options.entryId}).then(function(resultTimeEntry){

                        if(!_.isUndefined(resultTimeEntry)){
                                if(resultTimeEntry.approvelManager == resultManager.id){

                                    var inputcreation ={};
                                    inputcreation.submittedTimeSheetId = options.entryId;
                                    inputcreation.approvedDate = Format(new Date(), 'YYYY-MM-DD');
                                    inputcreation.approvedBy= resultManager.id;




                                    ApprovedTimeSheets.create(inputcreation).then(function(resultCreation){

                                            TimeSheetEntries.findOne({id:options.entryId}).then(function(resultTimeEntries){

                                            }).catch(function(errTimeSheetEntry){

                                                ApprovedTimeSheets.destroy({id:resultCreation.id}).then().catch()

                                            });

                                    }).catch(function(errCreation){

                                        reject({
                                            StatusCode: 500,
                                            StatusInfo: {
                                                message: 'faild',
                                                info: errCreation
                                            },
                                            result: {}
                            
                                        });

                                    });

                                }else{
                                    resolve({
                                        StatusCode: 400,
                                        StatusInfo: {
                                            message: 'logged in user is not the approvel manager for this entry',
                                            info: options
                                        },
                                        result: {}
                        
                                    });
                                }
                            

                        }else{

                            resolve({
                                StatusCode: 400,
                                StatusInfo: {
                                    message: 'there is no time sheet entry with this id',
                                    info: options
                                },
                                result: {}
                
                            });
                        }

                    }).catch(function(errTimeSheetEntry){
                        reject({
                            StatusCode: 500,
                            StatusInfo: {
                                message: 'faild',
                                info: errManager
                            },
                            result: {}
            
                        });
                    });

                }else{
                    resolve({
                        StatusCode: 400,
                        StatusInfo: {
                            message: 'user is not present in the database',
                            info: options
                        },
                        result: {}
        
                    });
                }


            }).catch(function(errManager){

                reject({
                    StatusCode: 500,
                    StatusInfo: {
                        message: 'faild',
                        info: errManager
                    },
                    result: {}
    
                });

            });



        }catch(err){
            reject({
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            });
        }
    });
},

approveSubmittedTimeSheets: async function(options){
    var sucessIds = [];
          try{

            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                },
                result: {}

            } ;

            var timesheetIds = options.timesheetIds;
            var notSubmitedTimeSheets = [];
            var rejectIds = [];
           
            if(_.isArray(timesheetIds)){

                //multiple time sheet id
                if(timesheetIds.length){

                    for(var ids of timesheetIds){
                        var submittedTimeSheet = await SubmittedTimeSheets.findOne({timeSheetId:ids}).populate('timeSheetId');
                        //sails.log.debug('>>>>>>>>>[approveSubmittedTimeSheets] : submitted time sheet:'+ JSON.stringify(submittedTimeSheet));
                        if(!_.isUndefined(submittedTimeSheet)){

                            var manager = await Manager.findOne({id:submittedTimeSheet.timeSheetId.approvelManager});
                            if(manager.profileId == options.loggedInUserId){
                                    var timeSheetEntry = await TimeSheetEntries.findOne({id:submittedTimeSheet.timeSheetId.id});
                                         if(!_.isUndefined(timeSheetEntry)){
                                             if(!timeSheetEntry.isRejected){
                                             if(!timeSheetEntry.isApproved){
                                             var approval = {
                                                submittedTimeSheetId:timeSheetEntry.id,
                                                approvedBy:manager.id,
                                                approvedDate:Format(new Date(),'YYYY-MM-DD')
                                             }
                                             sails.log.debug('>>>>>>>>>[approveSubmittedTimeSheets] : creating');
                                                 var createApprovalResponds =await ApprovedTimeSheets.create(approval).fetch();
                                                 sails.log.debug('>>>>>>>>>[approveSubmittedTimeSheets] : createApprovalResponds:'+ JSON.stringify(createApprovalResponds));
                                                 try{
                                                 var updaeTimeSheetResponds =  await TimeSheetEntries.update({id:submittedTimeSheet.timeSheetId.id}).set({isApproved:true}).fetch();
                                                 sails.log.debug('>>>>>>>>>[approveSubmittedTimeSheets] : err:'+ JSON.stringify(updaeTimeSheetResponds));
                                                 sucessIds.push(ids);
                                                 sails.log.debug('>>>>>>>>>[approveSubmittedTimeSheets] : sucess id:'+ JSON.stringify(sucessIds));
                                                
                                                }
                                                 catch(e){

                                                    await ApprovedTimeSheets.destroy({id:createApprovalResponds.id});
                                                    rejectIds.push({timesheetId:ids,message:'error while updating the value:()-: '+ e.cause.details});

                                                 }
                                                }else{

                                                    rejectIds.push({timesheetId:ids,message:'this timesheet is already approved'});

                                                }
                                            }else{
                                                rejectIds.push({timesheetId:ids,message:'this timesheet is already rejected'});
                                            }
                                             
                                         }else{
                                            rejectIds.push({timesheetId:ids,message:'timesheet Id Problem'});
                                         }
                                         
                            }else{
                                   rejectIds.push({timesheetId:ids,message:'approval manager id problem'});
                            }

                        }else{

                            rejectIds.push({timesheetId:ids,message:'time sheet is not yet submitted'});

                        }
                    }
                           if(!rejectIds.length){
                    responds.StatusCode =200;
                    responds.StatusInfo.message='';
                    responds.StatusInfo.info={
                        rejectIds:rejectIds,
                        rejectedIdCount:rejectIds.length,
                        sucessCount:sucessIds.length
                    };
                    responds.result.sucessids=sucessIds;
                    return responds
                }else if(sucessIds.length){
                    responds.StatusCode =207;
                    responds.StatusInfo.message='';
                    responds.StatusInfo.info={
                        rejectIds:rejectIds,
                        rejectedIdCount:rejectIds.length,
                        sucessCount:sucessIds.length
                    };
                    responds.result.sucessids=sucessIds;
                    return responds
                }else{
                    responds.StatusCode =500;
                    responds.StatusInfo.message='';
                    responds.StatusInfo.info={
                        rejectIds:rejectIds,
                        rejectedIdCount:rejectIds.length,
                        sucessCount:sucessIds.length
                    };
                    responds.result.sucessids=sucessIds;
                    return responds
                }


                }else{
                    responds.StatusCode =400;
                    responds.StatusInfo.message='time sheet ids should not be null';
                    responds.StatusInfo.info=options;
                    return responds
                }

            }else{
                responds.StatusCode =400;
                responds.StatusInfo.message='invalid input';
                responds.StatusInfo.info=options;
                return responds
            }


                  

          }catch(err){
              var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            } ;
              return responds;
          }



},
rejectSubmittedTimeSheets: async function(options){
    var sucessIds = [];
          try{

            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                },
                result: {}

            } ;

            var timesheetIds = options.timesheetIds;
            var notSubmitedTimeSheets = [];
            var rejectIds = [];
           
            if(_.isArray(timesheetIds)){

                //multiple time sheet id
                if(timesheetIds.length){

                    for(var ids of timesheetIds){
                        var submittedTimeSheet = await SubmittedTimeSheets.findOne({timeSheetId:ids}).populate('timeSheetId');
                        //sails.log.debug('>>>>>>>>>[approveSubmittedTimeSheets] : submitted time sheet:'+ JSON.stringify(submittedTimeSheet));
                        if(!_.isUndefined(submittedTimeSheet)){

                            var manager = await Manager.findOne({id:submittedTimeSheet.timeSheetId.approvelManager});
                            if(manager.profileId == options.loggedInUserId){
                                    var timeSheetEntry = await TimeSheetEntries.findOne({id:submittedTimeSheet.timeSheetId.id});
                                         if(!_.isUndefined(timeSheetEntry)){
                                             if(!timeSheetEntry.isApproved){
                                             if(!timeSheetEntry.isRejected){
                                             var reject = {
                                                submittedTimeSheetId:timeSheetEntry.id,
                                                rejectedBy:manager.id,
                                                rejectedDate:Format(new Date(),'YYYY-MM-DD'),
                                                commentsBymanager:options.comments
                                             }
                                             //sails.log.debug('>>>>>>>>>[approveSubmittedTimeSheets] : creating');
                                                 var createRejectResponds =await RejectedTimeSheets.create(reject).fetch();
                                                 //sails.log.debug('>>>>>>>>>[approveSubmittedTimeSheets] : createApprovalResponds:'+ JSON.stringify(createApprovalResponds));
                                                 try{
                                                 var updaeTimeSheetResponds =  await TimeSheetEntries.update({id:submittedTimeSheet.timeSheetId.id}).set({isRejected:true}).fetch();
                                                 //sails.log.debug('>>>>>>>>>[approveSubmittedTimeSheets] : err:'+ JSON.stringify(updaeTimeSheetResponds));
                                                 sucessIds.push(ids);
                                                 //sails.log.debug('>>>>>>>>>[approveSubmittedTimeSheets] : sucess id:'+ JSON.stringify(sucessIds));
                                                
                                                }
                                                 catch(e){

                                                    await RejectedTimeSheets.destroy({id:createRejectResponds.id});
                                                    rejectIds.push({timesheetId:ids,message:'error while updating the value:()-: '+ e.cause.details});

                                                 }
                                                }else{

                                                    rejectIds.push({timesheetId:ids,message:'this timesheet is already rejected'});

                                                }
                                            }else{
                                                rejectIds.push({timesheetId:ids,message:'this timesheet is already  approved'});
                                            }
                                             
                                         }else{
                                            rejectIds.push({timesheetId:ids,message:'timesheet Id Problem'});
                                         }
                                         
                            }else{
                                   rejectIds.push({timesheetId:ids,message:'approval manager id problem'});
                            }

                        }else{

                            rejectIds.push({timesheetId:ids,message:'time sheet is not yet submitted'});

                        }
                    }
                           if(!rejectIds.length){
                    responds.StatusCode =200;
                    responds.StatusInfo.message='';
                    responds.StatusInfo.info={
                        rejectIds:rejectIds,
                        rejectedIdCount:rejectIds.length,
                        sucessCount:sucessIds.length
                    };
                    responds.result.sucessids=sucessIds;
                    return responds
                }else if(sucessIds.length){
                    responds.StatusCode =207;
                    responds.StatusInfo.message='';
                    responds.StatusInfo.info={
                        rejectIds:rejectIds,
                        rejectedIdCount:rejectIds.length,
                        sucessCount:sucessIds.length
                    };
                    responds.result.sucessids=sucessIds;
                    return responds
                }else{
                    responds.StatusCode =500;
                    responds.StatusInfo.message='';
                    responds.StatusInfo.info={
                        rejectIds:rejectIds,
                        rejectedIdCount:rejectIds.length,
                        sucessCount:sucessIds.length
                    };
                    responds.result.sucessids=sucessIds;
                    return responds
                }


                }else{
                    responds.StatusCode =400;
                    responds.StatusInfo.message='time sheet ids should not be null';
                    responds.StatusInfo.info=options;
                    return responds
                }

            }else{
                responds.StatusCode =400;
                responds.StatusInfo.message='invalid input';
                responds.StatusInfo.info=options;
                return responds
            }


                  

          }catch(err){
              var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            } ;
              return responds;
          }



},
getApprovedTimeSheetEntryByAssociate : async function(options){
    try{

        var responds = {
            StatusCode: 0,
            StatusInfo: {
                message: '',
                info: {}
            },
            result: {}

        } ;


    var associate = await Associate.findOne({profileId:options.profileId}).populate('profileId');
    if(!_.isUndefined(associate)){


        var approvedtimesheet = await TimeSheetEntries.find({associateId:associate.id ,isApproved:true}).populate('approvelManager');
       
       if(!_.isUndefined(approvedtimesheet)){
       
        responds.StatusCode =200;
        responds.StatusInfo.message='sucess';
        responds.StatusInfo.info=options;
        responds.result= approvedtimesheet;
        return responds

    }else{
        responds.StatusCode =400;
        responds.StatusInfo.message='there is no time sheet approved for this user';
        responds.StatusInfo.info=options;
        return responds
    }

    }else{
        responds.StatusCode =400;
        responds.StatusInfo.message='there is no associate with this logged in user id';
        responds.StatusInfo.info=options;
        return responds
    }

    }catch(err){
              var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            } ;
              return responds;
          }
},
getRejectedTimeSheetEntryByAssociate : async function(options){
    try{

        var responds = {
            StatusCode: 0,
            StatusInfo: {
                message: '',
                info: {}
            },
            result: {}

        } ;


    var associate = await Associate.findOne({profileId:options.profileId}).populate('profileId');
    if(!_.isUndefined(associate)){


        var rejectedTimeSheet = await TimeSheetEntries.find({associateId:associate.id ,isRejected:true});
       
       if(!_.isUndefined(rejectedTimeSheet)&&_.isArray(rejectedTimeSheet)&&rejectedTimeSheet.length){
             var rejectId = _.map(rejectedTimeSheet,'id');
       var rejected= await RejectedTimeSheets.find({submittedTimeSheetId:rejectId,reSubmitted:false}).populate('submittedTimeSheetId').populate('rejectedBy');
       if(!_.isUndefined(rejected)&&_.isArray(rejected)&&rejected.length == rejectedTimeSheet.length){
        responds.StatusCode =200;
        responds.StatusInfo.message='sucess';
        responds.StatusInfo.info=options;
        responds.result= rejected;
        return responds
       }else{
        responds.StatusCode =400;
        responds.StatusInfo.message='this data is not consistant ';
        responds.StatusInfo.info=options;
        return responds
       }

    }else{
        responds.StatusCode =400;
        responds.StatusInfo.message='there is no time sheet approved for this user';
        responds.StatusInfo.info=options;
        return responds
    }

    }else{
        responds.StatusCode =400;
        responds.StatusInfo.message='there is no associate with this logged in user id';
        responds.StatusInfo.info=options;
        return responds
    }

    }catch(err){
              var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            } ;
              return responds;
          }
},

saveTimeSheetForTicket: async function(options){
    try{
        var responds = {
            StatusCode: 0,
            StatusInfo: {
                message: '',
                info: {}
            },
            result: {}

        } ;

        var ticket = await Ticket.findOne({id:options.ticketId});;
        if(!_.isUndefined(ticket)){



            var task = await Task.findOne({id:ticket.Task}).populate('assignedTo');
            if(!_.isUndefined(task)){

                if(!_.isUndefined(task.assignedTo) && _.isArray(task.assignedTo) && task.assignedTo.length){
                     
                      var associateIds = _.map(task.assignedTo,'id');
                      var isAssigned = false;

                     var associate = await Associate.findOne({id:options.associateId,isDeleted:false});
                     if(!_.isUndefined(associate)){

                        for(var id of associateIds){
                            if(id == associate.id){
                                isAssigned = true;
                            }
                        }

                        if(isAssigned){

                            var timeSheetEntryDate = new Date(Format(new Date(options.entryDate),'YYYY-MM-DD'));

                            var ticketCreatedDate = new Date(Format(new Date(ticket.createdDate),'YYYY-MM-DD'));

                            var today = new Date(Format(new Date(),'YYYY-MM-DD'));
                            if(isToday(timeSheetEntryDate)){
                                //entry today
                                     if(!isBefore(timeSheetEntryDate,ticketCreatedDate)){

                                        if(ticket.state == 1){
                                            var totalHrForentryDate =0;
                                            var timesheetentries = await TimeSheetEntries.find({
                                                associateId:associate.id,
                                                DateAndTime:Format(timeSheetEntryDate,'YYYY-MM-DD')
                                            });

                                            for(var timeEntry of timesheetentries){
                                                totalHrForentryDate = totalHrForentryDate+timeEntry.hours;

                                            }




                                            if(totalHrForentryDate < 24){

                                                var sumtotaltime = 24-totalHrForentryDate ;

                                                if(options.hours <= sumtotaltime){

                                                    var timeSheetEntry = await TimeSheetEntries.create({
                                                        ProjectId:ticket.project,
                                                        hours:options.hours,
                                                        isTicket:true,
                                                        ticket:ticket.id,
                                                        TaskId:task.id,
                                                        DateAndTime:Format(timeSheetEntryDate,'YYYY-MM-DD'),
                                                        associateId:associate.id,
                                                        approvelManager:ticket.reportingUser,
                                                        comments:options.comments

                                                    });

                                                    responds.StatusCode =201;
                                                    responds.StatusInfo.message='sucess';
                                                    responds.result =timeSheetEntry;
                                                    return responds

                                                }else{
                                                    responds.StatusCode =400;
                                                    responds.StatusInfo.message='you cant enter more than 24 hours a day for time sheet';
                                                    responds.StatusInfo.info=options;
                                                    return responds
                                                }

                                            }else{
                                                responds.StatusCode =400;
                                            responds.StatusInfo.message='you cant enter more than 24 hours a day for time sheet';
                                            responds.StatusInfo.info=options;
                                            return responds
                                            }

                                        }else{
                                            responds.StatusCode =400;
                                            responds.StatusInfo.message='you cant enter time sheet for ticket that is closed';
                                            responds.StatusInfo.info=options;
                                            return responds
                                        }

                                     }else{
                                        responds.StatusCode =400;
                                        responds.StatusInfo.message='you cant enter time sheet before the ticket created date';
                                        responds.StatusInfo.info=options;
                                        return responds
                                     }

                            }else if(isAfter(timeSheetEntryDate,today)){
                                responds.StatusCode =400;
                                responds.StatusInfo.message='you can\'t enter time entry for future date';
                                responds.StatusInfo.info=options;
                                return responds
                            }
                            else if(isBefore(timeSheetEntryDate,today)){
                                // entry before today
                                if(!isBefore(timeSheetEntryDate,ticketCreatedDate)){

                                    if(ticket.state == 1){

                                        var totalHrForentryDate =0;
                                        var timesheetentries = await TimeSheetEntries.find({
                                            associateId:associate.id,
                                            DateAndTime:Format(timeSheetEntryDate,'YYYY-MM-DD')
                                        });

                                        for(var timeEntry of timesheetentries){
                                            totalHrForentryDate = totalHrForentryDate+timeEntry.hours;

                                        }
                                        if(totalHrForentryDate < 24){

                                            var sumtotaltime = 24-totalHrForentryDate ;

                                            if(options.hours <= sumtotaltime){

                                                var timeSheetEntry = await TimeSheetEntries.create({
                                                    hours:options.hours,
                                                    isTicket:true,
                                                    ticket:ticket.id,
                                                    TaskId:task.id,
                                                    DateAndTime:Format(timeSheetEntryDate,'YYYY-MM-DD'),
                                                    associateId:associate.id,
                                                    approvelManager:ticket.reportingUser,
                                                    comments:options.comments

                                                }).fetch();

                                                responds.StatusCode =201;
                                                responds.StatusInfo.message='sucess';
                                                responds.result =timeSheetEntry;
                                                return responds

                                            }else{
                                                responds.StatusCode =400;
                                                responds.StatusInfo.message='you cant enter more than 24 hours a day for time sheet';
                                                responds.StatusInfo.info=options;
                                                return responds
                                            }

                                        }else{
                                            responds.StatusCode =400;
                                        responds.StatusInfo.message='you cant enter more than 24 hours a day for time sheet';
                                        responds.StatusInfo.info=options;
                                        return responds
                                        }

                                    }else{
                                        responds.StatusCode =400;
                                        responds.StatusInfo.message='you cant enter time sheet for ticket that is closed';
                                        responds.StatusInfo.info=options;
                                        return responds
                                    }

                                 }else{
                                    responds.StatusCode =400;
                                    responds.StatusInfo.message='you cant enter time sheet before the ticket created date';
                                    responds.StatusInfo.info=options;
                                    return responds
                                 }

                            }else{
                                responds.StatusCode =400;
                                responds.StatusInfo.message='problem with entry date';
                                responds.StatusInfo.info=options;
                                return responds
                            }

                        }else{

                            responds.StatusCode =400;
                        responds.StatusInfo.message='proided associate id is not assigned to this thicket';
                        responds.StatusInfo.info=options;
                        return responds

                        }

                     }else{
                        responds.StatusCode =400;
                        responds.StatusInfo.message='there is no associate with provided associate id';
                        responds.StatusInfo.info=options;
                        return responds
                     }
                     
                }else{
                    responds.StatusCode =400;
                    responds.StatusInfo.message='there is no associate assigned to this ticket';
                    responds.StatusInfo.info=options;
                    return responds
                }

            }else{
                responds.StatusCode =400;
                responds.StatusInfo.message='there is problem with associated task with this ticket';
                responds.StatusInfo.info=options;
                return responds
            }
            

        }else{
            responds.StatusCode =400;
            responds.StatusInfo.message='there is no ticket with provided ticket id';
            responds.StatusInfo.info=options;
            return responds
        }

    }catch(err){
        var responds = {
          StatusCode: 500,
          StatusInfo: {
              message: 'faild',
              info: err
          },
          result: {}

      } ;
        return responds;
    }
},

resubmitRejectedTimeSheet:async function(options){
    try{
        var responds = {
            StatusCode: 0,
            StatusInfo: {
                message: '',
                info: {}
            },
            result: {}

        } ;

        var associate = await Associate.findOne({id:options.associateId});
        if(!_.isUndefined(associate)){


           var timeSheet = await TimeSheetEntries.findOne({id:options.timeSheetId,isApproved:false});
           if(!_.isUndefined(timeSheet)){
                   


                        if(timeSheet.isRejected){

                             if(timeSheet.associateId == associate.id){

                                var rejectedEntry = await RejectedTimeSheets.findOne({submittedTimeSheetId:timeSheet.id,reSubmitted:false});
                                if(!_.isUndefined(rejectedEntry)){

                                   if(options.hours>24){
                                    responds.StatusCode =400;
                                    responds.StatusInfo.message='time entry should not be more than 24 hours';
                                    responds.StatusInfo.info=options;
                                    return responds
                                   }

                                   var timeEntriesByDateAndAssociate = await TimeSheetEntries.find({associateId:associate.id,DateAndTime:Format(new Date(timeSheet.DateAndTime),'YYYY-MM-DD')});

                                   var totalEntryHours = 0;
                                   for(var timeEntry of timeEntriesByDateAndAssociate){
                                       totalEntryHours = totalEntryHours + timeEntry.hours;
                                   }

                                   if(totalEntryHours < 24){

                                       var hoursMinus24 = 24 -  totalEntryHours;

                                       if(options.hours <= hoursMinus24){

                                                var UpdatedResult = await TimeSheetEntries.update({id:timeSheet.id}).set({
 
                                                    hours:options.hours,
                                                    comments:options.comments,
                                                    isRejected:false,
                                                    isSubmitted:true
                                                });

                                                try{

                                                    await RejectedTimeSheets.update({submittedTimeSheetId:timeSheet.id}).set({
                                                         reSubmitted:true
                                                    });

                                                    responds.StatusCode =200;
                                                    responds.StatusInfo.message='sucess';
                                                    responds.result = UpdatedResult;
                                                    return responds

                                                }catch(e){

                                                     try{
                                                      await TimeSheetEntries.update({id:timeSheet.id}).set({
 
                                                            hours:timeSheet.hours,
                                                            comments:timeSheet.comments,
                                                            isRejected:true,
                                                            isSubmitted:true
                                                        });
                                                        responds.StatusCode =500;
                                                        responds.StatusInfo.message='faild';
                                                        responds.StatusInfo.info = e;
                                                        return responds

                                                     }catch(e2){
                                                        responds.StatusCode =500;
                                                        responds.StatusInfo.message='faild and wrond data has been writern to database';
                                                        responds.StatusInfo.info = e2;
                                                        return responds
                                                     }


                                                }

                                       }else{
                                        responds.StatusCode =400;
                                        responds.StatusInfo.message='time entry should not be more than 24 hours';
                                        responds.StatusInfo.info=options;
                                        return responds
                                       }

                                   }else{
                                    responds.StatusCode =400;
                                    responds.StatusInfo.message='time entry should not be more than 24 hours';
                                    responds.StatusInfo.info=options;
                                    return responds
                                   }



                                }else{
                                    responds.StatusCode =400;
                                responds.StatusInfo.message='there is problem with rejeccted time sheet';
                                responds.StatusInfo.info=options;
                                return responds
                                }


                             }else{
                                responds.StatusCode =400;
                                responds.StatusInfo.message='provided time sheet entry is belongs to this associate';
                                responds.StatusInfo.info=options;
                                return responds
                             }

                        }else{
                            responds.StatusCode =400;
                            responds.StatusInfo.message='provided time sheet entry is not rejected one';
                            responds.StatusInfo.info=options;
                            return responds
                        }
                //   if(timeSheet.assoassociateId == associate.id){

                //   }else{
                      
                //   }
                

           }else{
            responds.StatusCode =400;
            responds.StatusInfo.message='there is no time sheet entry  with provided time sheet id';
            responds.StatusInfo.info=options;
            return responds
           }

        }else{
            responds.StatusCode =400;
            responds.StatusInfo.message='there is no associate with provided associate';
            responds.StatusInfo.info=options;
            return responds
        }




    }catch(err){
        var responds = {
          StatusCode: 500,
          StatusInfo: {
              message: 'faild',
              info: err
          },
          result: {}

      } ;
        return responds;
    }
},
deletRejectedTimeSheet:async function(options){
    try{
        var responds = {
            StatusCode: 0,
            StatusInfo: {
                message: '',
                info: {}
            },
            result: {}

        } ;

        var associate = await Associate.findOne({id:options.associateId});
        if(!_.isUndefined(associate)){


           var timeSheet = await TimeSheetEntries.findOne({id:options.timeSheetId,isApproved:false});
           if(!_.isUndefined(timeSheet)){
                   


                        if(timeSheet.isRejected){

                             if(timeSheet.associateId == associate.id){
                                           
                                  var rejectedTimeSheets = await RejectedTimeSheets.findOne({submittedTimeSheetId:timeSheet.id,reSubmitted:false});
                                  if(!_.isUndefined(rejectedTimeSheets)){

                                    var submittedTimeSheet = await SubmittedTimeSheets.findOne({timeSheetId:timeSheet.id});
                                    if(!_.isUndefined(submittedTimeSheet)){

                                    var submittedTimeSheet = await SubmittedTimeSheets.findOne({timeSheetId:timeSheet.id});
                                        await SubmittedTimeSheets.destroy({id:submittedTimeSheet.id});
                                        try{
                                            await RejectedTimeSheets.destroy({id:rejectedTimeSheets.id});

                                            try{
                                                await TimeSheetEntries.destroy({id:timeSheet.id});
                                                responds.StatusCode =200;
                                                responds.StatusInfo.message='sucess';
                                                return responds
                                            }catch(e3){

                                                try{

                                                    await RejectedTimeSheets.create(rejectedTimeSheets);
                                                 

                                                    try{
                                                        await SubmittedTimeSheets.create(submittedTimeSheet);
                                                        responds.StatusCode =500;
                                                        responds.StatusInfo.message='entry currecpted';
                                                        responds.StatusInfo.info=e3;
                                                        return responds

                                                    }catch(e6){

                                                        responds.StatusCode =500;
                                                        responds.StatusInfo.message='entry currecpted';
                                                        responds.StatusInfo.info=e6;
                                                        return responds

                                                    }
                                                

                                                }catch(e4){
                                                    try{

                                                        await SubmittedTimeSheets.create(submittedTimeSheet);

                                                        responds.StatusCode =500;
                                                        responds.StatusInfo.message='entry currecpted';
                                                        responds.StatusInfo.info=e4;
                                                        return responds
                                                    }catch(e5){
                                                        responds.StatusCode =500;
                                                        responds.StatusInfo.message='entry currecpted';
                                                        responds.StatusInfo.info=e5;
                                                        return responds
                                                    }

                                                }

                                            }

                                        }catch(e){
                                            try{
                                                await SubmittedTimeSheets.create(submittedTimeSheet);
                                                responds.StatusCode =500;
                                                responds.StatusInfo.message='faild';
                                                responds.StatusInfo.info=e;
                                                return responds
                                            }catch(e2){
                                                responds.StatusCode =500;
                                                responds.StatusInfo.message='faild with worng data deletion';
                                                responds.StatusInfo.info=e.error2 = e2;
                                                return responds
                                            }
                                        }

                                    }else{
                                        responds.StatusCode =400;
                                        responds.StatusInfo.message='problem with reject time sheet';
                                        responds.StatusInfo.info=options;
                                        return responds
                                    }

                                  }else{
                                    responds.StatusCode =400;
                                    responds.StatusInfo.message='problem with reject time sheet';
                                    responds.StatusInfo.info=options;
                                    return responds
                                  }

                             }else{
                                responds.StatusCode =400;
                                responds.StatusInfo.message='provided time sheet entry is belongs to this associate';
                                responds.StatusInfo.info=options;
                                return responds
                             }

                        }else{
                            responds.StatusCode =400;
                            responds.StatusInfo.message='provided time sheet entry is not rejected one';
                            responds.StatusInfo.info=options;
                            return responds
                        }
                //   if(timeSheet.assoassociateId == associate.id){

                //   }else{
                      
                //   }
                

           }else{
            responds.StatusCode =400;
            responds.StatusInfo.message='there is no time sheet entry  with provided time sheet id';
            responds.StatusInfo.info=options;
            return responds
           }

        }else{
            responds.StatusCode =400;
            responds.StatusInfo.message='there is no associate with provided associate';
            responds.StatusInfo.info=options;
            return responds
        }




    }catch(err){
        var responds = {
          StatusCode: 500,
          StatusInfo: {
              message: 'faild',
              info: err
          },
          result: {}

      } ;
        return responds;
    }
}




};

