
var dateHandler = require('date-fns');
var isBefore = require('date-fns/is_before');
var isValid = require('date-fns/is_valid');
var isEqual = require('date-fns/is_equal');
var isAfter = require('date-fns/is_after');
var Format = require('date-fns/format');



function saveRecords(record) {

    return new Promise(function (resolve, reject) {

        if (!_.isUndefined(record)) {

            record.save(function (err) {
                if (err) {
                    reject(err);
                } else {
                    resolve(record);
                }
            })

        } else {
            reject({ error: 'records is not defind for save' });
        }

    });
}
function checkArray(array, keyVal) {
    return new Promise(function (resolve, reject) {
        try {

            console.log('>>>>>>>>>in side checkArry function promise >>>keyVal ' + keyVal);
            console.log('>>>>>>>>>>>in side checkArryForId function promise ' + array.toString());
            var obj = {};

            for (var i = 0; i < array.length; i++) {
                if (array[i] == keyVal) {
                    sails.log.debug('>>>>>>>> array check i');
                    obj = array[i];
                    resolve(obj)
                }
            }
            console.log('>>>>>>>>>>>in side checkArryF  ' + array.toString());
            resolve();
        } catch (err) {
            reject(err);
        }

    });
}
function checkArryForId(array, keyVal) {
    console.log('>>>>>>>>>in side checkArryForId function');
    return new Promise(function (resolve, reject) {
        console.log('>>>>>>>>>in side checkArryForId function promise');

        checkArray(array, keyVal).then(function (obj) {

            console.log('>>>>>>>>>in side checkArryForId function promise >>>keyVal ' + keyVal);
            console.log('>>>>>>>>>in side checkArryForId function promise obj' + obj);
            console.log('>>>>>>>>>>>in side checkArryForId function promise ' + _.isUndefined(obj));
            console.log('>>>>>>>>>>>in side checkArryForId function promise ' + array.toString());

            if (!_.isUndefined(obj)) {

                console.log('>>>>>>>>>>>in side checkArryForId function promise if ' + array.toString());
                console.log('>>>>>>>>>>>in side checkArryForId function promise if' + _.isUndefined(obj));
                reject({ status: false });

            } else {

                resolve({});


            }
        }).catch(function (err) {


            reject({ status: true });

        });








    });
}
function checkArryForIds(array, keyVal) {
    console.log('>>>>>>>>>in side checkArryForId function');
    sails.log.debug('>>>>>>>>main array length : ' + array.length + ' >>>>>> keyval length ' + keyVal.length);
    return new Promise(function (resolve, reject) {
        try {
            var respondsObject = { validIdid: [], invalidId: [] };
            if (_.isArray(keyVal)) {
                if (keyVal.length) {
                    sails.log.debug('>>>>>>>>>>inside if condition');
                    for (var i = 0; i < keyVal.length; i++) {
                        sails.log.debug('>>>>>>>>>>inside for loop');
                        // var obj = _.find(array, { id: keyVal[i] });

                        var obj = { q: 1 };

                        if (!_.isUndefined(obj)) {
                            sails.log.debug('>>>>>>>>>>inside for loop inside if ');

                            respondsObject.invalidId.push(keyVal[i]);

                        } else {
                            sails.log.debug('>>>>>>>>>>inside for loop inside else ');
                            respondsObject.validIdid.push(keyVal[i]);


                        }

                    }
                    sails.log.debug('>>>>>>>>>>out side for loop');
                    sails.log.info('>>>>>>>respondsObject :::::' + respondsObject.invalidId);
                    resolve(respondsObject);

                } else {
                    sails.log.debug('>>>>>>>>>>reject 1');
                    reject({ mess: '1' });
                }

            } else {
                sails.log.debug('>>>>>>>>>>reject 2');
                reject({ mess: '2' });
            }
        } catch (err) {
            sails.log.debug('>>>>>>>>>>reject 3');
            reject({ err: 'err' });
        }



    });
}


function getAssociteIdListFromProjectMembers(objetArray) {


    return new Promise(function (resolve, reject) {

        try {
            var responds = _.map(objetArray, 'id');


            resolve(responds);
        } catch (err) {
            reject(err);
        }
    });


}
function getAssociteIdListFromObjectArray(objectArray) {
    return new Promise(function (resolve, reject) {

        try {
            var responds = _.map(objectArray, 'id');

            resolve(responds);
        } catch (err) {
            reject(err);
        }
    });
}


module.exports = {

    createBasicProject: function (options) {
        return new Promise(function (resolve, reject) {

            try {


                console.log('>>>>>create basic project');


                Manager.findOne({ profileId: options.manager, isDeleted: false }).then(function (result) {

                    console.log('>>>>>create basic project>>Manager.FindOne>>Then>>>>>' + options.manager);
                    if (_.isUndefined(result)) {
                        resolve({
                            StatusCode: 400, StatusInfo: {
                                message: 'provided user id is not present in the database',
                                info: {}
                            }, result: {}
                        });
                    }
                    options.manager = result.id;
                    console.log('>>>>>create basic project>>Manager.FindOne>>Then>>>>>>>>>NEXT' + options.manager);
                    Project.create(options).then(function (result2) {




                        var projectHistory = {};
                        projectHistory.projectId = result2.id;
                        projectHistory.dateOfEntry = Format(new Date(), 'YYYY-MM-DD').toString();
                        projectHistory.userId = result.id;
                        projectHistory.comments = 'created new project';


                        ProjectHistory.create(projectHistory).then(function (r) {
                            console.log('>>>>>create basic project>>Manager.FindOne>>Then>>Project.create.then>>create projectHistory');
                            resolve({
                                StatusCode: 201, StatusInfo: {
                                    message: 'project created sucessfully',
                                    info: {}
                                }, result: result2
                            });
                        }).catch(function (err0) {
                            resolve({
                                StatusCode: 207, StatusInfo: {
                                    message: 'project created sucessfully without adding history',
                                    info: err0
                                }, result: result2
                            });
                        });



                    }).catch(function (err2) {
                        console.log('>>>>>create basic project>>Manager.FindOne>>create Project Catch>>' + err2); as
                        if (err2.status == 400 || err2.error == 'E_VALIDATION') {
                            resolve({
                                StatusCode: 400, StatusInfo: {
                                    message: err2.toString(),
                                    info: err2.invalidAttributes,
                                }, result: {}
                            });
                        }
                        reject({
                            StatusCode: 500, StatusInfo: {
                                message: 'project creation faild',
                                info: err2
                            }, result: {}
                        });
                    });

                }).catch(function (err) {
                    reject({
                        StatusCode: 500, StatusInfo: {
                            message: 'project creation faild',
                            info: err
                        }, result: {}
                    });
                });
            } catch (err) {
                reject({
                    StatusCode: 500, StatusInfo: {
                        message: 'project creation faild',
                        info: err
                    }, result: {}
                });
            }

        });
    },
    getProjectByUserId: function (options) {
        return new Promise(function (resolve, reject) {

            try {
                UserProfile.findOne({ id: options.id, isDeleted: false }).then(function (result) {
                    if (!_.isUndefined(result)) {
                        if (result.role == '1') {
                            //management

                            Project.find().populate('membares').populate('tasks').populate('manager').then(function (result2) {
                                resolve({ StatusCode: 200, StatusInfo: { message: 'Sucess', info: {} }, result: result2 });
                            }).catch(function (err) {

                                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });

                            });

                        }
                        if (result.role == '2') {

                            //manager
                            Manager.findOne({ profileId: result.id, isDeleted: false }).then(function (result2) {
                                Project.find({ manager: result2.id }).populate('tasks').populate('membares').then(function (result3) {
                                    resolve({ StatusCode: 200, StatusInfo: { message: 'Sucess', info: {} }, result: result3 });
                                }).catch(function (err) {
                                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                                });

                            }).catch(function (err) {
                                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                            });

                        }

                        if (result.role == '3') {

                            //associate

                            Associate.findOne({ profileId: result.id, isDeleted: false }).populate('Projects').then(function (result2) {

                                var projectIds = _.map(result2.Projects, 'id');

                                Project.find({ id: projectIds }).populate('tasks').populate('membares').populate('manager').then(function (result3) {
                                    resolve({ StatusCode: 200, StatusInfo: { message: 'Sucess', info: {} }, result: result3 });
                                }).catch(function (err) {
                                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                                });

                            }).catch(function (err) {
                                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                            });
                        }
                    }
                    else {
                        resolve({ StatusCode: 400, StatusInfo: { message: 'user id not found in database', info: {} }, result: {} });
                    }
                }).catch(function (err) {
                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                });

            } catch (err) {
                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
            }
        });
    },

    getProjectByProjectId: function (options) {


        return new Promise(function (resolve, reject) {
            try {

                if (_.isUndefined(options)) {
                    resolve({ StatusCode: 400, StatusInfo: { message: 'ProjectId is not provided', info: {} }, result: {} });
                }

                Project.findOne({ id: options.projectId }).populate('tasks').populate('membares').populate('manager').then(function (result) {

                    if (_.isUndefined(result)) {
                        resolve({
                            StatusCode: 400, StatusInfo: { message: 'there is no project with this id', info: {} },
                            result: {}
                        });

                    }
                    else {
                        resolve({
                            StatusCode: 200, StatusInfo: { message: 'sucess', info: {} },
                            result: result
                        });
                    }


                }).catch(function (err) {
                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                });

            } catch (err) {
                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
            }

        });


    },
    createTaskForProjectWithoutUserId: function (options) {
        // to create task for project without user id for assigne task 

        return new Promise(function (resolve, reject) {

            try {
                Project.findOne({ id: options.projectId }).then(function (result) {

                    if (!_.isUndefined(result)) {

                        Task.create({
                            name: options.name,
                            projectId: options.projectId,
                            startDate: options.startDate,
                            endDate: options.endDate
                        }).then(function (result2) {
                            var taskHistory = {};
                            taskHistory.taskId = result2.id;
                            taskHistory.date = Format(new Date(), 'YYYY-MM-DD').toString();
                            taskHistory.userId = result.manager;
                            taskHistory.comments = 'new task created'
                            TaskHistory.create(taskHistory).then(function (result3) {

                                var projectHistory = {};
                                projectHistory.projectId = result.id;
                                projectHistory.dateOfEntry = Format(new Date(), 'YYYY-MM-DD').toString();
                                projectHistory.userId = result.manager;
                                projectHistory.comments = 'new task ' + result2.name + ' is add to the Project';
                                projectHistory.taskId = result2.id;

                                ProjectHistory.create(projectHistory).then(function (re) {
                                    resolve({ StatusCode: 201, StatusInfo: { message: 'sucess', info: {} }, result: result2 });

                                }).catch(function (err) {

                                    resolve({ StatusCode: 207, StatusInfo: { message: 'Task created without updating project history', info: err }, result: result2 });
                                });


                            }).catch(function (err) {
                                resolve({ StatusCode: 207, StatusInfo: { message: 'Task created without updating task and project history history', info: err }, result: result2 });
                            });



                        }).catch(function (err) {

                            if (err.status == 400 || err.error == 'E_VALIDATION') {
                                resolve({
                                    StatusCode: 400, StatusInfo: {
                                        message: err.toString(),
                                        info: err.invalidAttributes,
                                    }, result: {}
                                });
                            }
                            reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                        });


                    }
                    else {

                        resolve({ StatusCode: 400, StatusInfo: { message: 'project id is not valid', info: {} }, result: {} });

                    }
                }).catch(function (err) {

                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                });


            } catch (err) {

                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
            }


        });




    },

    addMemberToProject: async function (options) {

        var responds = {
            StatusCode: 0,
            StatusInfo: {
                message: '',
                info: {}
            },
            result: {}

        };

        try {



            var project = await Project.findOne({ id: options.projectId }).populate('membares');
            if (!_.isUndefined(project)) {

                var associate = await Associate.findOne({ id: options.associateId, isDeleted: false }).populate('profileId');
                if (!_.isUndefined(associate)) {

                    if (_.isArray(project.membares) && project.membares.length) {
                        var membersid = _.map(project.membares, 'id');
                        var isMember = false;

                        for (var id of membersid) {
                            if (id == associate.id) {
                                isMember = true;
                            }

                            if (!isMember) {

                                await Project.addToCollection(project.id, 'membares').members([associate.id]);

                                var projectHistory = {};
                                projectHistory.projectId = project.id;
                                projectHistory.dateOfEntry = Format(new Date(), 'YYYY-MM-DD').toString();
                                projectHistory.userId = project.manager;
                                projectHistory.comments = 'added ' + associate.profileId.name + ' to this project';

                                try {
                                    await ProjectHistory.create(projectHistory);
                                    responds.StatusCode = 200;
                                    responds.StatusInfo.message = 'sucess';
                                    responds.result = project;
                                    return responds;

                                } catch (e) {

                                    responds.StatusCode = 207;
                                    responds.StatusInfo.message = 'useer added without updating Project history';
                                    responds.result = project;
                                    responds.StatusInfo.info = e;
                                    return responds;

                                }




                            } else {

                                responds.StatusCode = 400;
                                responds.StatusInfo.message = 'associate is already added to project';
                                responds.StatusInfo.info = options;
                                return responds;

                            }
                        }

                    } else {

                        await Project.addToCollection(project.id, 'membares').members([associate.id]);

                        var projectHistory = {};
                        projectHistory.projectId = project.id;
                        projectHistory.dateOfEntry = Format(new Date(), 'YYYY-MM-DD').toString();
                        projectHistory.userId = project.manager;
                        projectHistory.comments = 'added ' + associate.profileId.name + ' to this project';

                        try {
                            await ProjectHistory.create(projectHistory);
                            responds.StatusCode = 200;
                            responds.StatusInfo.message = 'sucess';
                            responds.result = project;
                            return responds;

                        } catch (e) {

                            responds.StatusCode = 207;
                            responds.StatusInfo.message = 'useer added without updating Project history';
                            responds.result = project;
                            responds.StatusInfo.info = e;
                            return responds;

                        }


                    }

                } else {
                    responds.StatusCode = 400;
                    responds.StatusInfo.message = 'there is no assocaite with provided associate id';
                    responds.StatusInfo.info = options;
                    return responds;
                }

            } else {

                responds.StatusCode = 400;
                responds.StatusInfo.message = 'there is no project with provided project id';
                responds.StatusInfo.info = options;
                return responds;
            }





        } catch (err) {
            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            };
            return responds;
        }


    },
    getProjectMembersByProjectId: function (options) {

        return new Promise(function (resolve, reject) {

            Project.findOne({ id: options.projectId }).populate('membares').then(function (result) {



                if (!_.isUndefined(result)) {

                    if (_.isArray(result.membares) && result.membares.length) {

                        getAssociteIdListFromProjectMembers(result.membares).then(function (result2) {

                            sails.log.debug('>>>>>>>>>>>>>>>>>> associate ids ' + result2);
                            Associate.find({ id: result2, isDeleted: false }).populate('profileId').then(function (result3) {
                                if (!_.isUndefined(result3)) {
                                    resolve({
                                        StatusCode: 200,
                                        StatusInfo: {
                                            message: "sucess",
                                            info: {}
                                        },
                                        result: result3
                                    });
                                }
                                else {

                                    resolve({
                                        StatusCode: 200,
                                        StatusInfo: {
                                            message: "no members for this project",
                                            info: {}
                                        },
                                        result: {}
                                    });
                                }

                            }).catch(function (err) {

                                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
                            });

                        }).catch(function (err) {
                            reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });

                        });
                    }
                    else {

                        resolve({ StatusCode: 200, StatusInfo: { message: 'No Members so far for this Project', info: {} }, result: {} });
                    }

                }
                else {
                    resolve({ StatusCode: 400, StatusInfo: { message: 'invalid Project Id', info: {} }, result: {} });
                }



            }).catch(function (err) {
                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });

            });



        });


    },
    addMultipleMembersToProject: function (options) {


        return new Promise(function (resolve, reject) {
            try {


                if (!_.isUndefined(options.projectId)) {


                    if (_.isArray(options.associateIds) && options.associateIds.length) {

                        var obj = [];
                        var i = 0;
                        sails.log.debug('>>>>>>>> ' + i + ' >>>>>>>>>>>>>>>>>>>>>>>>>>');
                        while (i == options.associateIds.length) {
                            sails.log.debug('>>>>>>>> ' + i + ' >>>>>>>>>>>>>>>>>>>>>>>>>>');
                            ProjectManagementServices.addMemberToProject({ projectId: options.projectId, associateId: options.associateIds[i] }).then(function (result) {
                                sails.log.debug('>>>>>>>> ' + i + ' ' + result.StatusCode);
                                obj.push(result);
                                i = i + 1;
                                if (i == options.associateId.length - 1) {
                                    resolve({ StatusCode: 200, StatusInfo: { message: '', info: {} }, result: obj });
                                }
                            }).catch(function (err) {
                                i = i + 1;
                                sails.log.debug('>>>>>>>> ' + i + ' ' + result.StatusCode);
                                obj.push(result);
                                if (i == options.associateId.length - 1) {
                                    resolve({ StatusCode: 200, StatusInfo: { message: '', info: {} }, result: obj });
                                }
                            });
                        }
                        // if(obj.length == options.associateIds.length){


                        // }
                        // else{

                        //     reject({StatusCode:500,StatusInfo:{message:'something happend!!!!!',info:obj},result:{}});
                        // }
                    }

                }







            } catch (err) {
                sails.log.debug(">>>>>>>>>>>>>>>>catch 10");
                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
            }
        });




    },
    assigntaskToProjectmember: async function (options) {

        var responds = {
            StatusCode: 0,
            StatusInfo: {
                message: '',
                info: {}
            },
            result: {}

        };

        sails.log.debug('>>>>>[assigntaskToProjectmember] calling this function');

        try {

            var task = await Task.findOne({ id: options.taskId, isTicket: false }).populate('projectId').populate('assignedTo');
            if (!_.isUndefined(task)) {

                var project = await Project.findOne({ id: task.projectId.id }).populate('membares');
                if (!_.isUndefined(project)) {

                    if (_.isArray(project.membares) || project.membares.length) {

                        var projectmembaersid = _.map(project.membares, 'id');
                        var isMember = false;
                        for (var id of projectmembaersid) {

                            if (id == options.associateId) {
                                isMember = true;
                            }

                        }

                        if (isMember) {

                            if (_.isArray(task.assignedTo) || task.assignedTo.length) {

                                var assignedIds = _.map(task.assignedTo, 'id');
                                var isAssiged = false;
                                for (var id of assignedIds) {
                                    if (id == options.associateId) {
                                        isAssiged = true;
                                    }
                                }

                                if (!isAssiged) {

                                    await Task.addToCollection(task.id, 'assignedTo').members([options.associateId]);
                                    var taskHistory = {};
                                    taskHistory.taskId = task.id;
                                    taskHistory.date = Format(new Date(), 'YYYY-MM-DD').toString();
                                    taskHistory.userId = project.manager;
                                    taskHistory.comments = 'task is assigend to the associate with id ' + options.associateId;

                                    try {

                                        await TaskHistory.create(taskHistory);
                                        responds.StatusCode = 200;
                                        responds.StatusInfo.message = 'project member is assigned to this task sucessfully';

                                        responds.result = task;
                                        return responds

                                    } catch (e) {
                                        responds.StatusCode = 207;
                                        responds.StatusInfo.message = 'project member is assigned to this task without updating task history';
                                        responds.StatusInfo.info = e;
                                        responds.result = task;
                                        return responds


                                    }
                                } else {
                                    responds.StatusCode = 400;
                                    responds.StatusInfo.message = 'provided member is already assigned to this task';
                                    responds.StatusInfo.info = options;
                                    return responds
                                }

                            } else {

                                await Task.addToCollection(task.id, 'assignedTo').members([options.associateId]);
                                var taskHistory = {};
                                taskHistory.taskId = task.id;
                                taskHistory.date = Format(new Date(), 'YYYY-MM-DD').toString();
                                taskHistory.userId = project.manager;
                                taskHistory.comments = 'task is assigend to the associate with id ' + options.associateId;

                                try {

                                    await TaskHistory.create(taskHistory);
                                    responds.StatusCode = 200;
                                    responds.StatusInfo.message = 'project member is assigned to this task sucessfully';

                                    responds.result = task;
                                    return responds

                                } catch (e) {
                                    responds.StatusCode = 207;
                                    responds.StatusInfo.message = 'project member is assigned to this task without updating task history';
                                    responds.StatusInfo.info = e;
                                    responds.result = task;
                                    return responds


                                }

                            }

                        } else {
                            responds.StatusCode = 400;
                            responds.StatusInfo.message = 'provided assocaite is not a member of this project';
                            responds.StatusInfo.info = options;
                            return responds
                        }

                    } else {
                        responds.StatusCode = 400;
                        responds.StatusInfo.message = 'there is no associates added to this project yet';
                        responds.StatusInfo.info = options;
                        return responds
                    }

                } else {
                    responds.StatusCode = 400;
                    responds.StatusInfo.message = 'ask DB admin for correctness of data';
                    responds.StatusInfo.info = options;
                    return responds
                }

            } else {
                responds.StatusCode = 400;
                responds.StatusInfo.message = 'there is no task with provided task id';
                responds.StatusInfo.info = options;
                return responds
            }

        } catch (err) {
            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            };
            return responds;
        }
    },
    getTaskDetailsByTaskId: function (options) {

        return new Promise(function (resolve, reject) {
            try {

                Task.findOne({ id: options.taskId }).populateAll().then(function (resulTask) {

                    if (!_.isUndefined(resulTask)) {

                        resolve({

                            StatusCode: 200,
                            StatusInfo: {

                                message: 'sucess',
                                info: {}
                            },
                            result: resulTask

                        });
                    } else {
                        resolve({

                            StatusCode: 404,
                            StatusInfo: {

                                message: 'no such task',
                                info: options
                            },
                            result: {}

                        });
                    }

                }).catch(function (errTask) {

                    reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: errTask }, result: {} });




                });
            } catch (err) {
                reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });
            }
        });




    },
    editProjectDetails: async function (options) {
        try {
            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                }
            };


            var project = await Project.findOne({ id: options.projectId });
            if (!_.isUndefined(project)) {
                if (project.state == 4) {
                    responds.StatusCode = 400;
                    responds.StatusInfo.message = 'you can not edit the project in closed state';
                    responds.StatusInfo.info = options;
                    responds.result = project
                    return responds
                }
                var result = await Project.update({ id: options.projectId }).set({
                    Name: options.Name,
                    desc: options.desc,
                    state: options.state

                }).fetch();

                var projectHistory = {};
                projectHistory.projectId = result[0].id;
                projectHistory.dateOfEntry = Format(new Date(), 'YYYY-MM-DD').toString();
                projectHistory.userId = result[0].manager;
                projectHistory.comments = 'updated the project details name:' + options.Name + ' desc:' + options.desc + ' state:' + options.state;


                try {
                    sails.log.debug('>>>>>>>>>>>>>>>>>>>>>[edit Project details] :' + JSON.stringify(result))
                    if (result[0].state == 3 || result[0].state == 4) {
                        await Task.update({ projectId: result[0].id, isTicket: false }).set({ state: result[0].state });
                        try {

                            await ProjectHistory.create(projectHistory);
                            responds.StatusCode = 200;
                            responds.StatusInfo.message = 'sucess';
                            responds.result = result[0];
                            return responds

                        } catch (e) {
                            responds.StatusCode = 207;
                            responds.StatusInfo.message = 'updated without adding project history';
                            responds.StatusInfo.info = e;
                            responds.result = result[0]
                            return responds
                        }

                    } else {
                        try {

                            await ProjectHistory.create(projectHistory);
                            responds.StatusCode = 200;
                            responds.StatusInfo.message = 'sucess';
                            responds.result = result[0];
                            return responds

                        } catch (e) {
                            responds.StatusCode = 207;
                            responds.StatusInfo.message = 'updated without adding project history';
                            responds.StatusInfo.info = e;
                            responds.result = result[0]
                            return responds
                        }
                    }



                } catch (e2) {


                    try {
                        await Project.update({ id: project.id }).set({
                            Name: project.Name,
                            desc: project.desc,
                            state: project.state

                        }).fetch();
                        responds.StatusCode = 500;
                        responds.StatusInfo.message = 'faild';
                        responds.StatusInfo.info = e2;

                        return responds
                    } catch (e4) {

                        responds.StatusCode = 500;
                        responds.StatusInfo.message = 'inconsistant data writern into database';
                        responds.StatusInfo.info = e4;

                        return responds

                    }


                }
            } else {
                responds.StatusCode = 400;
                responds.StatusInfo.message = 'there is no project with this id';
                responds.StatusInfo.info = options;

                return responds
            }

        } catch (err) {
            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            };
            return responds;
        }

    },
    editTaskDetails: async function (options) {

        try {
            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                }
            };

            var result = await Task.update({ id: options.taskId, isTicket: false }).set({

                name: options.name,
                state: options.state
            });
            try {

                sails.log.debug('>>>>>>>>[editTaskDetails] updated result: ' + JSON.stringify(result));

                var project = await Project.findOne({ id: result[0].projectId });
                var taskHistory = {};
                taskHistory.taskId = result[0].id;
                taskHistory.date = Format(new Date(), 'YYYY-MM-DD').toString();
                taskHistory.userId = project.manager;
                taskHistory.comments = 'task is updated with data name:' + options.name + ' state:' + options.state;
                await TaskHistory.create(taskHistory);
                var projectHistory = {};
                projectHistory.projectId = project.id;
                projectHistory.dateOfEntry = Format(new Date(), 'YYYY-MM-DD').toString();
                projectHistory.userId = project.manager;
                projectHistory.comments = ' task: ' + result[0].id + ' is updated with value name:' + result[0].name;
                projectHistory.taskId = result[0].id;

                await ProjectHistory.create(projectHistory);

                responds.StatusCode = 200;
                responds.StatusInfo.message = 'sucess';

                responds.result = result[0];
                return responds

            } catch (e) {
                sails.log.debug('>>>>>>>>[editTaskDetails] error: ' + JSON.stringify(e))
                responds.StatusCode = 207;
                responds.StatusInfo.message = 'updated without adding project or task history';
                responds.StatusInfo.info = e;
                responds.result = result[0];
                return responds

            }





        } catch (err) {
            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            };
            return responds;
        }

    },
    removMemberFromProject: async function (options) {

        try {

            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                },
            };

            var project = await Project.findOne({ id: options.projectId }).populate('membares').populate('manager');

            if (!_.isUndefined(project)) {

                var tasks = await Task.find({ projectId: project.id, isTicket: false }).populate('assignedTo');
                var canRemove = true;

                if (!_.isUndefined(tasks) && tasks.length && _.isArray(tasks)) {

                    for (var task of tasks) {
                        if (_.isArray(task.assignedTo) || task.assignedTo.length) {

                            var ids = _.map(task.assignedTo, 'id');
                            for (var id of ids) {
                                if (id == options.associateId) {
                                    canRemove = false;
                                }
                            }

                        }
                    }

                    if (canRemove) {

                        if (_.isArray(project.membares) && project.membares.length) {

                            var memberIds = _.map(project.membares, 'id');
                            var canRemove2 = false
                            for (var id of memberIds) {
                                if (id == options.associateId) {
                                    canRemove2 = true;
                                }
                            }

                            if (canRemove2) {

                                await Project.removeFromCollection(project.id, 'membares').members([options.associateId]);
                                var projectHistory = {};
                                projectHistory.projectId = project.id;
                                projectHistory.dateOfEntry = Format(new Date(), 'YYYY-MM-DD').toString();
                                projectHistory.userId = project.manager.id;
                                projectHistory.comments = 'removed a user from project';
                                sails.log.debug('>>>>>>>>>>>>before creating history');
                                //

                                try {

                                    await ProjectHistory.create(projectHistory);
                                    responds.StatusCode = 200;
                                    responds.StatusInfo.message = 'sucess';
                                    responds.result = project;
                                    return responds

                                } catch (e) {

                                    responds.StatusCode = 207;
                                    responds.StatusInfo.message = 'removed without updating the project history';
                                    responds.result = project;
                                    return responds

                                }


                            } else {
                                responds.StatusCode = 400;
                                responds.StatusInfo.message = 'provided associate is not present in this project';
                                responds.StatusInfo.info = options;
                                return responds
                            }

                        } else {

                            responds.StatusCode = 400;
                            responds.StatusInfo.message = 'there is no mamber in this project for remove';
                            responds.StatusInfo.info = options;
                            return responds

                        }




                    } else {

                        responds.StatusCode = 400;
                        responds.StatusInfo.message = 'provided associate is assigned to a task in this project please remove him/her from that task first';
                        responds.StatusInfo.info = options;
                        return responds

                    }



                } else {
                    // task


                    if (_.isArray(project.membares) && project.membares.length) {

                        var memberIds = _.map(project.membares, 'id');
                        var canRemove2 = false
                        for (var id of memberIds) {
                            if (id == options.associateId) {
                                canRemove2 = true;
                            }
                        }

                        if (canRemove2) {

                            await Project.removeFromCollection(project.id, 'membares').members([options.associateId]);
                            var projectHistory = {};
                            projectHistory.projectId = project.id;
                            projectHistory.dateOfEntry = Format(new Date(), 'YYYY-MM-DD').toString();
                            projectHistory.userId = project.manager.id;
                            projectHistory.comments = 'removed a user from project';
                            sails.log.debug('>>>>>>>>>>>>before creating history');
                            //

                            try {

                                await ProjectHistory.create(projectHistory);
                                responds.StatusCode = 200;
                                responds.StatusInfo.message = 'sucess';
                                responds.result = project;
                                return responds

                            } catch (e) {

                                responds.StatusCode = 207;
                                responds.StatusInfo.message = 'removed without updating the project history';
                                responds.result = project;
                                return responds

                            }


                        } else {
                            responds.StatusCode = 400;
                            responds.StatusInfo.message = 'provided associate is not present in this project';
                            responds.StatusInfo.info = options;
                            return responds
                        }

                    } else {

                        responds.StatusCode = 400;
                        responds.StatusInfo.message = 'there is no mamber in this project for remove';
                        responds.StatusInfo.info = options;
                        return responds

                    }








                }




            } else {
                responds.StatusCode = 400;
                responds.StatusInfo.message = 'there is no project with provided project id';
                responds.StatusInfo.info = options;
                return responds
            }













        } catch (err) {
            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}

            };
            return responds;
        }

    },

    removeUserFromTask: async function (options) {

        try {
            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                },
                result: {}

            };


            var task = await Task.findOne({ id: options.taskId, isTicket: false }).populate('assignedTo').populate('projectId');
            if (!_.isUndefined(task)) {

                if (!_.isUndefined(task.assignedTo) && _.isArray(task.assignedTo) && task.assignedTo.length) {

                    var memberIds = _.map(task.assignedTo, 'id');
                    var canremove = false;

                    for (var id of memberIds) {
                        if (id == options.associateId) {
                            canremove = true;
                        }
                    }

                    if (canremove) {

                        await Task.removeFromCollection(task.id, 'assignedTo').members([options.associateId]);
                        try {

                            var taskHistory = {};
                            taskHistory.taskId = task.id;
                            taskHistory.date = Format(new Date(), 'YYYY-MM-DD').toString();
                            taskHistory.userId = task.projectId.manager;
                            taskHistory.comments = 'removed a user from task';
                            await TaskHistory.create(taskHistory);
                            var projectHistory = {};
                            projectHistory.projectId = task.projectId.id;
                            projectHistory.dateOfEntry = Format(new Date(), 'YYYY-MM-DD').toString();
                            projectHistory.userId = task.projectId.manager;
                            projectHistory.comments = 'user is removed from the task ' + task.name;
                            projectHistory.taskId = task.id;

                            await ProjectHistory.create(projectHistory);

                            responds.StatusCode = 200;
                            responds.StatusInfo.message = 'sucess';
                            responds.result = task;
                            return responds



                        } catch (e) {

                            responds.StatusCode = 207;
                            responds.StatusInfo.message = 'user removed fro task sucessfully without updating project or task history';
                            responds.StatusInfo.info = e;
                            responds.result = task;
                            return responds



                        }

                    } else {
                        responds.StatusCode = 400;
                        responds.StatusInfo.message = 'provided associate id is not assigned to this task yet';
                        responds.StatusInfo.info = options;
                        return responds
                    }

                } else {
                    responds.StatusCode = 400;
                    responds.StatusInfo.message = 'there is no one assigned to this task yet';
                    responds.StatusInfo.info = options;
                    return responds
                }



            } else {
                responds.StatusCode = 400;
                responds.StatusInfo.message = 'there is no task with provided task id';
                responds.StatusInfo.info = options;
                return responds
            }

        } catch (err) {
            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}
            };
            return responds;
        }

    },
    creatTicketTask: async function (options) {
        try {
            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                },
                result: {}

            };

            var creatingUserProfile = await UserProfile.findOne({ id: options.loggedInUserId, isDeleted: false });
            var project = await Project.findOne({id:options.projectId}).populate('manager').populate('membares');
            if (!_.isUndefined(creatingUserProfile)) {

                switch (creatingUserProfile.role) {

                    case 1:
                        //creating by management
                        options.superVisor = options.loggedInUserId;

                     
                                     if(!_.isUndefined(project)){
                           

                              

                                    var supervisor = await Management.findOne({ profileId: creatingUserProfile.id, isDeleted:false });
                                    if (!_.isUndefined(supervisor)) {

                                        if (!_.isUndefined(options.associateProfileIds) && _.isArray(options.associateProfileIds) && options.associateProfileIds.length) {


                                            var assocaiteProfile = await UserProfile.find({ id: options.associateProfileIds });

                                            if (assocaiteProfile.length == options.associateProfileIds.length) {

                                                var associateUserProfileIds = _.map(assocaiteProfile, 'id');

                                                var associates = await Associate.find({ profileId: associateUserProfileIds });
                                                if (associates.length == assocaiteProfile.length) {

                                                    var ids = _.map(associates, 'id');
                                                    var ids2 = _.map(project.membares,'id')
                                                    var associateCheack = true;

                                                   var _intersection =  _.intersection(ids2,ids);
                                                   if(_intersection.length && _intersection.length === ids.length){

                                                    var today = new Date(Format(new Date(), 'YYYY-MM-DD'));

                                                    var proejctStartDate = new Date(Format(new Date(project.startDate),'YYYY-MM-DD'));
                                                    var proejctEndDate = new Date(Format(new Date(project.endDate),'YYYY-MM-DD'));

                                                    if(isAfter(today,proejctEndDate)){
                                                        responds.StatusCode = 400;
                                                        responds.StatusInfo.message = 'you cant create ticket today for this project';
                                                        responds.StatusInfo.info = options;
                                                        return responds;
                                                    }
                                                    
                                                    if(isBefore(today,proejctStartDate)){
                                                        responds.StatusCode = 400;
                                                        responds.StatusInfo.message = 'you cant create ticket today for this project';
                                                        responds.StatusInfo.info = options;
                                                        return responds;
                                                    }

                                                    var task = await Task.create({ name: options.title,projectId:project.id,state: 1, isTicket: true, startDate:Format(new Date(), 'YYYY-MM-DD'),endDate:Format(new Date(), 'YYYY-MM-DD') }).fetch();

                                                    try {
                                                        await Task.addToCollection(task.id, 'assignedTo').members(ids);

                                                        var ticket = await Ticket.create({
                                                            project:project.id,
                                                            Title: task.name,
                                                            Task: task.id,
                                                            reportingUser: project.manager.id,
                                                            createdby: 1,
                                                            description: options.description,
                                                            createdbyUser: options.loggedInUserId,
                                                            superVisorUser: options.superVisor,
                                                            createdDate: Format(new Date(), 'YYYY-MM-DD')
                                                        });
                                                        try{
                                                            var followers = [];
                                                            
                                                            for( var id of options.associateProfileIds){
                                                                followers.push(id)
                                                            }

                                                          
                                                            followers.push(project.manager.profileId);
                                                            followers.push(options.superVisor);
                                                            
                                                          await Ticket.addToCollection(ticket.id,'followers').members(followers);

                                                            responds.StatusCode = 200;
                                                            responds.StatusInfo.message = 'sucess';
                                                            responds.resul = ticket
                                                            return responds;
                                                        }catch(e0){

                                                            try{
                                                                await Ticket.destroy({id:ticket.id});
                                                                try{
                                                                    await Task.destroy({ id: task.id });
                                                                    responds.StatusCode = 500;
                                                                    responds.StatusInfo.message = 'faild';
                                                                    responds.StatusInfo.info = e0;
                                                                    return responds;
                                                                }catch(e7){
                                                                    responds.StatusCode = 500;
                                                                    responds.StatusInfo.message = 'wrong data inserted into database';
                                                                    responds.StatusInfo.info = e6;
                                                                    return responds;
                                                                }

                                                            }catch(e6){
                                                                responds.StatusCode = 500;
                                                                responds.StatusInfo.message = 'wrong data inserted into database';
                                                                responds.StatusInfo.info = e6;
                                                                return responds;
                                                            }

                                                           
                                                         
                                                        }

                                                        

                                                    } catch (e) {
                                                        try {
                                                            await Task.destroy({ id: task.id });
                                                            responds.StatusCode = 500;
                                                            responds.StatusInfo.message = 'faild';
                                                            responds.StatusInfo.info = e;
                                                            return responds;


                                                        } catch (e2) {
                                                            responds.StatusCode = 500;
                                                            responds.StatusInfo.message = 'wrong task has been created which has to be deleted task id: ' + task.id + ' task name: ' + task.name;
                                                            responds.StatusInfo.info = e;
                                                            return responds;
                                                        }

                                                    }


                                                } else {
                                                    responds.StatusCode = 400;
                                                    responds.StatusInfo.message = 'there is problem provided associate ids and project members';
                                                    responds.StatusInfo.info = options;
                                                    return responds
                                                }
                                            }else{
                                                responds.StatusCode = 400;
                                                responds.StatusInfo.message = 'there is problem for finding assocaites profile based on the provided profile ids';
                                                responds.StatusInfo.info = options;
                                                return responds
                                            }

                                            } else {
                                                responds.StatusCode = 400;
                                                responds.StatusInfo.message = 'there is problem for finding assocaites profile based on the provided profile ids';
                                                responds.StatusInfo.info = options;
                                                return responds
                                            }




                                        } else {
                                            responds.StatusCode = 400;
                                            responds.StatusInfo.message = 'for create a ticket you shoud select at least one associate';
                                            responds.StatusInfo.info = options;
                                            return responds
                                        }

                                    } else {
                                        responds.StatusCode = 400;
                                        responds.StatusInfo.message = 'super Visor profile is not consistant';
                                        responds.StatusInfo.info = options;
                                        return responds
                                    }

                              
                                }else{

                                    responds.StatusCode = 400;
                                    responds.StatusInfo.message = 'there is no project with provided project id';
                                    responds.StatusInfo.info = options;
                                    return responds

                                }
                           

                     
                        break;
                    case 2:
                        //creating by manager
            

                     
                                     if(!_.isUndefined(project)){
                           

                              if(options.loggedInUserId == project.manager.profileId){

                                    var supervisor = await Management.findOne({ profileId: options.superVisor,isDeleted:false });
                                    if (!_.isUndefined(supervisor)) {

                                        if (!_.isUndefined(options.associateProfileIds) && _.isArray(options.associateProfileIds) && options.associateProfileIds.length) {


                                            var assocaiteProfile = await UserProfile.find({ id: options.associateProfileIds });

                                            if (assocaiteProfile.length == options.associateProfileIds.length) {

                                                var associateUserProfileIds = _.map(assocaiteProfile, 'id');

                                                var associates = await Associate.find({ profileId: associateUserProfileIds });
                                                if (associates.length == assocaiteProfile.length) {

                                                    var ids = _.map(associates, 'id');
                                                    var ids2 = _.map(project.membares,'id')
                                                    var associateCheack = true;

                                                   var _intersection =  _.intersection(ids2,ids);
                                                   if(_intersection.length && _intersection.length === ids.length){

                                                    var today = new Date(Format(new Date(), 'YYYY-MM-DD'));

                                                    var proejctStartDate = new Date(Format(new Date(project.startDate),'YYYY-MM-DD'));
                                                    var proejctEndDate = new Date(Format(new Date(project.endDate),'YYYY-MM-DD'));

                                                    if(isAfter(today,proejctEndDate)){
                                                        responds.StatusCode = 400;
                                                        responds.StatusInfo.message = 'you cant create ticket today for this project';
                                                        responds.StatusInfo.info = options;
                                                        return responds;
                                                    }
                                                    
                                                    if(isBefore(today,proejctStartDate)){
                                                        responds.StatusCode = 400;
                                                        responds.StatusInfo.message = 'you cant create ticket today for this project';
                                                        responds.StatusInfo.info = options;
                                                        return responds;
                                                    }

                                                    var task = await Task.create({ name: options.title,projectId:project.id,state: 1, isTicket: true, startDate:Format(new Date(), 'YYYY-MM-DD'),endDate:Format(new Date(), 'YYYY-MM-DD') }).fetch();

                                                    try {
                                                        await Task.addToCollection(task.id, 'assignedTo').members(ids);

                                                        var ticket = await Ticket.create({
                                                            project:project.id,
                                                            Title: task.name,
                                                            Task: task.id,
                                                            reportingUser: project.manager.id,
                                                            createdby: 2,
                                                            description: options.description,
                                                            createdbyUser: options.loggedInUserId,
                                                            superVisorUser: options.superVisor,
                                                            createdDate: Format(new Date(), 'YYYY-MM-DD')
                                                        });
                                                        try{
                                                            var followers = [];
                                                            
                                                            for( var id of options.associateProfileIds){
                                                                followers.push(id)
                                                            }
                                                            followers.push(project.manager.profileId.toString());
                                                            followers.push(options.superVisor);
                                                            
                                                          await Ticket.addToCollection(ticket.id,'followers').members(followers);

                                                            responds.StatusCode = 200;
                                                            responds.StatusInfo.message = 'sucess';
                                                            responds.resul = ticket
                                                            return responds;
                                                        }catch(e0){

                                                            try{
                                                                await Ticket.destroy({id:ticket.id});
                                                                try{
                                                                    await Task.destroy({ id: task.id });
                                                                    responds.StatusCode = 500;
                                                                    responds.StatusInfo.message = 'faild';
                                                                    responds.StatusInfo.info = e0;
                                                                    return responds;
                                                                }catch(e7){
                                                                    responds.StatusCode = 500;
                                                                    responds.StatusInfo.message = 'wrong data inserted into database';
                                                                    responds.StatusInfo.info = e6;
                                                                    return responds;
                                                                }

                                                            }catch(e6){
                                                                responds.StatusCode = 500;
                                                                responds.StatusInfo.message = 'wrong data inserted into database';
                                                                responds.StatusInfo.info = e6;
                                                                return responds;
                                                            }

                                                           
                                                         
                                                        }

                                                        

                                                    } catch (e) {
                                                        try {
                                                            await Task.destroy({ id: task.id });
                                                            responds.StatusCode = 500;
                                                            responds.StatusInfo.message = 'faild';
                                                            responds.StatusInfo.info = e;
                                                            return responds;


                                                        } catch (e2) {
                                                            responds.StatusCode = 500;
                                                            responds.StatusInfo.message = 'wrong task has been created which has to be deleted task id: ' + task.id + ' task name: ' + task.name;
                                                            responds.StatusInfo.info = e;
                                                            return responds;
                                                        }

                                                    }


                                                } else {
                                                    responds.StatusCode = 400;
                                                    responds.StatusInfo.message = 'there is problem provided associate ids and project members';
                                                    responds.StatusInfo.info = options;
                                                    return responds
                                                }
                                            }else{
                                                responds.StatusCode = 400;
                                                responds.StatusInfo.message = 'there is problem for finding assocaites profile based on the provided profile ids';
                                                responds.StatusInfo.info = options;
                                                return responds;
                                            }

                                            } else {
                                                responds.StatusCode = 400;
                                                responds.StatusInfo.message = 'there is problem for finding assocaites profile based on the provided profile ids';
                                                responds.StatusInfo.info = options;
                                                return responds
                                            }




                                        } else {
                                            responds.StatusCode = 400;
                                            responds.StatusInfo.message = 'for create a ticket you shoud select at least one associate';
                                            responds.StatusInfo.info = options;
                                            return responds
                                        }

                                    } else {
                                        responds.StatusCode = 400;
                                        responds.StatusInfo.message = 'super Visor profile is not consistant';
                                        responds.StatusInfo.info = options;
                                        return responds
                                    }


                                }else{
                                    responds.StatusCode = 400;
                                    responds.StatusInfo.message = 'you can create ticket only for your projects';
                                    responds.StatusInfo.info = options;
                                    return responds
                                }

                              
                                }else{

                                    responds.StatusCode = 400;
                                    responds.StatusInfo.message = 'there is no project with provided project id';
                                    responds.StatusInfo.info = options;
                                    return responds

                                }
                           

                        break;

                    case 3:
                        //createdByAssocaite
                        if(!_.isUndefined(project)){
                            
                           

                              

                            var supervisor = await Management.findOne({ profileId: options.superVisor,isDeleted:false });
                            if (!_.isUndefined(supervisor)) {

                                if (!_.isUndefined(options.associateProfileIds) && _.isArray(options.associateProfileIds) && options.associateProfileIds.length) {


                                    var assocaiteProfile = await UserProfile.find({ id: options.associateProfileIds });

                                    if (assocaiteProfile.length == options.associateProfileIds.length) {

                                        var associateUserProfileIds = _.map(assocaiteProfile, 'id');

                                        var associates = await Associate.find({ profileId: associateUserProfileIds });
                                        if (associates.length == assocaiteProfile.length) {

                                            var ids = _.map(associates, 'id');
                                            var ids2 = _.map(project.membares,'id')
                                            var associateCheack = true;

                                           var _intersection =  _.intersection(ids2,ids);
                                           if(_intersection.length && _intersection.length === ids.length){

                                            var today = new Date(Format(new Date(), 'YYYY-MM-DD'));

                                            var proejctStartDate = new Date(Format(new Date(project.startDate),'YYYY-MM-DD'));
                                            var proejctEndDate = new Date(Format(new Date(project.endDate),'YYYY-MM-DD'));

                                            if(isAfter(today,proejctEndDate)){
                                                responds.StatusCode = 400;
                                                responds.StatusInfo.message = 'you cant create ticket today for this project';
                                                responds.StatusInfo.info = options;
                                                return responds;
                                            }
                                            
                                            if(isBefore(today,proejctStartDate)){
                                                responds.StatusCode = 400;
                                                responds.StatusInfo.message = 'you cant create ticket today for this project';
                                                responds.StatusInfo.info = options;
                                                return responds;
                                            }

                                            var task = await Task.create({ name: options.title,projectId:project.id,state: 1, isTicket: true, startDate:Format(new Date(), 'YYYY-MM-DD'),endDate:Format(new Date(), 'YYYY-MM-DD') }).fetch();

                                            try {
                                                await Task.addToCollection(task.id, 'assignedTo').members(ids);

                                                var ticket = await Ticket.create({
                                                    project:project.id,
                                                    Title: task.name,
                                                    Task: task.id,
                                                    reportingUser: project.manager.id,
                                                    createdby: 3,
                                                    description: options.description,
                                                    createdbyUser: options.loggedInUserId,
                                                    superVisorUser: options.superVisor,
                                                    createdDate: Format(new Date(), 'YYYY-MM-DD')
                                                });
                                                try{
                                                    var followers = [];
                                                    
                                                    for( var id of options.associateProfileIds){
                                                        followers.push(id)
                                                    }
                                                    followers.push(project.manager.profileId);
                                                    followers.push(options.superVisor);
                                                    
                                                  await Ticket.addToCollection(ticket.id,'followers').members(followers);

                                                    responds.StatusCode = 200;
                                                    responds.StatusInfo.message = 'sucess';
                                                    responds.resul = ticket
                                                    return responds;
                                                }catch(e0){

                                                    try{
                                                        await Ticket.destroy({id:ticket.id});
                                                        try{
                                                            await Task.destroy({ id: task.id });
                                                            responds.StatusCode = 500;
                                                            responds.StatusInfo.message = 'faild';
                                                            responds.StatusInfo.info = e0;
                                                            return responds;
                                                        }catch(e7){
                                                            responds.StatusCode = 500;
                                                            responds.StatusInfo.message = 'wrong data inserted into database';
                                                            responds.StatusInfo.info = e6;
                                                            return responds;
                                                        }

                                                    }catch(e6){
                                                        responds.StatusCode = 500;
                                                        responds.StatusInfo.message = 'wrong data inserted into database';
                                                        responds.StatusInfo.info = e6;
                                                        return responds;
                                                    }

                                                   
                                                 
                                                }

                                                

                                            } catch (e) {
                                                try {
                                                    await Task.destroy({ id: task.id });
                                                    responds.StatusCode = 500;
                                                    responds.StatusInfo.message = 'faild';
                                                    responds.StatusInfo.info = e;
                                                    return responds;


                                                } catch (e2) {
                                                    responds.StatusCode = 500;
                                                    responds.StatusInfo.message = 'wrong task has been created which has to be deleted task id: ' + task.id + ' task name: ' + task.name;
                                                    responds.StatusInfo.info = e;
                                                    return responds;
                                                }

                                            }


                                        } else {
                                           
                                            responds.StatusCode = 400;
                                            responds.StatusInfo.message = 'there is problem provided associate ids and project members';
                                            responds.StatusInfo.info = options;
                                            return responds
                                        }
                                    }else{
                                        responds.StatusCode = 400;
                                        responds.StatusInfo.message = 'there is problem for finding assocaites profile based on the provided profile ids';
                                        responds.StatusInfo.info = options;
                                        return responds;
                                    }

                                    } else {
                                        responds.StatusCode = 400;
                                        responds.StatusInfo.message = 'there is problem for finding assocaites profile based on the provided profile ids';
                                        responds.StatusInfo.info = options;
                                        return responds
                                    }




                                } else {
                                    responds.StatusCode = 400;
                                    responds.StatusInfo.message = 'for create a ticket you shoud select at least one associate';
                                    responds.StatusInfo.info = options;
                                    return responds
                                }

                            } else {
                                responds.StatusCode = 400;
                                responds.StatusInfo.message = 'super Visor profile is not consistant';
                                responds.StatusInfo.info = options;
                                return responds
                            }

                      
                        }else{

                            responds.StatusCode = 400;
                            responds.StatusInfo.message = 'there is no project with provided project id';
                            responds.StatusInfo.info = options;
                            return responds

                        }

                        break;
                    default:
                        responds.StatusCode = 400;
                        responds.StatusInfo.message = 'problem with role';
                        responds.StatusInfo.info = options;
                        return responds


                }

            } else {
                responds.StatusCode = 400;
                responds.StatusInfo.message = 'there is no user with provided loggedInUserId id';
                responds.StatusInfo.info = options;
                return responds
            }


        } catch (err) {
            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}
            };
            return responds;

        }
    },
    getListOfTickets: async function (options) {
        try {
            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                },
                result: {}

            };

            var profile = await UserProfile.findOne({ id: options.loggedInUserId, isDeleted: false }).populate('tickets');
            if (!_.isUndefined(profile)) {


                var ticketId = _.map(profile.tickets,'id');
                var tickes = await Ticket.find({ id: ticketId}).populate('reportingUser').populate('createdbyUser').populate('superVisorUser').populate('project');
                           var result =[];
                            for(var ticket of tickes){
                                var task = await Task.findOne({id:ticket.Task}).populate('assignedTo');
                                if(!_.isUndefined(task)){
                                    ticket.Task = task;
                                    result.push(ticket);
                                }


                            }
                           
                          
                            responds.StatusCode = 200;
                            responds.StatusInfo.message = 'sucess';
                            responds.result =  result;
                            return responds



                // switch (profile.role) {
                //     case 1:

                //         var management = await Management.findOne({ profileId: profile.id, isDeleted: false });
                //         if (!_.isUndefined(management)) {
                //             var tickes = await Ticket.find({ superVisorUser: profile.id }).populate('reportingUser').populate('createdbyUser').populate('superVisorUser').populate('project');
                //            var result =[];
                //             for(var ticket of tickes){
                //                 var task = await Task.findOne({id:ticket.Task}).populate('assignedTo');
                //                 if(!_.isUndefined(task)){
                //                     ticket.Task = task;
                //                     result.push(ticket);
                //                 }


                //             }
                           
                          
                //             responds.StatusCode = 200;
                //             responds.StatusInfo.message = 'sucess';
                //             responds.result =  result;
                //             return responds
                //         } else {
                //             responds.StatusCode = 400;
                //             responds.StatusInfo.message = 'logged in user role issue';
                //             responds.StatusInfo.info = options;
                //             return responds
                //         }


                //         break;
                //     case 2:
                //         var manager = await Manager.findOne({ profileId: profile.id, isDeleted: false });
                //         if (!_.isUndefined(manager)) {
                //             var tickes = await Ticket.find({ reportingUser: manager.id }).populate('reportingUser').populate('createdbyUser').populate('superVisorUser').populate('project');
                //             var result =[];
                //             for(var ticket of tickes){
                //                 var task = await Task.findOne({id:ticket.Task}).populate('assignedTo');
                //                 if(!_.isUndefined(task)){
                //                     ticket.Task = task;
                //                     result.push(ticket);
                //                 }


                //             }
                //             responds.StatusCode = 200;
                //             responds.StatusInfo.message = 'sucess';
                //             responds.result = result;
                //             return responds
                //         } else {
                //             responds.StatusCode = 400;
                //             responds.StatusInfo.message = 'logged in user role issue';
                //             responds.StatusInfo.info = options;
                //             return responds
                //         }
                //         break;

                //     case 3:

                //         var assocaites = await Associate.findOne({ profileId: profile.id }).populate('tasks', { where: { isTicket: true } });
                //         if (!_.isUndefined(assocaites)) {

                //             var tasks = assocaites.tasks;
                //             if (!_.isUndefined(tasks) && _.isArray(tasks) && tasks.length) {

                //                 var taskId = _.map(tasks, 'id');

                //                 var tickets = await Ticket.find({ Task: taskId }).populate('reportingUser').populate('createdbyUser').populate('superVisorUser').populate('project');

                //                 responds.StatusCode = 200;
                //                 responds.StatusInfo.message = 'sucess';
                //                 responds.result = tickets;
                //                 return responds





                //             } else {
                //                 responds.StatusCode = 200;
                //                 responds.StatusInfo.message = 'sucess';
                //                 responds.result = [];
                //                 return responds
                //             }

                //         } else {
                //             responds.StatusCode = 400;
                //             responds.StatusInfo.message = 'logged in user role issue';
                //             responds.StatusInfo.info = options;
                //             return responds
                //         }



                //         break;

                //     default:
                //     responds.StatusCode = 400;
                //     responds.StatusInfo.message = 'logged in user role issue';
                //     responds.StatusInfo.info = options;
                //     return responds
                // }

            } else {
                responds.StatusCode = 400;
                responds.StatusInfo.message = 'there is no user available with provided loggedin user ID';
                responds.StatusInfo.info = options;
                return responds
            }




        } catch (e) {

            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: e
                },
                result: {}
            };
            return responds;

        }
    },

    getTicketDetailsByTicketId: async function (options) {
        try {
            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                },
                result: {}

            };


            var ticket = await Ticket.findOne({ id: options.ticketId }).populate('createdbyUser').populate('superVisorUser').populate('reportingUser');

            if (!_.isUndefined(ticket)) {

                delete ticket.chat;
                delete ticket.createdby;

                var task = await Task.findOne({ id: ticket.Task }).populate('assignedTo');
                if (!_.isUndefined(task)) {

                    ticket.assocaites = [];

                    for (var assocaite of task.assignedTo) {

                        var associateProfile = await UserProfile.findOne({ id: assocaite.profileId });
                        if (!_.isUndefined(associateProfile)) {
                            ticket.assocaites.push(associateProfile);
                        }

                    }

                    responds.StatusCode = 200;
                    responds.StatusInfo.message = 'sucess';
                    responds.result = ticket;

                    return responds
                } else {
                    responds.StatusCode = 400;
                    responds.StatusInfo.message = 'there is some problem with this ticket';
                    responds.StatusInfo.info = options;
                    return responds
                }

            } else {

                responds.StatusCode = 400;
                responds.StatusInfo.message = 'there is no ticket with providede id';
                responds.StatusInfo.info = options;
                return responds

            }




        } catch (err) {

            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}
            };
            return responds;

        }

    },

    editTicket:async function(options){
        try{
            var responds = {
                StatusCode: 0,
                StatusInfo: {
                    message: '',
                    info: {}
                },
                result: {}

            };

            var ticket = await Ticket.findOne({id:options.ticketId});
            if(!_.isUndefined(ticket)){

                switch(options.state){
                    case '1':
                    await Task.update({id:ticket.Task}).set({name:options.title});
                       break;
                    case '2':
                    await Task.update({id:ticket.Task}).set({name:options.title,state:4});
                       break;
                    default:
                    responds.StatusCode = 400;
                responds.StatusInfo.message = 'invalid state';
                responds.StatusInfo.info = options;
                return responds

                }
               
               var updateResult= await Ticket.update({id:ticket.id}).set({Title:options.title,description:options.description,state:options.state});
                responds.StatusCode = 200;
                responds.StatusInfo.message = 'sucess';
                responds.result=updateResult;
                return responds

            }else{
                responds.StatusCode = 400;
                responds.StatusInfo.message = 'there is no ticket with providede id';
                responds.StatusInfo.info = options;
                return responds

            }



        }catch (err) {

            var responds = {
                StatusCode: 500,
                StatusInfo: {
                    message: 'faild',
                    info: err
                },
                result: {}
            };
            return responds;

        }
    }

};

var checkProjectMebersForRemoveUserFromProject = function (options) {
    sails.log.debug('>>>>>>[checkProjectMebersForRemoveUserFromProject] :start of function');
    return new Promise(function (resolve, reject) {
        try {
            sails.log.debug('>>>>>>[checkProjectMebersForRemoveUserFromProject] :try start: ' + JSON.stringify(options.associateId));

            options.resultProject.membares.forEach(function (member) {
                if (member.id == options.associateId) {
                    sails.log.debug('>>>>>>[checkProjectMebersForRemoveUserFromProject] for each-->> if:');
                    resolve({ StatusCode: 200, StatusInfo: { message: 'ok', info: {} }, result: options.resultProject });
                }
            });
            sails.log.debug('>>>>>>[checkProjectMebersForRemoveUserFromProject] :end of for each');

            reject({ StatusCode: 400, StatusInfo: { message: 'associate id is not present in the project member list', info: options.resultProject }, result: {} });

        } catch (err) {

            sails.log.debug('>>>>>>[checkProjectMebersForRemoveUserFromProject] :main catch');
            reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: err }, result: {} });

        }
    });
}

var checkTheTaskMemberForRemoveUserFromProject = function (options) {
    sails.log.debug('>>>>>>[checkTheTaskMemberForRemoveUserFromProject] :start of function');
    return new Promise(function (resolve, reject) {
        try {
            sails.log.debug('>>>>>>[checkTheTaskMemberForRemoveUserFromProject] :try start :');

            var tasks = options.resulTask;

            sails.log.debug('>>>>>>[checkTheTaskMemberForRemoveUserFromProject] :starting for each');
            tasks.forEach(function (task) {
                sails.log.debug('>>>>>>[checkTheTaskMemberForRemoveUserFromProject] :start of foreach 2');
                var assignedTo = task.assignedTo;

                assignedTo.forEach(function (associate) {
                    if (associate.id == options.associateId) {

                        reject({ StatusCode: 400, StatusInfo: { message: 'associate assigned to a task in project please remove from there first', info: task }, result: {} });
                    }



                });
                sails.log.debug('>>>>>>[checkTheTaskMemberForRemoveUserFromProject] :end of foreach 2 -->> taskid: ' + task.id);


                resolve({ StatusCode: 200, StatusInfo: { message: 'ok', info: {} }, result: tasks });

            });
            sails.log.debug('>>>>>>[checkTheTaskMemberForRemoveUserFromProject] :ending foreac 1');





        } catch (err) {
            sails.log.debug('>>>>>>[checkTheTaskMemberForRemoveUserFromProject] :main catch ' + JSON.stringify(err));
            reject({ StatusCode: 500, StatusInfo: { message: 'failed', info: JSON.stringify(err) }, result: {} });
        }
    });

}