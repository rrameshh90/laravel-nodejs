// var dateHandler = require('date-fns');
// var isBefore = require('date-fns/is_before');
// var isValid = require('date-fns/is_valid');
// var isEqual = require('date-fns/is_equal');
// var isAfter = require('date-fns/is_after');
// var Format = require('date-fns/format');
// var validate = require('validator');
 var verifier = require('email-verify');
 var infoCodes = verifier.infoCodes;

 //var emailExists = require('email-exists');

// var emailExistence = require('email-existence');
// var emailCheck = require('email-check');
//var quickemailverification = require('quickemailverification').client('184b27e49f720c76916629a65a484e9ac48e771fcc73331ce051c86565f2').quickemailverification();

module.exports = {


validateEmail:function(req,res,next){

try{
var options = req.body;
    if(_.isUndefined(options.email)||_.isNull(options.email)||options.email == ''){
        return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
    }
  //   if(_.isUndefined(options.key)||_.isNull(options.key)||options.key == ''){
  //     return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
  // }


  //////////////////////////////////////////////////////////////////////////
    verifier.verify(options.email, function( err, info ){
        if( err ){ console.log(err);
        
         res.serverError(err);
        }
        else{
          console.log( "Success (T/F): " + info.success );
          console.log( "Info: " + info.info );
       
        
          res.ok(info);


        }
      });
//////////////////////////////////////////////////////////////////////////////////


// console.log('>>>>>>>>>>>>>>>');
// emailExists({ sender: options.email,
//               recipient: options.email })
//     .then(function(result){
//       console.log('>>>>>>>>>>>>>>>');
//       return  res.ok(result);
//     }).catch(function(err){
//       console.log('>>>>>>>>>>>>>>>');
//       return  res.serverError(err);
//     });





/////////////////////////////////////////////////////////////////////////////////

    // var quickemailverification = require('quickemailverification').client(options.key).quickemailverification();
    // quickemailverification.verify(options.email, function (err, response) {
    //   // Print response object 
    //      if(err){
    //       console.log(err);
    //       res.serverError(err);
    //      }
    //   console.log(response);
    //   res.ok(response.body);
    // });

    //     }
    // });
    //================================================================================================================
    // emailCheck("rhls94@gmail.com")
    // .then(function (responds) {
    //   // Returns "true" if the email address exists, "false" if it doesn't. 
    //   return res.ok(responds);
    // })
    // .catch(function (err) {
    //   if (err.message === 'refuse') {
    //     // The MX server is refusing requests from your IP address. 
    //     return res.forbidden(JSON.stringify(err));
    //   } else {
    //     // Decide what to do with other errors. 
    //     return res.serverError(JSON.stringify(err));
    //   }
    // });
    


}catch(err){
   return res.serverError({statusCode:500,statusInfo:{message:err.toString(),info:err},result:{}});
}


}


  

};

