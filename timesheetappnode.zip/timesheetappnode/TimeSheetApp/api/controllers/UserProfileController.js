

/**
 * UserProfileController
 *
 * @description :: Server-side logic for managing Userprofiles
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {




    userLoginValidation: function (req, res, next) {

        try {
            var options = req.body;

            if (_.isUndefined(options.email)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (_.isNull(options.email)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            UserProfileServices.isValidUser({ email: options.email }).then(function (responds) {
                if (responds.StatusCode == 400) {

                    return res.badRequest(responds);
                }
                if (responds.StatusCode == 200) {
                    return res.ok(responds);
                }

            }).catch(function (err) {

                return res.serverError(err);
            });
        } catch (err) {
            console.log(err);
            return res.serverError(err);
        }

    },
    getProfileDetilsByProfileId: function (req, res, next) {

        try {
            var options = req.body;

            if (_.isUndefined(options.profileId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (_.isNull(options.profileId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            UserProfileServices.getProfileDetailsWithProfileId({ profileId: options.profileId }).then(function (responds) {
                if (responds.StatusCode == 400) {

                    return res.badRequest(responds);
                }
                if (responds.StatusCode == 200) {
                    return res.ok(responds);
                }

            }).catch(function (err) {

                return res.serverError(err);
            });
        } catch (err) {
            console.log(err);
            return res.serverError(err);
        }

    },
    createUserProfile: function (req, res, next) {
        try {
            var options = req.body;




            if (_.isUndefined(options.email) || _.isUndefined(options.name) || _.isUndefined(options.loggedInUser) || _.isUndefined(options.designation)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (_.isNull(options.email) || _.isNull(options.name) || _.isNull(options.loggedInUser) || _.isNull(options.designation)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (options.name == '' || options.loggedInUser == '' || options.designation == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (options.role != '1') {
                if (options.role != '2') {
                    if (options.role != '3') {
                        return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requested for wrong user role', info: options }, result: {} });
                    }
                }
            }
            var ps = UserProfileServices.isAdmin({ email: options.loggedInUser }).then(function (responds) {
                if (responds.StatusCode == 401) {

                    return res.forbidden(responds);
                } else if (responds.StatusCode == 404) {
                    return res.badRequest(responds);
                }
                if (responds.StatusCode == 200) {
                    UserProfileServices.createUserProfile({
                        email: options.email,
                        name: options.name,
                        role: options.role,
                        designation: options.designation
                    }).then(function (result) {
                        if (!_.isUndefined(result)) {

                            if (result.StatusCode == 400) {
                                return res.badRequest(result);
                            }
                            return res.created(result);
                        }
                    }, function (err) {

                        return res.serverError(err);
                    });
                }

            }, function (err) {
                return res.serverError(err);
            });
        } catch (err) {
            console.log(err);
            return res.serverError(err);
        }

    },
    getAllAssociate: function (req, res, next) {


        try {

            UserProfileServices.getAssociates().then(function (result) {
                return res.ok(result);
            }).catch(function (err) {
                return res.serverError(err);
            });


        } catch (err) {
            return res.serverError(({ StatusCode: 500, StatusInfo: { message: err.toString(), info: err }, result: {} }));
        }


    },
    getAllUsers: function (req, res, next) {

        try {
            UserProfileServices.getAllEmployess().then(function (result) {

                return res.ok(result);

            }).catch(function (err) {
                return res.serverError(err);
            });

        } catch (err) {

        }




    },
    getAssociatesById: function (req, res, next) {

        try {


            var options = req.body;

            if (_.isUndefined(options.loggedInUserId) || _.isNull(options.loggedInUserId) || options.loggedInUserId == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });

            }
            UserProfileServices.getAssociateById(options).then(function (result) {

                if (result.StatusCode == 404) {

                    sails.log.debug(JSON.stringify(result))
                    return res.notFound(result);



                } else {
                    sails.log.debug(JSON.stringify(result))
                    return res.ok(result);
                }
            }).catch(function (err) {
                return res.serverError(err);
            });







        } catch (err) {
            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });
        }



    },

    editUserDetails: async function (req, res, next) {

        try {
            var options = req.body;

            if (_.isUndefined(options.name) || _.isUndefined(options.email) || _.isUndefined(options.designation) || _.isUndefined(options.profileIdToEdit)) {
                sails.log.debug('>>>>>>>>1');
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });

            }
            if (options.name == '' || options.email == '' || options.designation == '' || options.profileIdToEdit == '') {
                sails.log.debug('>>>>>>>>2');
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });

            }

            if (_.isNull(options.name) || _.isNull(options.email) || _.isNull(options.designation) || _.isNull(options.profileIdToEdit)) {
                sails.log.debug('>>>>>>>>3');
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });

            }
            var responds = await UserProfileServices.editUserDetails(options);

            if (responds.StatusCode == 200 || responds.StatusCode == 207) {
                return res.ok(responds);
            } else if (responds.StatusCode == 400) {
                return res.badRequest(responds);
            } else if (responds.StatusCode == 500) {
                return res.serverError(responds);
            } else {
                return next();
            }





        } catch (err) {
            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });
        }

    },

    softDeletUser: async function (req, res, next) {

        try {

            var options = req.body;

            if (_.isUndefined(options.profileIdToDelete) || _.isNull(options.profileIdToDelete) || options.profileIdToDelete == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }


            var responds = await UserProfileServices.softDeletUser(options);

            if (responds.StatusCode == 200 || responds.StatusCode == 207) {
                return res.ok(responds);
            } else if (responds.StatusCode == 400) {
                return res.badRequest(responds);
            } else if (responds.StatusCode == 500) {
                return res.serverError(responds);
            } else {
                return next();
            }




        } catch (err) {
            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });
        }



    },
    reStoreUser: async function (req, res, next) {

        try {

            var options = req.body;

            if (_.isUndefined(options.profileEmailToReStore) || _.isNull(options.profileEmailToReStore) || options.profileEmailToReStore == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }



            var responds = await UserProfileServices.restoreUser(options);

            if (responds.StatusCode == 200 || responds.StatusCode == 207) {
                return res.ok(responds);
            } else if (responds.StatusCode == 400) {
                return res.badRequest(responds);
            } else if (responds.StatusCode == 500) {
                return res.serverError(responds);
            } else {
                return next();
            }

        } catch (err) {
            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });
        }



    },
    editUserRole: async function (req, res, next) {

        try {

            var options = req.body;

            if (_.isUndefined(options.email) || _.isNull(options.email) || options.email == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (_.isUndefined(options.role) || _.isNull(options.role) || options.role == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }


            switch (options.role) {
                case '1':
                    var responds = await UserProfileServices.editRole(options);
                    break;
                case '2':
                    var responds = await UserProfileServices.editRole(options);
                    break;
                case '3':
                    var responds = await UserProfileServices.editRole(options);
                    break;
                default:
                    return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });

            }



            if (responds.StatusCode == 200 || responds.StatusCode == 207) {
                return res.ok(responds);
            } else if (responds.StatusCode == 400) {
                return res.badRequest(responds);
            } else if (responds.StatusCode == 500) {
                return res.serverError(responds);
            } else {
                return next();
            }

        } catch (err) {
            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });
        }



    }



};

