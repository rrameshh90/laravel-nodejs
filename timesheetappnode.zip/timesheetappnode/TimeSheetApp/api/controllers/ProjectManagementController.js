var dateHandler = require('date-fns');
var isBefore = require('date-fns/is_before');
var isValid = require('date-fns/is_valid');
var isEqual = require('date-fns/is_equal');
var isAfter = require('date-fns/is_after');
var Format = require('date-fns/format');

module.exports = {





    createBasicProject: function (req, res, next) {

        try {
            var options = req.body;

            var todayString = new Date().toUTCString().split(" ").slice(0, 4).join(" ");
            var today = new Date(todayString);
            //var today = new Date(Format(new Date(),'YYYY-MM-DD'));
            console.log(today + ' inside createBasicProject contrller action');


            if (_.isUndefined(options.Name) || _.isUndefined(options.desc) || _.isUndefined(options.loggedInUserId) || _.isUndefined(options.startDate) || _.isUndefined(options.endDate)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (_.isNull(options.Name) || _.isNull(options.desc) || _.isNull(options.loggedInUserId) || _.isNull(options.startDate) || _.isNull(options.endDate)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (options.Name == '' || options.loggedInUserId == '' || options.desc == '' || options.startDate == '' || options.endDate == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            var projectStartDate = new Date(options.startDate);
            var projectEndDate = new Date(options.endDate);
            console.log(projectStartDate);
            console.log(projectEndDate);

            console.log('>>>>>>>>project start date valid = ' + isValid(projectStartDate));
            console.log('>>>>>>>>project end date valid = ' + isValid(projectStartDate));
            console.log('>>>>>>>>project start date is before today = ' + isBefore(projectStartDate, today));
            console.log('>>>>>>>>project end date is before today = ' + isBefore(projectEndDate, today));
            console.log('>>>>>>>>project end date is before start date = ' + isBefore(projectEndDate, projectStartDate));
            console.log('>>>>>>>>project start date equel end date = ' + isEqual(projectStartDate, projectEndDate));

            if (!isValid(projectStartDate) || !isValid(projectEndDate) ||
                isBefore(projectStartDate, today) || isBefore(projectEndDate, today) ||
                isBefore(projectEndDate, projectStartDate) || isEqual(projectStartDate, projectEndDate)) {

                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'start date or end  is not valid', info: options }, result: {} });
            }

            var ps = UserProfileServices.isManager({ id: options.loggedInUserId }).then(function (responds) {
                if (responds.StatusCode == 401) {

                    return res.forbidden(responds);
                } else if (responds.StatusCode == 404) {
                    return res.badRequest(responds);
                }
                if (responds.StatusCode == 200) {
                    ProjectManagementServices.createBasicProject({
                        Name: options.Name,
                        desc: options.desc,
                        startDate: Format(projectStartDate, 'YYYY-MM-DD'),
                        endDate: Format(projectEndDate, 'YYYY-MM-DD'),
                        manager: options.loggedInUserId
                    }).then(function (result) {
                        console.log('created project');
                        if (!_.isUndefined(result)) {
                            if (result.StatusCode == 400) {
                                return res.badRequest(result);
                            }

                            return res.created(result);
                        }
                    }, function (err) {

                        return res.serverError(err);
                    });
                }

            }, function (err) {
                return res.serverError(err);
            });
        } catch (err) {
            console.log(err);
            return res.serverError(err);
        }

    },

    getProjectByUserId: function (req, res, next) {
        try {
            var options = req.body;

            if (options.id == '' || _.isUndefined(options.id) || _.isNull(options.id)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            ProjectManagementServices.getProjectByUserId(options).then(function (result) {
                res.ok(result);
            }).catch(function (err) {

                res.serverError(err);

            });
        } catch (err) {
            res.serverError(err);
        }


    },

    createTaskWithoutMember: function (req, res, next) {
        try {
            var options = req.body;

            if (_.isUndefined(options.name) || _.isUndefined(options.projectId) || _.isUndefined(options.startDate) || _.isUndefined(options.endDate)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            if (_.isNull(options.name) || _.isNull(options.projectId) || _.isNull(options.startDate) || _.isNull(options.endDate)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            if (options.name == '' || options.projectId == '' || options.startDate == '' || options.endDate == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }



            ProjectManagementServices.getProjectByProjectId({ projectId: options.projectId }).then(function (result) {
                if (result.StatusCode == 400) {
                    return res.badRequest(result);
                }
                var startDate = new Date(options.startDate);
                var endDate = new Date(options.endDate);

                console.log('>>create>>input startDate >>' + startDate);
                console.log('>>create>>input endDate >>' + endDate);
                var projectStartDate = new Date(Format(new Date(result.result.startDate), 'YYYY-MM-DD'));
                var projectEndDate = new Date(Format(new Date(result.result.endDate), 'YYYY-MM-DD'));
                console.log('>>create>>input ProstartDate >>' + projectStartDate);
                console.log('>>create>>input ProendDate >>' + projectEndDate);
                console.log('>>create>>input ProstartDate real >>' + result.result.startDate);
                console.log('>>create>>input ProendDate real >>' + result.result.endDate);

                if (!isValid(startDate) || !isValid(endDate) || isBefore(endDate, startDate) ||
                    isBefore(startDate, projectStartDate) ||
                    isAfter(startDate, projectEndDate) || isAfter(endDate, projectEndDate) || isBefore(endDate, projectStartDate)) {
                    return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'start date or end date is not valid', info: options }, result: {} });
                }

                options.startDate = Format(startDate, 'YYYY-MM-DD');
                options.endDate = Format(endDate, 'YYYY-MM-DD');

                ProjectManagementServices.createTaskForProjectWithoutUserId(options).then(function (result2) {
                    if (result2.StatusCode == 400) {
                        return res.badRequest(result2);
                    }
                    return res.created(result2);

                }).catch(function (err) {

                    return res.serverError(err);

                });
            }).catch(function (err) {
                return res.serverError(err);
            });

        } catch (err) {
            return res.serverError(err);
        }





    },

    addMemberToProject: async function (req, res, next) {

        try {
            var options = req.body;
            console.log(options)

            if (options.projectId == '' || options.associateId == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            if (_.isUndefined(options.projectId) || _.isUndefined(options.associateId)) {

                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            if (_.isNull(options.projectId) || _.isNull(options.associateId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            var responds = await ProjectManagementServices.addMemberToProject({ projectId: options.projectId, associateId: options.associateId });

            if (responds.StatusCode == 200 || responds.StatusCode == 207) {
                return res.ok(responds);
            } else if (responds.StatusCode == 400) {
                return res.badRequest(responds);
            } else if (responds.StatusCode == 500) {
                return res.serverError(responds);
            } else {
                return next();
            }



        } catch (err) {
            return res.serverError(err);
        }


    },
    getProjectByProjectId: function (req, res, next) {

        try {
            var options = req.body;

            if (options.projectId == '' || _.isUndefined(options.projectId) || _.isNull(options.projectId)) {

                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            ProjectManagementServices.getProjectByProjectId(options).then(function (result) {


                if (result.StatusCode == 400) {
                    return res.badRequest(result);
                }

                return res.ok(result);

            }).catch(function (err) {
                return res.serverError(err);
            });
        } catch (err) {
            return res.serverError(err);
        }
    },
    getProjectMembersByProjectId: function (req, res, next) {

        try {
            var options = req.body;

            if (options.projectId == '' || _.isUndefined(options.projectId) || _.isNull(options.projectId)) {

                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });

            }

            ProjectManagementServices.getProjectMembersByProjectId(options).then(function (result) {

                if (result.StatusCode == 400) {
                    return res.badRequest(result);
                }
                if (result.StatusCode == 200) {
                    return res.ok(result);
                } else {
                    next();
                }

            }).catch(function (err) {

                return res.serverError(err);
            });


        } catch (err) {

            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });
        }




    },
    assignAssociateToTask: async function (req, res, next) {

        try {

            var options = req.body;
            if (_.isUndefined(options.taskId) || _.isNull(options.taskId) || options.taskId == '') {

                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });

            }

            if (_.isUndefined(options.associateId) || _.isNull(options.associateId) || options.associateId == '') {

                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            var responds = await ProjectManagementServices.assigntaskToProjectmember(options);

            if (responds.StatusCode == 200 || responds.StatusCode == 207) {
                return res.ok(responds);
            } else if (responds.StatusCode == 400) {
                return res.badRequest(responds);
            } else if (responds.StatusCode == 500) {
                return res.serverError(responds);
            } else {
                return next();
            }



        } catch (err) {

            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: options
                },
                result: {}
            });
        }



    },
    addMultipleMembersToProject: function (req, res, next) {
        try {

            var options = req.body;
            if (options.projectId == '' || _.isUndefined(options.projectId) || _.isNull(options.projectId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            if (options.associateIds == '' || !_.isArray(options.associateIds) || !options.associateIds.length || _.isUndefined(options.associateIds)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            ProjectManagementServices.addMultipleMembersToProject(options).then(function (result) {

                if (result.StatusCode == 400) {
                    res.badRequest(result);
                }
                else if (result.StatusCode == 200 || result.StatusCode == 207) {
                    res.ok(result);
                }
                else {
                    return next();
                }


            }).catch(function (err) {

                res.serverError(err);

            });


        } catch (err) {
            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });
        }
    },
    getTaskDatilsByTaskId: function (req, res, next) {

        try {


            var options = req.body;

            if (_.isUndefined(options.taskId) || _.isNull(options.taskId) || options.taskId == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });

            }
            ProjectManagementServices.getTaskDetailsByTaskId(options).then(function (result) {

                if (result.StatusCode == 404) {

                    sails.log.debug(JSON.stringify(result))
                    return res.notFound(result);



                } else {
                    sails.log.debug(JSON.stringify(result))
                    return res.ok(result);
                }
            }).catch(function (err) {
                return res.serverError(err);
            });







        } catch (err) {
            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });
        }



    },
    editProjectDetails: async function (req, res, next) {

        try {

            var options = req.body;

            if (_.isUndefined(options.Name) || _.isUndefined(options.desc) || _.isUndefined(options.state) || _.isUndefined(options.projectId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (_.isNull(options.Name) || _.isNull(options.desc) || _.isNull(options.state) || _.isNull(options.projectId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            if (options.Name == '' || options.desc == '' || options.state == '' || options.projectId == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }


            var responds = await ProjectManagementServices.editProjectDetails(options);

            if (responds.StatusCode == 200 || responds.StatusCode == 207) {
                return res.ok(responds);
            } else if (responds.StatusCode == 400) {
                return res.badRequest(responds);
            } else if (responds.StatusCode == 500) {
                return res.serverError(responds);
            } else {
                return next();
            }




        } catch (err) {
            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });
        }

    },
    editTaskDetails: async function (req, res, next) {
        try {

            var options = req.body;

            if (_.isUndefined(options.name) || _.isUndefined(options.state) || _.isUndefined(options.taskId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (_.isNull(options.name) || _.isNull(options.state) || _.isNull(options.taskId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            if (options.name == '' || options.state == '' || options.taskId == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }


            var responds = await ProjectManagementServices.editTaskDetails(options);

            if (responds.StatusCode == 200 || responds.StatusCode == 207) {
                return res.ok(responds);
            } else if (responds.StatusCode == 400) {
                return res.badRequest(responds);
            } else if (responds.StatusCode == 500) {
                return res.serverError(responds);
            } else {
                return next();
            }


        } catch (err) {
            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });

        }
    },
    removMemberFromProject: async function (req, res, next) {
        try {
            var options = req.body;
            if (_.isUndefined(options.associateId) || _.isUndefined(options.projectId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (_.isNull(options.associateId) || _.isNull(options.projectId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            if (options.associateId == '' || options.projectId == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }


            var responds = await ProjectManagementServices.removMemberFromProject(options);

            if (responds.StatusCode == 200 || responds.StatusCode == 207) {
                return res.ok(responds);
            } else if (responds.StatusCode == 400) {
                return res.badRequest(responds);
            } else if (responds.StatusCode == 500) {
                return res.serverError(responds);
            } else {
                return next();
            }





        } catch (err) {

            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });

        }
    },

    removeUserFromTask: async function (req, res, next) {
        try {
            var options = req.body;
            if (_.isUndefined(options.associateId) || _.isUndefined(options.taskId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (_.isNull(options.associateId) || _.isNull(options.taskId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            if (options.associateId == '' || options.taskId == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }


            var responds = await ProjectManagementServices.removeUserFromTask(options);

            if (responds.StatusCode == 200 || responds.StatusCode == 207) {
                return res.ok(responds);
            } else if (responds.StatusCode == 400) {
                return res.badRequest(responds);
            } else if (responds.StatusCode == 500) {
                return res.serverError(responds);
            } else {
                return next();
            }

        } catch (err) {

            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });

        }
    },
    creatTicketTask: async function (req, res, next) {
        try {
            var options = req.body;
            if (_.isUndefined(options.description) || _.isUndefined(options.loggedInUserId) || _.isUndefined(options.superVisor) || _.isUndefined(options.projectId) || _.isUndefined(options.associateProfileIds)
                || _.isUndefined(options.title)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (_.isNull(options.loggedInUserId) || _.isNull(options.description) || _.isNull(options.superVisor) || _.isNull(options.projectId) || _.isNull(options.associateProfileIds)
                || _.isNull(options.title)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            if (options.loggedInUserId == '' || options.description == '' || options.superVisor == '' || options.projectId == '' || options.associateProfileIds == ''
                || options.title == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }


            if (!_.isArray(options.associateProfileIds) && options.associateProfileIds.length == 0) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }


            var responds = await ProjectManagementServices.creatTicketTask(options);

            if (responds.StatusCode == 200 || responds.StatusCode == 207) {
                return res.ok(responds);
            } else if (responds.StatusCode == 400) {
                return res.badRequest(responds);
            } else if (responds.StatusCode == 500) {
                return res.serverError(responds);
            } else {
                return next();
            }

        } catch (err) {

            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });

        }
    },
    getListOfTickets: async function (req, res, next) {
        try {
            var options = {};

            options.loggedInUserId = req.param('loggedInUserId');
            if (_.isUndefined(options.loggedInUserId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (_.isNull(options.loggedInUserId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            if (options.loggedInUserId == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }





            var responds = await ProjectManagementServices.getListOfTickets(options);

            if (responds.StatusCode == 200 || responds.StatusCode == 207) {
                return res.ok(responds);
            } else if (responds.StatusCode == 400) {
                return res.badRequest(responds);
            } else if (responds.StatusCode == 500) {
                return res.serverError(responds);
            } else {
                return next();
            }

        } catch (err) {

            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });

        }
    },
    getTicketDetailsByTicketId: async function (req, res, next) {
        try {
            var options = {};

            options.ticketId = req.param('ticketId');
            if (_.isUndefined(options.ticketId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (_.isNull(options.ticketId)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            if (options.ticketId == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }





            var responds = await ProjectManagementServices.getTicketDetailsByTicketId(options);

            if (responds.StatusCode == 200 || responds.StatusCode == 207) {
                return res.ok(responds);
            } else if (responds.StatusCode == 400) {
                return res.badRequest(responds);
            } else if (responds.StatusCode == 500) {
                return res.serverError(responds);
            } else {
                return next();
            }

        } catch (err) {

            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });

        }
    },
    editTicket: async function (req, res, next) {
        try {
            var options = req.body;

            if (_.isUndefined(options.ticketId)||_.isUndefined(options.title)||_.isUndefined(options.description)||_.isUndefined(options.state)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }
            if (_.isNull(options.ticketId)||_.isNull(options.title)||_.isNull(options.description)||_.isNull(options.state)) {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }

            if (options.ticketId == ''||options.title == ''||options.description == ''||options.state == '') {
                return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
            }





            var responds = await ProjectManagementServices.editTicket(options);

            if (responds.StatusCode == 200 || responds.StatusCode == 207) {
                return res.ok(responds);
            } else if (responds.StatusCode == 400) {
                return res.badRequest(responds);
            } else if (responds.StatusCode == 500) {
                return res.serverError(responds);
            } else {
                return next();
            }

        } catch (err) {

            return res.serverError({
                StatusCode: 500,
                StatusInfo: {
                    message: err.toString(),
                    info: err
                },
                result: {}
            });

        }
    }
};

