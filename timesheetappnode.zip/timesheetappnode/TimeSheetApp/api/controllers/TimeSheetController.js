var dateHandler = require('date-fns');
var isBefore = require('date-fns/is_before');
var isValid = require('date-fns/is_valid');
var isEqual = require('date-fns/is_equal');
var isAfter = require('date-fns/is_after');
var Format = require('date-fns/format');

module.exports = {

saveTimeSheetEntry:function(req,res,next){
    try{
            
             var options = req.body;
             

             if (_.isUndefined(options.timeSheetEntries)) {
                
                res.badRequest({
                    StatusCode: 400,
                    StatusInfo: {
                        message: 'reqierd fields are missing',
                        info: options
                    },
                    result: {}
                });
                
                
                
            }

            TimeSheetServices.saveSingleTimeSheetEntries(options).then(function(result){
                res.ok(result);
            }).catch(function(errResult){
                res.serverError(errResult);
            });





    }catch(err){
        return res.serverError(err);
    }
},
getSavedTimeSheet:function(req,res,next){
    try{
         
        var options = req.body;
             

        if (_.isUndefined(options.loggedInUserId)) {
           
           res.badRequest({
               StatusCode: 400,
               StatusInfo: {
                   message: 'reqierd fields are missing',
                   info: options
               },
               result: {}
           });
           
           
           
       }

       TimeSheetServices.getSavedTimeSheetEntry(options).then(function(result){
           if(result.StatusCode == 400){
               return res.badRequest(result);
           }
           res.ok(result);
       }).catch(function(errResult){
           res.serverError(errResult);
       });






    }catch(err){
        return res.serverError(err);
    }
},
editSavedTimeSheet:function(req,res,next){
    try{

        var options = req.body;

        if(_.isUndefined(options)||_.isUndefined(options.associateId)||_.isUndefined(options.entryId)||
          _.isUndefined(options.comments)||_.isUndefined(options.hours)){
           return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
          }
        
          if(_.isNull(options)||_.isNull(options.associateId)||_.isNull(options.entryId)||
          _.isNull(options.comments)||_.isNull(options.hours)){
           return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
          }      

          if(options==''||options.associateId==''||options.entryId==''||
         options.comments==''||options.hours==''){
           return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
          }


          TimeSheetServices.editSavedTimeSheet(options).then(function(result){

            if(result.StatusCode == 400){
                return res.badRequest(result);
            }
            res.ok(result);

          }).catch(function(err){
            return res.serverError(err);
          });

    }catch(err){
        return res.serverError(err);
    }
},
deleteTimeSheetEntry:function(req,res,next){
    try{

        var options = req.body;
        

        if(_.isUndefined(options)||_.isUndefined(options.entryId)||_.isUndefined(options.associateId)){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });

        }
        if(_.isNull(options)||_.isNull(options.entryId)||_.isNull(options.associateId)){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });

        }
        if(options==''||options.entryId==''||options.associateId==''){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });

        }

        TimeSheetServices.deleteTimeSheetEntry(options).then(function(result){
            if(result.StatusCode == 400){
                return res.badRequest(result);
            }
            res.ok(result);

        }).catch(function(err){
            return res.serverError(err);

        });

      

    }catch(err){

        return res.serverError(err);

    }
},
submitTimeSheet:function(req,res,next){
try{

    var options = req.body;
    if(_.isUndefined(options)||_.isUndefined(options.entryId)||_.isUndefined(options.associateId)){
        return res.badRequest({
            StatusCode: 400,
            StatusInfo: {
                message: 'reqierd fields are missing',
                info: options
            },
            result: {}
        });
    }
    if(_.isNull(options)||_.isNull(options.entryId)||_.isNull(options.associateId)){
        return res.badRequest({
            StatusCode: 400,
            StatusInfo: {
                message: 'reqierd fields are missing',
                info: options
            },
            result: {}
        });
    }
    if(options == ''||options.entryId==''||options.associateId==''){
        return res.badRequest({
            StatusCode: 400,
            StatusInfo: {
                message: 'reqierd fields are missing',
                info: options
            },
            result: {}
        });
    }

    TimeSheetServices.submitTimeSheet(options).then(function(result){
        if(result.StatusCode == 400){
            return res.badRequest(result);
        }

        
        res.ok({
            StatusCode: 200,
            StatusInfo: {
                message: 'sucess',
                info: options
            },
            result: {}
        });

    }).catch(function(err){
        return res.serverError(err);
    });

}catch(err){
    
    return res.serverError(err);
}
},
getSubmittedTimeSheet:function(req,res,next){
    try{

        var options = {};

         options.loggedInUserId = req.param('loggedInUserId');
        if(_.isUndefined(options)||_.isUndefined(options.loggedInUserId)||_.isNull(options.loggedInUserId)||options.loggedInUserId==''){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }

        TimeSheetServices.getSubmittedTimeSheet(options).then(function(result){
            if(result.StatusCode == 400){
                return res.badRequest(result);
            }
            res.ok(result);
    
        }).catch(function(err){
            return res.serverError(err);
        });

    }catch(err){
        return res.serverError(err);
    }
},
approveSubmittedTimeSheets:async function(req,res,next){
    try{

         var options = req.body;
         if(_.isUndefined(options)||_.isUndefined(options.timesheetIds)||_.isNull(options.timesheetIds)||options.timesheetIds==''){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }

        var responds = await TimeSheetServices.approveSubmittedTimeSheets(options);

        if(responds.StatusCode == 200 ||responds.StatusCode == 207 ){
                    return res.ok(responds);
        }else if(responds.StatusCode == 400){
            return res.badRequest(responds);
        }else if(responds.StatusCode == 500){
            return res.serverError(responds);
        }else{
            return req.ok('222');
        }         

           
    
         


    }catch(err){
        return res.serverError(err);
    }
},
rejectSubmittedTimeSheets:async function(req,res,next){
    try{

         var options = req.body;
         if(_.isUndefined(options)||_.isUndefined(options.timesheetIds)||_.isNull(options.timesheetIds)||options.timesheetIds==''){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }

        if(_.isUndefined(options.comments)||_.isNull(options.comments)||options.comments==''){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }

        var responds = await TimeSheetServices.rejectSubmittedTimeSheets(options);

        if(responds.StatusCode == 200 ||responds.StatusCode == 207 ){
                    return res.ok(responds);
        }else if(responds.StatusCode == 400){
            return res.badRequest(responds);
        }else if(responds.StatusCode == 500){
            return res.serverError(responds);
        }else{
            return next();
        }         

           
    
         


    }catch(err){
        return res.serverError(err);
    }
},
getApprovedTimeSheetEntryByAssociate:async function(req,res,next){
    try{
        var options = {};

        options.profileId = req.param('profileId');
         if(_.isUndefined(options)||_.isUndefined(options.profileId)||_.isNull(options.profileId)||options.profileId==''){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }

        var responds = await TimeSheetServices.getApprovedTimeSheetEntryByAssociate(options);

        if(responds.StatusCode == 200 ||responds.StatusCode == 207 ){
                    return res.ok(responds);
        }else if(responds.StatusCode == 400){
            return res.badRequest(responds);
        }else if(responds.StatusCode == 500){
            return res.serverError(responds);
        }else{
            return next();
        }        

    }catch(err){
        return res.serverError(err);
    }
},
getRejectedTimeSheetEntryByAssociate:async function(req,res,next){
    try{
        var options = {};

        options.profileId = req.param('profileId');
         if(_.isUndefined(options)||_.isUndefined(options.profileId)||_.isNull(options.profileId)||options.profileId==''){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }

        var responds = await TimeSheetServices.getRejectedTimeSheetEntryByAssociate(options);

        if(responds.StatusCode == 200 ||responds.StatusCode == 207 ){
                    return res.ok(responds);
        }else if(responds.StatusCode == 400){
            return res.badRequest(responds);
        }else if(responds.StatusCode == 500){
            return res.serverError(responds);
        }else{
            return next();
        }        

    }catch(err){
        return res.serverError(err);
    }
},
saveTimeSheetForTicket:async function(req,res,next){
    try{
        var options = req.body;

        
         if(_.isUndefined(options)|| _.isUndefined(options.ticketId)||_.isUndefined(options.associateId)||_.isUndefined(options.entryDate)||_.isUndefined(options.hours)||_.isUndefined(options.comments)){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }
        if(_.isNull(options)|| _.isNull(options.ticketId)||_.isNull(options.associateId)||_.isNull(options.entryDate)||_.isNull(options.hours)||_.isUndefined(options.comments)){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }
        if(options == ''|| options.ticketId==''||options.associateId==''||options.entryDate==''||options.hours==''||options.comments==''){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }

        var responds = await TimeSheetServices.saveTimeSheetForTicket(options);

        if(responds.StatusCode == 200 ||responds.StatusCode == 207||responds.StatusCode == 201 ){
                    return res.ok(responds);
        }else if(responds.StatusCode == 400){
            return res.badRequest(responds);
        }else if(responds.StatusCode == 500){
            return res.serverError(responds);
        }else{
            return next();
        }        

    }catch(err){
        return res.serverError(err);
    }
},
resubmitRejectedTimeSheet:async function(req,res,next){
    try{
        var options = req.body;

        
         if(_.isUndefined(options)|| _.isUndefined(options.timeSheetId)||_.isUndefined(options.associateId)||_.isUndefined(options.hours)||_.isUndefined(options.comments)){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }
        if(_.isNull(options)|| _.isNull(options.timeSheetId)||_.isNull(options.associateId)||_.isNull(options.hours)||_.isUndefined(options.comments)){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }
        if(options == ''|| options.timeSheetId==''||options.associateId==''||options.hours==''||options.comments==''){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }

        var responds = await TimeSheetServices.resubmitRejectedTimeSheet(options);

        if(responds.StatusCode == 200 ||responds.StatusCode == 207||responds.StatusCode == 201 ){
                    return res.ok(responds);
        }else if(responds.StatusCode == 400){
            return res.badRequest(responds);
        }else if(responds.StatusCode == 500){
            return res.serverError(responds);
        }else{
            return next();
        }        

    }catch(err){
        return res.serverError(err);
    }
},
deletRejectedTimeSheet:async function(req,res,next){
    try{
        var options = req.body;

        
         if(_.isUndefined(options)|| _.isUndefined(options.timeSheetId)||_.isUndefined(options.associateId)){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }
        if(_.isNull(options)|| _.isNull(options.timeSheetId)||_.isNull(options.associateId)){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }
        if(options == ''|| options.timeSheetId==''||options.associateId==''){
            return res.badRequest({
                StatusCode: 400,
                StatusInfo: {
                    message: 'reqierd fields are missing',
                    info: options
                },
                result: {}
            });
        }

        var responds = await TimeSheetServices.deletRejectedTimeSheet(options);

        if(responds.StatusCode == 200 ||responds.StatusCode == 207||responds.StatusCode == 201 ){
                    return res.ok(responds);
        }else if(responds.StatusCode == 400){
            return res.badRequest(responds);
        }else if(responds.StatusCode == 500){
            return res.serverError(responds);
        }else{
            return next();
        }        

    }catch(err){
        return res.serverError(err);
    }
}





};

