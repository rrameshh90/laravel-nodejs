module.exports = {
    datastore:'TimeSheet_TimeSheet',
   attributes: {
          timeSheetId:{

            model:'timesheetentries'
          },
          submittedDate:{
            type:"string",
            columnType:'date',
          }

          
           }
 };