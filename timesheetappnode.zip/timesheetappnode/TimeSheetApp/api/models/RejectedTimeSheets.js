module.exports = {
    datastore:'TimeSheet_TimeSheet',
   attributes: {
          submittedTimeSheetId:{

            model:'timesheetentries'
          },
          rejectedDate:{
            type:"string",
            columnType:'date',
          },
          rejectedBy:{
              model:'manager',
          },
          commentsBymanager:{
              type:'string'
          },
          reSubmitted:{
              type:'boolean',   
              defaultsTo:false
              
          }
          

          
           }
 };