

module.exports = {
    datastore:'TimeSheet_Project_ManagementMongo',
   attributes: {
          message:{
              type:'string',
              required:true
          },
         user:{
             model:'userprofile'
         },
         ticket:{
             model:'ticket'
         }
          
           }
 };
 
 