

module.exports = {
    datastore:'TimeSheet_Project_ManagementMongo',
   attributes: {
          
    manager:{
        model:'manager'
    },
    membares:{
        collection:'associate',
        via:'teams'
    }
    }
          
           
 };
 
 