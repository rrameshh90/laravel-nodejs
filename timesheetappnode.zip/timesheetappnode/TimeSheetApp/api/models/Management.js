

module.exports = {
    datastore:'TimeSheet_User_ProfileMongo',
   attributes: {
    
    profileId :{
        model:'userprofile',
        unique:true
    },
    Managers:{
        collection:'manager'
    },
    isDeleted:{
        type:'boolean',
        defaultsTo:false
     }
           }
 };
 
 