

module.exports = {
    datastore:'TimeSheet_User_ProfileMongo',
   attributes: {
             
           profileId :{
               model:'userprofile',
               unique:true
           },
           Projects:{
                collection:'project',
                via:'membares',
                //dominant: true
           },
           teams:{
               collection:'team',
               via:'membares',
               dominant: true
           },
           tasks:{
              collection:'task',
              via:'assignedTo',
              dominant:true
           },
           isDeleted:{
            type:'boolean',
            defaultsTo:false
         }
 
          
           }
 };
 
 