/**
 * UserProfile.js
 *
 * @description :: TODO: You might write a short summary of how this model works and what it represents here.
 * @docs        :: http://sailsjs.org/documentation/concepts/models-and-orm/models
 */

module.exports = {
  datastore:'TimeSheet_User_ProfileMongo',
  attributes: {
           email:{
             type:'string',
             unique:true,
            
             isEmail:true,
             required:true
           
          },
          name:{
            type:'string',
            required:true
          },
          designation:{
            type:'string',
            required:true
          },
          role:{
            type:'number',
            isIn: [1,2,3],
            defaultsTo:3
          },
          isDeleted:{
             type:'boolean',
             defaultsTo:false
          },
          tickets:{
            collection:'ticket',
            via:'followers'
          }
        

         
          }
};

