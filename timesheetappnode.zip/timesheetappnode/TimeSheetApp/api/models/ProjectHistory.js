

module.exports = {
    datastore:'TimeSheet_Project_ManagementMongo',
   attributes: {
          projectId:{
              model:'project'
          },
          dateOfEntry:{
                    
            type:"string",
            columnType:'date',
          },
          userId:{
              model:'userprofile'
        
              
          },
          comments:{
              type:'string'
          },
          taskId:{
                 model:'task'
          }
          
           }
 };
 
 