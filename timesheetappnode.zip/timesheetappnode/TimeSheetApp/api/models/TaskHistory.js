

module.exports = {
    datastore:'TimeSheet_Project_ManagementMongo',
   attributes: {
         taskId:{
             model:'task'
         },
         date:{
            type:"string",
            columnType:'date',
         },
         comments:{
             type:'string'
         },
        userId:{
            model:'userprofile'
        }
          
           }
 };
 
 