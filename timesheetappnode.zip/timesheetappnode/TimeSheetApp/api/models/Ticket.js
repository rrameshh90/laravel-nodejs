

module.exports = {
    datastore:'TimeSheet_Project_ManagementMongo',
   attributes: {
       project:{
        model:'project'
       },
          Title:{
              type:'string',
              required:true
          },
          description:{
            type:'string',
            required:true
          },
          Task:{
              model:'task'
          },
          state:{
              type:'number',
            isIn: [1, 2],
            defaultsTo: 1
          },
          reportingUser:{
              model:'manager'
          },
          createdby:{
              type:'number',
              isIn:[1,2,3],
              defaultsTo:3
          },
          createdbyUser:{
              model:'userprofile'
          },
          superVisorUser:{
                  model:'userprofile'
          },
          createdDate:{
              type:'string',
              columnType:'date'
          },
          endDate:{
            type:'string',
            columnType:'date'
          },
          followers:{
              collection:'userprofile',
              via:'tickets'
          },
        
          chat:{
              collection:'ticketchat',
              via:'ticket'
          }
          
           }

 };
 
 