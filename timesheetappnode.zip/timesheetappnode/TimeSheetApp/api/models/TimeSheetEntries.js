module.exports = {
    datastore:'TimeSheet_TimeSheet',
   attributes: {
          ProjectId:{
              model:'project',
              
          },
          hours:{
              type:'number',
              columnType:'float',
              min:0.0,
              max:24.0
          },

          TaskId:{
              model:'task'
          },
          DateAndTime:{
            type:'string',
            columnType:'date',
          },
          comments:{
              type:'string'
          },
          associateId:{
              model:'associate'
          },
          approvelManager:{
              model:'manager'
          },
          isSubmitted:{
              type:'boolean',
              defaultsTo:false
          },
          isApproved:{
              type:'boolean',
              defaultsTo:false
          },
          isRejected:{
            type:'boolean',
            defaultsTo:false
          },
          isTicket:{
            type:'boolean',
            defaultsTo:false
          },
          ticket:{
              model:'ticket'
          }

          
           }
 };