

module.exports = {
    datastore:'TimeSheet_Project_ManagementMongo',
   attributes: {
          name:{
              type:'string',
              required:true
          },
          projectId:{
              model:'project'
          },
          assignedTo:{
              collection:'associate',
              via:'tasks'
          },
          
          startDate:{
            type:"string",
            columnType:'date',
          }, 
          endDate:{
            type:"string",
            columnType:'date',
          },
          state:{
              type:'number',
            isIn: [1, 2, 3,4,5],
            defaultsTo: 1
          },
          taskHistory:{
            
            collection:'taskhistory',
            
            via:'taskId'
            
          } ,
          isTicket:{
            type:'boolean',
            defaultsTo: false
          }
          
           }
 };
 
 