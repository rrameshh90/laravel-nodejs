module.exports = {
    datastore:'TimeSheet_TimeSheet',
   attributes: {
          submittedTimeSheetId:{

            model:'timesheetentries'
          },
          approvedDate:{
              type:'string',
              columnType:'date'
          },
          approvedBy:{
              model:'manager'
          }

          
           }
 };