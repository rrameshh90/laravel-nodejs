


module.exports = {
    datastore:'TimeSheet_Project_ManagementMongo',
   attributes: {
          
          Name:{
              type:'string',
              required:true
          },
          desc:{
              type:'string',
              required:true
          },
          manager:{
            model:'manager'
          },
          tasks:{
              collection:'task',
              via:'projectId'
              
          },
          membares:{
               collection:'associate',
               via:'Projects'
          },
        
          startDate:{
            type:"string",
            columnType:'date',
            required:true
          },
          endDate:{
            type:"string",
            columnType:'date',
            required:true
          },
          state:{
              type:'number',
              isIn:[1,2,3,4],
              defaultsTo:1
          },
          projectHistory:{
              collection:'projecthistory',
              via:'projectId'
          }
          
           }
 };
 
 