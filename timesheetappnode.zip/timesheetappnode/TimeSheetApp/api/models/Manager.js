

module.exports = {
    datastore:'TimeSheet_User_ProfileMongo',
   attributes: {
    
    profileId :{
        model:'userprofile',
        unique:true
    },
    Projects:{
         collection:'project',
         via:'manager',
        
    },
    teams:{
        collection:'team',
        via:'manager'
    },
    isDeleted:{
        type:'boolean',
        defaultsTo:false
     }
          
           }
 };
 
 