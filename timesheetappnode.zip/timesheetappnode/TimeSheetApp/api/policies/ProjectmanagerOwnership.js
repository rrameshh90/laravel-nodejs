module.exports = function (req, res, next) {
    try {
     
      var options = req.body;
      if (_.isUndefined(options.loggedInUserId) || _.isNull(options.loggedInUserId) || options.loggedInUserId == '') {
  
        return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
      }
      if (_.isUndefined(options.projectId) || _.isNull(options.projectId) || options.projectId == '') {
  
        return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
      }
          
          Manager.findOne({profileId:options.loggedInUserId, isDeleted:false}).then(function(result){
               if(!_.isUndefined(result)){
                  
                     Project.findOne({id:options.projectId,manager:result.id}).then(function(result2){
                      
                        if(!_.isUndefined(result2)){
                             return next();
                        }else{
                            return res.forbidden({ StatusCode: 401, StatusInfo: { message: 'logged in user have not owned the project', info: options }, result: {} });
                        }



                     }).catch(function(err){

                     });

                 
               }else{
                return res.forbidden({ StatusCode: 401, StatusInfo: { message: 'logged in user is not manager', info: options }, result: {} });
               }
          }).catch(function(err){

          });

     
    } catch (err) {
      return res.serverError(err);
    }
  
    // User is not allowed
    // (default res.forbidden() behavior can be overridden in `config/403.js`)
  
  };