module.exports = function (req, res, next) {
    try {
     
      var options = req.body;
      if (_.isUndefined(options.loggedInUserId) || _.isNull(options.loggedInUserId) || options.loggedInUserId == '') {
  
        return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
      }
      if (_.isUndefined(options.taskId) || _.isNull(options.taskId) || options.taskId == '') {
  
        return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
      }
          
          Manager.findOne({profileId:options.loggedInUserId, isDeleted:false}).then(function(result){
               if(!_.isUndefined(result)){
                  
                     Task.findOne({id:options.taskId}).populate('projectId').then(function(result2){
                      
                        if(!_.isUndefined(result2)){
                             if(result2.projectId.manager == result.id){
                                 return next();
                             }else{
                                return res.forbidden({ StatusCode: 401, StatusInfo: { message: 'task is not owned by this user', info: options }, result: {} });

                             }
                        }else{
                            return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'ther is no such a task', info: options }, result: {} });
                        }



                     }).catch(function(err){

                     });

                 
               }else{
                return res.forbidden({ StatusCode: 401, StatusInfo: { message: 'logged in user is not manager', info: options }, result: {} });
               }
          }).catch(function(err){

          });

     
    } catch (err) {
      return res.serverError(err);
    }
  
    // User is not allowed
    // (default res.forbidden() behavior can be overridden in `config/403.js`)
  
  };