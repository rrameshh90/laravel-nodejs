module.exports = function (req, res, next) {
    try {
      var options = req.body;
      console.log('>>>>>>> in management or manager policy function');
      sails.log.info('>>>>>>>>>>>>>>>>>> '+JSON.stringify(options));
      if (_.isUndefined(options.loggedInUserId) || _.isNull(options.loggedInUserId) || options.loggedInUserId == '') {
                     sails.log.debug('>>>>>>>>');
        return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
      }
  
    
      UserProfileServices.isAdminById({ id: options.loggedInUserId }).then(function (responds2) {
        if (responds2.StatusCode == 401) {

            return res.forbidden({ StatusCode: 401, StatusInfo: { message: ' logged in user is not in role managment',
             info: {} }, result: {}});
        }else if(responds2.StatusCode == 404){
            return res.badRequest(responds2);
        }
        if (responds2.StatusCode == 200) {
            return next();
        }

    }, function (err) {
        return res.serverError(err);
    });
    } catch (err) {
      return res.serverError(err);
    }
  
    // User is not allowed
    // (default res.forbidden() behavior can be overridden in `config/403.js`)
  
  };