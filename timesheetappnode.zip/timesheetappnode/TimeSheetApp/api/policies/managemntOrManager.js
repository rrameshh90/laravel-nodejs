module.exports = function (req, res, next) {
    try {
      var options = req.body;
      console.log('>>>>>>> in management or manager policy function');
      sails.log.info('>>>>>>>>>>>>>>>>>> '+options);
      if (_.isUndefined(options.loggedInUserId) || _.isNull(options.loggedInUserId) || options.loggedInUserId == '') {
  
        return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
      }
  
      UserProfileServices.isManager({ id: options.loggedInUserId }).then(function (responds) {
        
        sails.log.info(responds);
        if (responds.StatusCode == 401) {

            UserProfileServices.isAdminById({ id: options.loggedInUserId }).then(function (responds2) {
                if (responds2.StatusCode == 401) {

                    return res.forbidden({ StatusCode: 401, StatusInfo: { message: ' logged in user is not in role managment or manager',
                     info: {} }, result: {}});
                }else if(responds2.StatusCode == 404){
                    return res.badRequest(responds2);
                }
                if (responds2.StatusCode == 200) {
                    return next();
                }

            }, function (err) {
                return res.serverError(err);
            });


          
        }
        else if(responds.StatusCode == 404){
          return res.badRequest(responds);
        }
        if (responds.StatusCode == 200) {
          return next();
        }
      }).catch(function (err) {
  
        return res.forbidden(err);
      });
    } catch (err) {
      return res.serverError(err);
    }
  
    // User is not allowed
    // (default res.forbidden() behavior can be overridden in `config/403.js`)
  
  };