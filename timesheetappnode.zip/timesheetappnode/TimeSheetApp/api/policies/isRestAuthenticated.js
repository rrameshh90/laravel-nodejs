module.exports = function(req, res, next) {

    var header=req.headers['authorization']||'',        // get the header
      token=header.split(/\s+/).pop()||'',            // and the encoded auth token
      auth=new Buffer(token, 'base64').toString(),    // convert from base64
      parts=auth.split(/:/),                          // split on colon
      username=parts[0],
      password=parts[1];

      if(_.isUndefined(header)){
        return res.forbidden({ StatusCode: 401, StatusInfo: { message: 'You are not permitted to perform this action', info: options }, result: {} });
             }

      if(username == 'NUIT'&& password=='welcome-123'){
          return next();
      }
  
    // User is not allowed
    // (default res.forbidden() behavior can be overridden in `config/403.js`)
    return res.forbidden({ StatusCode: 401, StatusInfo: { message: 'You are not permitted to perform this action', info: options }, result: {} });
  };