module.exports = function (req, res, next) {
    try {
      console.log('in is manager policy');
      var options = req.body;
      if (_.isUndefined(options.loggedInUserId) || _.isNull(options.loggedInUserId) || options.loggedInUserId == '') {
  
        return res.badRequest({ StatusCode: 400, StatusInfo: { message: 'requierd inputs are missing', info: options }, result: {} });
      }
  
      UserProfileServices.isAssociateByid({ id: options.loggedInUserId }).then(function (responds) {
       
                 
        if (responds.StatusCode == 400) {
             
             return res.forbidden(responds);
        }
       
        if (responds.StatusCode == 200) {
          req.body.associateId = responds.result.id;
         
          return next();
        }
      }).catch(function (err) {
  
        return res.forbidden(err);
      });
    } catch (err) {
      return res.serverError(err);
    }
  
    // User is not allowed
    // (default res.forbidden() behavior can be overridden in `config/403.js`)
  
  };