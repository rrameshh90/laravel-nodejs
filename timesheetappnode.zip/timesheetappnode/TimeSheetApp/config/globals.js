/**
 * THIS FILE WAS ADDED AUTOMATICALLY by the Sails 1.0 app migration tool.
 * The original file was backed up as `config/globals-old.js.txt`
 */

 module.exports.globals = {

   _: require('lodash'),

   async: require('async'),

   models: true,

   sails: true

 };
