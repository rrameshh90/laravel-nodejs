// config/swagger.js
module.exports.swagger = {
    /**
     * require() the package.json file for your Sails app.
     */
    pkg: require('../package'),
    ui: {
      url: 'http://swagger.balderdash.io'
    }
  };