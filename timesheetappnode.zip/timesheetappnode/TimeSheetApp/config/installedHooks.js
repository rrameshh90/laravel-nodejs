module.exports.installedHooks = {
    'sails-swagger': {
      'name': 'swagger'
    }
  };