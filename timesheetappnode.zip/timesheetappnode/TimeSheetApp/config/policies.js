

/**
 * Policy Mappings
 * (sails.config.policies)
 *
 * Policies are simple functions which run **before** your controllers.
 * You can apply one or more policies to a given controller, or protect
 * its actions individually.
 *
 * Any policy file (e.g. `api/policies/authenticated.js`) can be accessed
 * below by its filename, minus the extension, (e.g. "authenticated")
 *
 * For more information on how policies work, see:
 * http://sailsjs.org/#!/documentation/concepts/Policies
 *
 * For more information on configuring policies, check out:
 * http://sailsjs.org/#!/documentation/reference/sails.config/sails.config.policies.html
 */


module.exports.policies = {

  /***************************************************************************
  *                                                                          *
  * Default policy for all controllers and actions (`true` allows public     *
  * access)                                                                  *
  *                                                                          *
  ***************************************************************************/

  '*': ['isRestAuthenticated'],

  /***************************************************************************
  *                                                                          *
  * Here's an example of mapping some policies to run before a controller    *
  * and its actions                                                          *
  *                                                                          *
  ***************************************************************************/
 Swagger:{
   '*':true
 },
	// RabbitController: {
    ProjectManagementController:{
		// Apply the `false` policy as the default for all of RabbitController's actions
		// (`false` prevents all access, which ensures that nothing bad happens to our rabbits)
    // '*': false,
    
   '*':false,
   getProjectByUserId:true,
   createBasicProject : ['isManager'],
    createTaskWithoutMember: ['isManager'],
    addMemberToProject: ['isManager'],
    getProjectByProjectId:true,
   
    getProjectMembersByProjectId:['isManager','ProjectmanagerOwnership'],
    addMultipleMembersToProject:['isManager'],
    assignAssociateToTask:['isManager'],
    getTaskDatilsByTaskId:true,
    editProjectDetails:['isManager','ProjectmanagerOwnership'],
    editTaskDetails:['isManager','TaskmanagerOwnerShip'],
    removMemberFromProject:['isManager','ProjectmanagerOwnership'],
    removeUserFromTask:['isManager','TaskmanagerOwnerShip'],
    creatTicketTask:true,
    getListOfTickets:true,
    getTicketDetailsByTicketId:true,
    editTicket:true,

  },
  UserProfileController:{


    '*':false,
    getAllAssociate:['managemntOrManager'],
    userLoginValidation:true,
    createUserProfile:['isAdmin'],
    getAllUsers:true,
    getAssociatesById:true,
    getProfileDetilsByProfileId:true,
    editUserDetails:['isAdmin'],
    softDeletUser:['isAdmin'],
    reStoreUser:['isAdmin'],
    editUserRole:['isAdmin']

    

  },

  TimeSheetController:{
    '*':false,
    saveTimeSheetEntry:true,
    getSavedTimeSheet:['isAssociate'],
    editSavedTimeSheet:['isAssociate'],
    deleteTimeSheetEntry:['isAssociate'],
    submitTimeSheet:['isAssociate'],
    getSubmittedTimeSheet:true,
    approveSubmittedTimeSheets:['isManager'],
    rejectSubmittedTimeSheets:['isManager'],
    getApprovedTimeSheetEntryByAssociate:true,
    getRejectedTimeSheetEntryByAssociate:true,
    saveTimeSheetForTicket:true,
    resubmitRejectedTimeSheet:['isAssociate'],
    deletRejectedTimeSheet:['isAssociate'],
  }
		// For the action `nurture`, apply the 'isRabbitMother' policy
		// (this overrides `false` above)
		// nurture	: 'isRabbitMother',

		// Apply the `isNiceToAnimals` AND `hasRabbitFood` policies
		// before letting any users feed our rabbits
		// feed : ['isNiceToAnimals', 'hasRabbitFood']
	// }
};
