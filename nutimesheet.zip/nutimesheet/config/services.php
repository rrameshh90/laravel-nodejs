<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Stripe, Mailgun, SparkPost and others. This file provides a sane
    | default location for this type of information, allowing packages
    | to have a conventional place to find your various credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
    ],

    'ses' => [
        'key' => env('SES_KEY'),
        'secret' => env('SES_SECRET'),
        'region' => 'us-east-1',
    ],

    'sparkpost' => [
        'secret' => env('SPARKPOST_SECRET'),
    ],

    'stripe' => [
        'model' => App\User::class,
        'key' => env('STRIPE_KEY'),
        'secret' => env('STRIPE_SECRET'),
    ],
	/*  ramesh.rajamani@nutechnologyinc.com -- Google developer Console Details
    'google' => [
    'client_id' => '965192330723-i6tkr3rqkhqrmokqal70tlg2p3l912h3.apps.googleusercontent.com',         // Your google Client ID
    'client_secret' => 'n3zLA4VtziTpltAmVzjU0nuG', // Your google Client Secret
    'redirect' => 'http://nu.timesheet.com/login/google/callback/',
    //'redirect' => 'http://crm.nutechnologyinc.com:8600/login/google/callback/',
    //'redirect' => 'http://apps.nutechnologyinc.com:8600/login/google/callback/',
	*/
	
	/*  971o350266@gmail.com -- Google developer Console Details  pwd- welcome-123 */
    'google' => [
    'client_id' => '679303070940-ensl4loeq85c7f8djqi3gqpi01b9ksp5.apps.googleusercontent.com',         // Your google Client ID
    'client_secret' => '6m9x2oOXk8_I-8fafahIvjEM', // Your google Client Secret
    'redirect' => 'http://nu.timesheet.com/login/google/callback/',
    //'redirect' => 'http://crm.nutechnologyinc.com:8600/login/google/callback/',
    //'redirect' => 'http://apps.nutechnologyinc.com:8600/login/google/callback/',
],

];
