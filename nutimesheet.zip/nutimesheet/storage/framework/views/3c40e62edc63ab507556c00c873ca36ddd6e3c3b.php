<?php $__env->startSection('title', 'Timesheet  User List'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	Employee List Page
	<small></small>
	</h1>
	<ol class="breadcrumb">
	<li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
	<li class="active">Timesheet User List Page</li>
	</ol>
</section>
 <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-xs-12">
			<div class="box">		
				<?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				 <?php if(Session::has($key)): ?>
				 <div class="alert alert-<?php echo e($key); ?> alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong> <?php echo e(Session::get($key)); ?></strong>
				 </div>
				 <?php endif; ?>
			   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			 <div class="box-header">
              <h3 class="box-title">Timesheet  User List</h3>
              </div>
     <div class="box-body" id="userlistparentdiv">     
		  
		<?php if(!empty($timesheetassociatelist)){
			foreach($timesheetassociatelist as $list){ ?>
		<div class="col-md-6">
          <!-- Widget: user widget style 1 -->
          <div class="box box-widget widget-user-2">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <!-- bk color class -- bg-yellow -->
         
            <div class="widget-user-header">
              <div class="widget-user-image">
                <img class="img-circle" src="<?php echo e(asset('Admin/dist/img/usericon.png')); ?>" alt="User Avatar">
              </div>
              <!-- /.widget-user-image -->
              <h3 class="widget-user-username"><?php echo $list['profileId']['name'];?></h3>
              <h5 class="widget-user-email"><?php echo $list['profileId']['email'];?></h5>
              <h5 class="widget-user-designation"><?php echo $list['profileId']['designation'];?></h5>
              <div class="pull-right user-action">
               <a href="<?php echo "/associatetimesheetdetails/".$list['profileId']['id'];?>" title="View Timesheet" class="userview"><i class="fa fa-fw fa-eye"></i>&nbsp; View Timesheet</a>
			 </div>
            </div>
          </div>
         
          <!-- /.widget-user -->
        </div>
        <?php 
        }
        }?>
      </div>
     </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>