<!-- Edit Task Modal -->
			<div class="modal right fade" id="<?php echo "updatetaskmodal".$task['result']['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
						<div class="modal-dialog" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<h4 class="modal-title" id="addtaskLabel1">Task Updation</h4>
								</div>
								<div class="modal-body">
									<div class="row">
											<!-- left column -->
											<div class="col-md-12">
											  <!-- general form elements -->
	
										<div class="card">
										<ul class="nav nav-tabs" role="tablist">
											<li role="presentation" class="active"><a href="<?php echo "#updatetask".$task['result']['id'];?>" aria-controls="updatetask" role="tab" data-toggle="tab">Update Task</a></li>
											<li role="presentation"><a href="<?php echo "#addmembertask".$task['result']['id'];?>" aria-controls="addmembertask" role="tab" data-toggle="tab">Add Member</a></li>
											<li role="presentation"><a href="<?php echo "#removemembertask".$task['result']['id'];?>" aria-controls="removemembertask" role="tab" data-toggle="tab">Remove Member</a></li>
										</ul>

										<!-- Tab panes Start-->
										<div class="tab-content">
										<div role="tabpanel" class="tab-pane active" id="<?php echo "updatetask".$task['result']['id'];?>">
											<!--Task Update Start-->
											<div class="box box-primary">
												<!-- /.box-header -->
												<!-- form start -->
												<form role="form" method="POST" action="/updatetaskdetails" id="updatetaskform">
													 <?php echo e(csrf_field()); ?>

												  <div class="box-body">
													 <input type="hidden" name="task_id" value="<?php echo e($task['result']['id']); ?>" id="task_id"></input>
													 <input type="hidden" name="loggedin_id" value="<?php echo e(Session::get('userdetails.id')); ?>" id="loggedin_id"></input>
													 <input type="hidden" name="task_projectid" value="<?php echo e($project_data['id']); ?>" id="task_projectid"></input>
													 <div class="form-group">
													  <label for="InputTaskname">Task Name<span class="red">*</span></label>
													  <input type="text" name="task_name" class="form-control" id="InputTaskname" placeholder="Task Name"  value="<?php echo $task['result']['name']; ?>" required>
													 </div>
													<!-- Add Select Field for Status -->
													<?php if(!empty($task['result']['state'])){ echo HelperController::getEditTaskstatus($task['result']['state']);}?>
													<!-- Add Select Field for Status -->
													<!-- Display Selected User -->
													<div class="form-group">
													<label for="exampleInputFile">Assigned user Info</label>
														<?php if(!empty($task['result']['assignedTo'])){
														  $assignusers=array();
														  foreach($task['result']['assignedTo'] as $index => $assign){
																$assignusers[]=TaskManageController::getAssignName($assign['profileId']);
														  }
														  if(!empty($assignusers)){
															  ?>
														  <p class="assigneed-user"><?php echo implode(",", $assignusers);?></p>
														  <?php }  
														  }else{?>
														
														   <p class="assigneed-user"><?php echo "No Assignee";?></p>
														<?php	}?>
														 </div>
														<!-- Display Selected User -->
												  </div>
												  <!-- /.box-body -->
												  <div class="box-footer">
													<button type="submit" class="btn btn-primary">Update</button>
													<button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Cancel</button>
												  </div>
												</form>
												</div>
												<!--Task Update End-->
										</div>
										<div role="tabpanel" class="tab-pane" id="<?php echo "addmembertask".$task['result']['id'];?>">
												<!-- Add Member From Task -->
												<div class="box box-primary">
												<form role="form" method="POST" action="/addmemberfromtask" id="addmemberfromtaskform">
													 <?php echo e(csrf_field()); ?>

												  <div class="box-body">
													 <input type="hidden" name="task_id" value="<?php echo e($task['result']['id']); ?>" id="task_id"></input>
													 <input type="hidden" name="loggedin_id" value="<?php echo e(Session::get('userdetails.id')); ?>" id="loggedin_id"></input>
													 <input type="hidden" name="task_projectid" value="<?php echo e($project_data['id']); ?>" id="task_projectid"></input>
													<div class="form-group">
													  <label>Select Member<span class="red">*</span></label>
													 <?php if(!empty($task['result']['assignedTo'])){
														   $assigneduser=array();
														   foreach($task['result']['assignedTo'] as $index => $assign){
															 $assigneduser[]=TaskManageController::getAssignName($assign['profileId']);
														   } 
														 }?>
													  <select multiple class="form-control"  name="associateId[]" required>
													 <?php if(!empty($project_user)){?>
														 
														<?php 
														   foreach($project_user as $index => $list){
															   if(!empty($assigneduser)){
															   $existingassignee=in_array($list['profileId']['name'],$assigneduser);
																}
															   if(!empty($existingassignee)){?>
																 <option value="<?php echo $list['id'].','.$list['profileId']['id'];?>" class="selectedassignee"><?php echo $list['profileId']['name'];?></option>
															  <?php }else{  ?>
																 <option value="<?php echo $list['id'].','.$list['profileId']['id'];?>"><?php echo $list['profileId']['name'];?></option>
															   <?php }
														   } 
														?>	 
													  <?php }else{?>
														  <option value="">No Member Assignee</option>
													<?php  }?>
													 </select>
													 </div>
												  </div>
												  <!-- /.box-body -->
												  <div class="box-footer">
													<button type="submit" class="btn btn-primary">Add Assignee</button>
													<button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Cancel</button>
												  </div>
												</form>
											  </div>
											  <!-- Add Member From Task -->
										</div>
										<div role="tabpanel" class="tab-pane" id="<?php echo "removemembertask".$task['result']['id'];?>">			
												<!-- Remove Member From Task -->
												<div class="box box-primary">
												<form role="form" method="POST" action="/removememberfromtask" id="removememberfromtaskform">
													 <?php echo e(csrf_field()); ?>

												  <div class="box-body">
													 <input type="hidden" name="task_id" value="<?php echo e($task['result']['id']); ?>" id="task_id"></input>
													 <input type="hidden" name="loggedin_id" value="<?php echo e(Session::get('userdetails.id')); ?>" id="loggedin_id"></input>
													 <input type="hidden" name="task_projectid" value="<?php echo e($project_data['id']); ?>" id="task_projectid"></input>
													<div class="form-group">
													  <label>Select Member<span class="red">*</span></label>
													  <select class="form-control" name="assignee" required>
														<option value="" >Please select Member</option>
														<?php if(!empty($task['result']['assignedTo'])){
														   foreach($task['result']['assignedTo'] as $index => $assign){
															echo '<option value='.$assign['id'].','.$assign['profileId'].'>'.TaskManageController::getAssignName($assign['profileId']) .'</option>';
														   } 
														 }?>
													  </select>
													</div>
												  </div>
												  <!-- /.box-body -->
												  <div class="box-footer">
													<button type="submit" class="btn btn-primary">Remove Assignee</button>
													<button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Cancel</button>
												  </div>
												</form>
												</div>
											  </div>
											  <!-- Remove Member From Task -->
										</div>
								</div>
								<!-- Tab Panes End -->
									 </div>
								</div><!-- modal-content -->
							</div><!-- modal-dialog -->
						</div><!-- modal -->
					  </div>
					</div>
					<!--  Edit Task Model End -->
