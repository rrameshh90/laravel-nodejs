<?php $__env->startSection('title', 'Timesheet All Details'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	Timesheet Approved List Page
	<small></small>
	</h1>
	<ol class="breadcrumb">
	<li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
	<li><a href="<?php echo e(url('/timesheetassociate')); ?>">Timesheet User List</a></li>
	<li class="active">Timesheet Approved Page</li>
	</ol>
</section>
 <section class="content">
      <div class="row">
        <!-- left column -->
       <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 <?php if(Session::has($key)): ?>
			  <div class="alert alert-<?php echo e($key); ?> alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				<strong><?php echo e(Session::get($key)); ?></strong>
				</div>
				<?php endif; ?>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <section class="invoice">
		<div class="row table-responsive">
			  <div class="card">
				<ul class="nav nav-tabs" role="tablist">
					<li role="presentation" class="active"><a href="#timesheetapprovedlist" id="userwisetimeapproved_1" aria-controls="timesheetapprovedlist" role="tab" data-toggle="tab">Timesheet Approved List</a></li> 
				</ul>

				<!-- Tab panes Start-->
				<div class="tab-content">
					<!-- Tab Approved Timesheet list Start-->
					<div role="tabpanel" class="tab-pane <?php if(!empty(Session::get('userdetails.role')=='1')){ echo "active";}?>" id="timesheetapprovedlist">
						 <br/>
						 <div class="box-body"> 
						<div class="box-body table-responsive">
						<div class="accordion-approved" id="accordionapproved">
						<div class="accordion-group">
							<div class="accordion-heading-approved custom-filter-search">
							<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionapproved" href="#collapseApproved">
							 Custom Filters
							</a>
							</div>
						<div id="collapseApproved" class="accordion-body collapse">
							<div class="accordion-inner">
								<div class="row">
									<div class="col-md-12">
												 <div class="form-group timesheet_filter">
													<label>Project Name :</label>
													<input type='text' id="project_name_field_app" class='form-control approved_filter' data-column-index='1'/>
												  </div>
													<div class="form-group timesheet_filter">
													<label>Task / Ticket Name:</label>
													<input type='text' id="ticket_task_field_app" class='form-control approved_filter' data-column-index='2'/>
												  </div>
												  <div class="form-group timesheet_filter">
													<label>Start Date :</label>
													<div class="input-group date">
													<div class="input-group-addon">
													<i class="fa fa-calendar"></i>
													</div>
													<input type="text" name="min"  class="form-control" id="min_approved" placeholder="Start Date" required />
													</div>
												  </div>
												   <div class="form-group timesheet_filter">
													<label>End Date :</label>
													<div class="input-group date">
													<div class="input-group-addon">
													<i class="fa fa-calendar"></i>
													</div>
													<input type="text" name="max"  class="form-control" id="max_approved" placeholder="End Date" required />
													</div>
												  </div>
												<div class="form-group timesheet_filter">
												  <b>Filter By Task / Ticket</b>
															  <div class="radio">
																<label>
																  <input type="radio" class='approved_filter' name="optionsuserApproved" id="optionsuserApproved1" value="Task" data-column-index='7' />
																  Task &nbsp;&nbsp;
																</label>
																<label>
															  <input type="radio" class='approved_filter' name="optionsuserApproved" id="optionsuserApproved2" value="Ticket" data-column-index='7'/>
																   Ticket
																</label>
															  </div>
													  </div>
												<div style="clear:both;"></div>
												  <button id="reset_btn_id_approved" class="pull-left">Reset Filter</button>
												  <br/>
												  <br/>
											</div>
										</div>
									</div>
								</div>
							</div>
					</div>
									<div class="box-body table-responsive">
								  <table class="table table-bordered table-striped" id="timesheet_approved_list_1">
									  <thead>
										<tr>
											<th>Sno</th>
											<th>Project Name</th>
											<th>Task Name / Ticket Name</th>
											<th>Date</th>
											<th>Hours</th>
											<th>Comments</th>
											<th>Approved By</th>
											<th>Filter</th>
										</tr>
									</thead>
									<tbody>				
										<?php if(!empty($associateapprovedtimesheetdata)){
											foreach($associateapprovedtimesheetdata as $index=>$list){ ?>
												<?php $id=$list['id'];?>
												<?php $user_role = Session::get('userdetails.role');?>
											<tr>
											  <td><?php echo $index+1;?></td>
											  <?php if(!empty($list['ProjectId']) && $list['isTicket']!='1'){?>
											  <td><a href="<?php echo "/project_details/".$list['ProjectId'];?>"><?php echo HelperController::getProjectName($list['ProjectId']) ?></a></td>
											  <?php }elseif(!empty($list['ProjectId']) && $list['isTicket']=='1'){?>
											  <td><a href="<?php echo "/project_details/".$list['ProjectId'];?>"><?php echo HelperController::getProjectName($list['ProjectId']) ?></a></td>
											  <?php }else{?>
											  <td> NA </td>
											  <?php }?>
											  <?php if($user_role!='1'){?>
											   <?php if(!empty($list['TaskId']) && $list['isTicket']!='1' ){?>
											  <td><a href="<?php echo "/taskdetails/".$list['TaskId'];?>"><?php echo HelperController::getTaskName($list['TaskId']) ?></a></td>
											  <?php }else {?>
											  <td><a href="<?php echo "/ticketdetails/".$list['ticket'];?>"><?php echo HelperController::getTicketName($list['ticket']) ?></a></td>
											  <?php }?>
											  <?php }else{?>
												   <?php if(!empty($list['TaskId']) && $list['isTicket']!='1' ){?>
											  <td><?php echo HelperController::getTaskName($list['TaskId']) ?></td>
											  <?php }else {?>
											  <td><?php echo HelperController::getTicketName($list['ticket']) ?></td>
											  <?php }?>
											  <?php }?>
											  <td><?php echo date('d/m/Y', strtotime($list['DateAndTime']));?></td>	
											  <td><?php echo $list['hours'];?></td>
											  <td><?php echo $list['comments'];?></td>
											  <td><?php echo HelperController::getProjectManagerName($list['approvelManager']['profileId']) ?></td>
											  <?php if($list['isTicket']!='1'){?>
											  <td><span class="task_name_label">Task</span></td>
											  <?php }else{?>
											  <td><span class="ticket_name_label">Ticket</span></td>
											  <?php }?>
											</tr>
											<?php } 
												}
											  ?>
									  </tbody>	
									   <tfoot>
												<tr>
														<th></th>
														<th></th>
														<th></th>
														<th></th>
														<th></th>
														<th></th>
														<th colspan="2"></th>
													</tr>
												</tfoot>				 
										</table>  
								  </div>
								</div>
								</div>
					</div>
					<!-- Tab Approved Timesheet list End-->
				</div>
				<!-- Tab panes End-->
			</div>
		</div>
	</section>

     </div>
     </section>
     <script>
	var $=jQuery;
  $(function () {
     /* Custom filtering function which will search data in column four between two values */
        $(document).ready(function () { 
			
	    /* Approved Timesheet Custom Filter */
     var dtable_approved_1 = $('#timesheet_approved_list_1').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : true,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]],      
      "dom": 'lBfrtip',
      "buttons": [
            {
                extend: 'collection',
                className: 'approved',
                text: 'Export',
                buttons: [
					{ extend: 'excelHtml5',exportOptions: { columns: [0,1,2,3,4,5,6,7] }, footer: true },
					{ extend: 'csvHtml5', exportOptions: { columns: [0,1,2,3,4,5,6,7] }, footer: true },
					{ extend: 'pdfHtml5', exportOptions: { columns: [0,1,2,3,4,5,6,7] }, footer: true }
                ]
            }
        ],
        "footerCallback": function (nRow,row, data, start, end, display ) {
            var api = this.api(), data;
		
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
                .column( 4 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 ); 
            // Total over this page
            pageTotal = api
                .column( 4, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            // Update footer
            $($(nRow).children().get(data-1)).html('<div class="totalhrs"><span class="pagetotal">Total: '+pageTotal +' Hrs</span></div>');
        },
		"drawCallback": function( settings ) {
			var table = this.api();
			if (table.page.info().recordsTotal < 1 ) {
			 $('button.dt-button').css( 'display', 'none' );
			}
		}
    });  
                /** Userwise Approved Date filter **/
            $.fn.dataTable.ext.search.push(
                function (settings, data, dataIndex) {
                    var min = $('#min_approved').datepicker("getDate");
                    var max = $('#max_approved').datepicker("getDate");
                    // need to change str order before making  date obect since it uses a new Date("mm/dd/yyyy") format for short date.
                    var d = data[3].split("/");
                    var startDate = new Date(d[1]+ "/" +  d[0] +"/" + d[2]);

                    if (min == null && max == null) { return true; }
                    if (min == null && startDate <= max) { return true;}
                    if(max == null && startDate >= min) {return true;}
                    if (startDate <= max && startDate >= min) { return true; }
                    return false;
                }
            );
            $("#min_approved").datepicker({ onSelect: function () { table.draw(); }, changeMonth: true, changeYear: true , dateFormat:"dd/mm/yy"});
            $("#max_approved").datepicker({ onSelect: function () { table.draw(); }, changeMonth: true, changeYear: true, dateFormat:"dd/mm/yy" });
            var table = dtable_approved_1;

            // Event listener to the two range filtering inputs to redraw on input
            $('#min_approved, #max_approved').change(function () {
                table.draw();
            });
            
            /** User Wise Timesheet Approved list filter Start **/
			$('.approved_filter').on('keyup change', function() {
			//clear global search values
			//dtable is object of the #timesheet_approved_list
			dtable_approved_1.search('');
			dtable_approved_1.column($(this).data('columnIndex')).search(this.value).draw();
			});
			$(".dataTables_filter input").on('keyup change', function() {
			//clear column search values
			dtable_approved_1.columns().search('');
			//clear input values
			$('.approved_filter').val('');
			});
			/** User Wise Timesheet Approved list filter End **/
			
			/** Reset Filter **/
			$('#reset_btn_id_approved').on('click', function(){
				$("#project_name_field_app").val('');
				$("#ticket_task_field_app").val('');
				$('input[name=min]').val('').datepicker("update");
				$('input[name=max]').val('').datepicker("update");
				dtable_approved_1.search( '' ).columns().search( '' ).draw();
				$('input[name=optionsuserApproved]').prop('checked', false);
			});
        });
     });
     </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>