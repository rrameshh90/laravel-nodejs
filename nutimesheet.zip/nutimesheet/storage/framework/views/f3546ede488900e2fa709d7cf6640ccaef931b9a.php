<?php $__env->startSection('title', 'Project List'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
       <section class="content-header">
      <h1>
        Project List Page
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Project List Page</li>
      </ol>
    </section>
 <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-xs-12">
			<?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 <?php if(Session::has($key)): ?>
			  <div class="alert alert-<?php echo e($key); ?> alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				<strong><?php echo e(Session::get($key)); ?></strong>
				</div>
				<?php endif; ?>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Project List</h3>
              <?php if(!empty(Session::get('userdetails.role')=='2')): ?>
				<p class="pull-right">
					<a href="<?php echo e(url('/create_project')); ?>" class="btn btn-block btn-success">
						Add Project
					</a>
                 </p>
                <?php endif; ?>
            </div>
            <!-- /.box-header -->
             <div class="box-body">
			<?php if(!empty(Session::get('userdetails.role')=='2')): ?>
            <?php if(!empty($project_listdata)){?>
						<strong>Project Status Count: </strong><br> 
						<?php
						$taskstatus=array();
						foreach($project_listdata as $project){
							$projectstatus[]=$project['state'];
						}
						$counts = array_count_values($projectstatus);
						$total=0;
							foreach($counts as $count){
									$total+=$count;
							}?>
					<address class="task-count-section">
						<?php if(!empty($counts['1'])){?>
						<span class="badge new-label">New <span id="new-count">(<?php echo e($counts['1']); ?>)</span></span>
						<?php }if(!empty($counts['2'])){?>
						<span class="badge inprogress-label">InProgress <span id="inprogress-count">(<?php echo e($counts['2']); ?>)</span></span>
						<?php }if(!empty($counts['3'])){?>
						<span class="badge delayed-label">Deloyed <span id="delayed-count">(<?php echo e($counts['3']); ?>)</span></span>
						<?php }if(!empty($counts['4'])){?>
						<span class="badge closed-label">Closed <span id="closed-count">(<?php echo e($counts['4']); ?>)</span></span>
						<?php }if(!empty($counts['5'])){?>
						<span class="badge deleted-label">Deleted <span id="deleted-count">(<?php echo e($counts['5']); ?>)</span></span>
						<?php }if(!empty($total)){?>
						<span class="badge total-label">Total <span id="total-count">(<?php echo e($total); ?>)</span></span>
						<?php }?>
					</address>
				    <?php }?>
				   <?php endif; ?>
				 </div>
            <div class="box-body table-responsive">
              <table class="table table-bordered table-striped" id="project_datatable">
				  <thead>
					<tr>
					  <th>ID</th>
					  <th>Name</th>
					  <th>Start Date</th>
					  <th>End Date</th>
					  <th class="desc">Description</th>
					  <?php if(!empty(Session::get('userdetails.role')=='1') || !empty(Session::get('userdetails.role')=='3')): ?>
					  <th>Project Manager</th>
					  <?php endif; ?>
					  <th>Status</th>
					  <?php if(!empty(Session::get('userdetails.role')=='2')): ?>
					  <th>Actions</th>
					  <?php endif; ?>
					</tr>
                </thead>
                <?php if(!empty(Session::get('userdetails.role')=='1') || !empty(Session::get('userdetails.role')=='2')): ?>
                <tbody>
                 <?php if(!empty($project_listdata)){
						foreach($project_listdata as $index=>$list){ ?>
							<?php $id=$list['id'];?>
						<tr>
						  <td><?php echo $index+1;?></td>
						  <td><a href="<?php echo "/project_details/".$id;?>"><?php echo $list['Name'];?></a></td>
						  <td><?php echo date('d-m-Y', strtotime($list['startDate']));?> </td>
						  <td><?php echo date('d-m-Y', strtotime($list['endDate']));?></td>
						  
						  <td><?php echo $list['desc'];?></td>
						  <?php if(!empty(Session::get('userdetails.role')=='1')): ?>
						  <td><?php if(!empty( $list['manager']['profileId'])){?>
							   <?php echo HelperController::getProjectManagerName($list['manager']['profileId']);}?>
						  </td>
						  <?php endif; ?>
						  <td><?php if(!empty($list['state'])){?>
							  <?php $todaydate=date("d-m-Y");?>
							  <?php if(date('d-m-Y', strtotime($list['startDate'])) <= $todaydate){
										if($list['state']=='1'){
										$list['state']='2';?>
										<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php $loggedInUserId=Session::get('user_id'); 
												  $projectid=$list['id'];
												  $project_name=$list['Name'];
												  $project_desc=$list['desc'];
												  $project_status=$list['state'];
											if(!empty($loggedInUserId) && !empty($projectid) && !empty($project_name) && !empty($project_desc) && !empty($project_status)){	  
										      $statusid=HelperController::UpdateProjectStatus($loggedInUserId,$projectid,$project_name,$project_desc,$project_status);
											  if(!empty($statusid['state'])){
												  $list['state']=$statusid['state'];
											  }
											}?>
											<?php echo HelperController::getprojectStatus($list['state']);?>
											<?php }else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
												<?php echo HelperController::getprojectStatus($list['state']);?>
											<?php }
											}elseif(date('d-m-Y', strtotime($list['endDate'])) == $todaydate){
											if($list['state']!='3' || $list['state']!='4'){
												$list['state']='3';?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php $loggedInUserId=Session::get('user_id'); 
												  $projectid=$list['id'];
												  $project_name=$list['Name'];
												  $project_desc=$list['desc'];
												  $project_status=$list['state'];
													if(!empty($loggedInUserId) && !empty($projectid) && !empty($project_name) && !empty($project_desc) && !empty($project_status)){	  
													 $statusid=HelperController::UpdateProjectStatus($loggedInUserId,$projectid,$project_name,$project_desc,$project_status);
													  if(!empty($statusid['state'])){
														  $list['state']=$statusid['state'];
													  }
													}?>
													<?php echo HelperController::getprojectStatus($list['state']);?>
											<?php }else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
												<?php echo HelperController::getprojectStatus($list['state']);?>
											<?php }
											}else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php echo HelperController::getprojectStatus($list['state']);?>
											<?php }?>
											<?php }?>
								   </span>
						  </td>
						  <?php if(!empty(Session::get('userdetails.role')=='2')): ?>
						  <td><span class="edit" data-toggle="modal" title="edit" data-target="<?php echo "#updateprojectModal".$list['id'];?>"><i class="fa fa-fw fa-edit"></i></span>
						  <?php endif; ?>
							<!--<a href="<?php //echo "/projectdelete/".$list['id'];?>" title="delete" class="delete" Onclick="return ConfirmDelete();"><i class="fa fa-fw fa-trash"></i></a></td>-->
						</tr>
						<div class="modal right fade" id="<?php echo "updateprojectModal".$list['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<h4 class="modal-title" id="updateuserLabel">Edit Project</h4>
									</div>
									<div class="modal-body">
										<div class="row">
												<!-- left column -->
												<div class="col-md-12">
												  <!-- general form elements -->
												  <div class="box box-primary" id="projecttoassociate">
													<div class="box-header with-border">
													  <h3 class="box-title">Update Project Details</h3>
													</div>
													<!-- /.box-header -->
													<!-- form start -->
													<form role="form" method="POST" action="/updateprojectdetails">
														 <?php echo e(csrf_field()); ?>

													   <div class="box-body">
														 <input type="hidden" name="loggedInUserId" value="<?php echo e(Session::get('userdetails.id')); ?>" id="loggedin_id"></input>
														 <input type="hidden" name="projectid" value="<?php echo $list['id'];?>" id="project_id"></input>
														  <div class="form-group">
															  <label for="project_name">Project Name<span class="red">*</span></label>
															  <input type="text" name="project_name" class="form-control" id="project_name" value="<?php echo $list['Name'];?>" placeholder="Enter project name" required>
															</div>
															<div class="form-group">
															  <label>Description<span class="red">*</span></label>
															  <textarea class="form-control" name="project_desc" required><?php echo $list['desc'];?></textarea>
															</div>
															<!-- Add Select Field for Status -->
															<?php if(!empty($list['state'])){ echo HelperController::getEditProjectstatus($list['state']);}?>
															<!-- Add Select Field for Status -->
													  </div>
													  <!-- /.box-body -->
												
													<div class="box-footer">
														<button type="submit" class="btn btn-primary">Update</button>
													  </div>
													</form>
												  </div>
												</div>
											</div><!-- modal-content -->
										</div><!-- modal-dialog -->
									</div><!-- modal -->
									</div>
							</div>
						<?php }
						}?>
				  </tbody>
				  <?php elseif(!empty(Session::get('userdetails.role')=='3')): ?>
				    <tbody>
					<?php $dashboard_associateproject=Session::get('associateuserdetails');?>
                 <?php if(!empty($project_listdata)){
						foreach($project_listdata as $index=>$list){ ?>
							<?php $id=$list['id'];?>
						<tr>
						  <td><?php echo $index+1;?></td>
						  <td><a href="<?php echo "/project_details/".$id;?>"><?php echo $list['Name'];?></a></td>
						  <td><?php echo date('d-m-Y', strtotime($list['startDate']));?></td>
						  <td><?php echo date('d-m-Y', strtotime($list['endDate']));?></td>
						  <td><?php echo $list['desc'];?></td>
						  <td><?php if(!empty( $list['manager']['profileId'])){?>
							   <?php echo HelperController::getProjectManagerName($list['manager']['profileId']);}?>
						  </td>
						  <td><?php if(!empty($list['state'])){?>
							  <?php $todaydate=date("d-m-Y");?>
							  <?php if(date('d-m-Y', strtotime($list['startDate'])) <= $todaydate){
										if($list['state']=='1'){
										$list['state']='2';?>
										<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php $loggedInUserId=Session::get('user_id'); 
												  $projectid=$list['id'];
												  $project_name=$list['Name'];
												  $project_desc=$list['desc'];
												  $project_status=$list['state'];
											if(!empty($loggedInUserId) && !empty($projectid) && !empty($project_name) && !empty($project_desc) && !empty($project_status)){	  
										      $statusid=HelperController::UpdateProjectStatus($loggedInUserId,$projectid,$project_name,$project_desc,$project_status);
											  if(!empty($statusid['state'])){
												  $list['state']=$statusid['state'];
											  }
											}?>
											<?php echo HelperController::getprojectStatus($list['state']);?>
											<?php }else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
												<?php echo HelperController::getprojectStatus($list['state']);?>
											<?php }
											}elseif(date('d-m-Y', strtotime($list['endDate'])) == $todaydate){
											if($list['state']!='3' || $list['state']!='4'){
												$list['state']='3';?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php $loggedInUserId=Session::get('user_id'); 
												  $projectid=$list['id'];
												  $project_name=$list['Name'];
												  $project_desc=$list['desc'];
												  $project_status=$list['state'];
													if(!empty($loggedInUserId) && !empty($projectid) && !empty($project_name) && !empty($project_desc) && !empty($project_status)){	  
													 $statusid=HelperController::UpdateProjectStatus($loggedInUserId,$projectid,$project_name,$project_desc,$project_status);
													  if(!empty($statusid['state'])){
														  $list['state']=$statusid['state'];
													  }
													}?>
													<?php echo HelperController::getprojectStatus($list['state']);?>
											<?php }else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
												<?php echo HelperController::getprojectStatus($list['state']);?>
											<?php }
											}else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php echo HelperController::getprojectStatus($list['state']);?>
											<?php }?>
											<?php }?>
								   </span>
						  </td>
						</tr>
						<?php }
						}?>
				  </tbody>
				  <?php endif; ?>
				</table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
          <!-- /.box -->
     </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>