<?php $__env->startSection('title', 'Login'); ?>
<?php echo $__env->make('layouts.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="login-box">
  <div class="login-logo">
    <img src="<?php echo e(asset('images/nu-logo.png')); ?>"></img>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
		<?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if(Session::has($key)): ?>
		  <div class="alert alert-<?php echo e($key); ?> alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong><?php echo e(Session::get($key)); ?></strong>
		  </div>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <p class="login-box-msg">Sign in to start your session</p>
    <div class="social-auth-links text-center">
      <a href="<?php echo e(url('/login/google')); ?>" class="btn btn-block btn-social btn-google btn-flat"><i class="fa fa-google-plus"></i> Sign in using
        Google+</a>
    </div>
    <!-- /.social-auth-links -->

  </div>
  <!-- /.login-box-body -->
</div>
<?php echo $__env->make('layouts.partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
<footer class="main-footer login-footer">
    <!-- Default to the left -->
    <strong>Copyright © 2018 <a href="http://www.nutechnologyinc.com/">NU Technologyinc</a>.</strong> All rights reserved.
</footer>
</html>
