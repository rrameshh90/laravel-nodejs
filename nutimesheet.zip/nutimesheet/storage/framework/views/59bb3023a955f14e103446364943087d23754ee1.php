<?php $__env->startSection('title', 'Employee List'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	Employee List Page
	<small></small>
	</h1>
	<ol class="breadcrumb">
	<li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
	<li class="active">Employee List Page</li>
	</ol>
</section>
 <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-xs-12">
			<div class="box">		
				<?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				 <?php if(Session::has($key)): ?>
				 <div class="alert alert-<?php echo e($key); ?> alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong> <?php echo e(Session::get($key)); ?></strong>
				 </div>
				 <?php endif; ?>
			   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			 <div class="box-header">
              <h3 class="box-title">Empolyee List</h3>
				 <p class="pull-right">
					<button type="button" class="btn btn-success" data-toggle="modal" data-target="#userrestoremodal">
						User Restore
					</button>

					<a href="<?php echo e(url('/create_user')); ?>" class="btn btn-success">
						Add New Employee
					</a>
                 </p>
              </div>
              <div class="box-body">
				<div class="accordion-userlist" id="accordionuserlist">
					<div class="accordion-group">
						<div class="accordion-heading-userlist custom-filter-search">
						<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionuserlist" href="#collapseUsers">
						User Filter By Role
						</a>
						</div>
					<div id="collapseUsers" class="accordion-body collapse">
						<div class="accordion-inner">
							<div class="row">
								<div class="col-md-12">
											 <div class="form-group userlist_filter">
												 <button class="active btn" id="all">All Users</button>
												 <button class="btn" id="management">Management</button>
												 <button class="btn" id="manager">Manager</button>
												 <button class="btn" id="associate">Associate</button>
											  </div>
											  <!--<div class="form-group userlist_filter">
												<label>Search By Text :</label>
												<input type="text" class="text-input" id="filter" value="" />
											  </div>-->
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					</div>
     <div class="box-body" id="userlistparentdiv">     
		  
		<?php if(!empty($user_listdata)){
			foreach($user_listdata as $list){ ?>
		<div class="col-md-6 <?php if($list['role']=='1'){ echo "management".' '."all"; } if($list['role']=='2'){ echo "manager".' '."all";} if($list['role']=='3'){ echo "associate".' '."all";}?>">
          <!-- Widget: user widget style 1 -->
          <div class="box box-widget widget-user-2">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <!-- bk color class -- bg-yellow -->
         
            <div class="widget-user-header">
              <div class="widget-user-image">
                <img class="img-circle" src="<?php echo e(asset('Admin/dist/img/usericon.png')); ?>" alt="User Avatar">
              </div>
              <!-- /.widget-user-image -->
              <h3 class="widget-user-username"> <a href="<?php echo "/userdetails/".$list['id'];?>"><?php echo $list['name'];?></a></h3>
              <h5 class="widget-user-email"><?php echo $list['email'];?></h5>
              <h5 class="widget-user-designation"><?php echo $list['designation'];?></h5>
              <div class="pull-right user-action">
               <a href="<?php echo "/userdetails/".$list['id'];?>" title="view user" class="userview"><i class="fa fa-fw fa-eye"></i></a>&nbsp;&nbsp;&nbsp;
			   <span class="edit" data-toggle="modal" title="edit" data-target="<?php echo "#updateuserModal".$list['id'];?>"><i class="fa fa-fw fa-edit"></i></span>&nbsp;&nbsp;&nbsp;
			   <a href="<?php echo "/userdelete/".$list['id'];?>" title="delete" class="delete" Onclick="return ConfirmDelete();"><i class="fa fa-fw fa-trash"></i></a>
			 </div>
            </div>
          </div>
         
          <!-- /.widget-user -->
        </div>
        <div class="modal right fade" id="<?php echo "updateuserModal".$list['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="updateuserLabel">Edit User</h4>
				</div>
				<div class="modal-body">
					<div class="row">
							<!-- left column -->
							<div class="col-md-12">
							  <!-- general form elements -->
							  <div class="box box-primary" id="updateuserdetails">
								<div class="box-header with-border">
								  <h3 class="box-title">Update User Details</h3>
								</div>
								<!-- /.box-header -->
								<!-- form start -->
								<form role="form" method="POST" action="/updateuserdetails">
									 <?php echo e(csrf_field()); ?>

								   <div class="box-body">
									 <input type="hidden" name="loggedInUserId" value="<?php echo e(Session::get('userdetails.id')); ?>" id="loggedin_id"></input>
									 <input type="hidden" name="userprofileId" value="<?php echo $list['id'];?>" id="userprofile_id"></input>
									 <div class="form-group">
									  <label for="Inputusername">Name<span class="red">*</span></label>
									  <input type="text" name="employee_name" class="form-control" id="InputUsername" value="<?php echo $list['name'];?>" required>
									</div>
									<div class="form-group">
									  <label for="InputEmailaddress">Email Address<span class="red">*</span></label>
									  <input type="email" name="email_address" class="form-control" id="InputEmailaddress" value="<?php echo $list['email'];?>" required>
									</div>
									<div class="form-group">
									  <label for="InputDesignation">Designation<span class="red">*</span></label>
									  <input type="text" name="employee_designation" class="form-control" id="InputDesignation" value="<?php echo $list['designation'];?>" required>
									</div>
								  </div>
								  <!-- /.box-body -->
							
								<div class="box-footer">
									<button type="submit" class="btn btn-primary">Update</button>
									<button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Cancel</button>
								  </div>
								</form>
							  </div>
							  <!-- Role change Code Start -->
							   <div class="box box-primary" id="rolechangeuser">
								<div class="box-header with-border">
								  <h3 class="box-title">Role Change For Existing User</h3>
								</div>
								<!-- /.box-header -->
								<!-- form start -->
								<form role="form" method="POST" action="/rolechangeexistinguser">
									 <?php echo e(csrf_field()); ?>

								   <div class="box-body">
									 <input type="hidden" name="loggedInUserId" value="<?php echo e(Session::get('userdetails.id')); ?>" id="loggedin_id"></input>
									<div class="form-group">
									  <label for="InputEmailaddress">Email Address<span class="red">*</span></label>
									  <input type="email" name="email" class="form-control" id="emailaddress"  value="<?php echo $list['email'];?>" required></input>
									</div>
									 <div class="form-group">
										  <label>Role<span class="red">*</span></label>
										  <?php $roleid=$list['role']; ?>
										  <select class="form-control" name="role" required>
											<option value="1" <?php if(!empty($roleid) && $roleid =='1'){ echo "selected"; }?>>Management</option>
											<option value="2" <?php if(!empty($roleid) && $roleid =='2'){ echo "selected"; }?>>Manager</option>
											<option value="3" <?php if(!empty($roleid) && $roleid =='3'){ echo "selected"; }?>>Associate</option>
										  </select>
									  </div>
									  
								  </div>
								  <!-- /.box-body -->
								<div class="box-footer">
									<button type="submit" class="btn btn-primary">Change Role</button>
									<button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Cancel</button>
								  </div>
								</form>
							  </div>
							  <!-- Role Change code End -->
							</div>
						</div><!-- modal-content -->
					</div><!-- modal-dialog -->
				</div><!-- modal -->
				</div>
		</div>
        <?php 
        }
        }else{
			echo "<center><span class='red'>No Employee Data Right Now</span></center>";
		
		}?>
      </div>
      <!-- User Restore Modal Code Start -->
              <div class="modal right fade" id="userrestoremodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="restoreuserLabel">Restore User</h4>
				</div>
				<div class="modal-body">
					<div class="row">
							<!-- left column -->
							<div class="col-md-12">
							  <!-- general form elements -->
							  <div class="box box-primary" id="restoreuser">
								<div class="box-header with-border">
								  <h3 class="box-title">Restore Existing User</h3>
								</div>
								<!-- /.box-header -->
								<!-- form start -->
								<form role="form" method="POST" action="/restoreexistinguser">
									 <?php echo e(csrf_field()); ?>

								   <div class="box-body">
									 <input type="hidden" name="loggedInUserId" value="<?php echo e(Session::get('userdetails.id')); ?>" id="loggedin_id"></input>
									<div class="form-group">
									  <label for="InputEmailaddress">Email Address<span class="red">*</span></label>
									  <input type="email" name="email_address" class="form-control" id="InputEmailaddress" required>
									</div>
								  </div>
								  <!-- /.box-body -->
							
								<div class="box-footer">
									<button type="submit" class="btn btn-primary">Restore</button>
									<button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Cancel</button>
								  </div>
								</form>
							  </div>
							</div>
						</div><!-- modal-content -->
					</div><!-- modal-dialog -->
				</div><!-- modal -->
				</div>
		</div>
          <!-- /.box -->
           <!-- User Restore Modal Code End -->
     </section>
     <!-- Script for User Div List filter based on Role -->
   <script>
	   var $=jQuery;
		$(function () {
		var $btns = $('.btn').click(function() {

		var $el = $('.' + this.id).fadeIn(450);
		$('#userlistparentdiv > div').not($el).hide();
		$btns.removeClass('active');
		$(this).addClass('active');
		});
		$(document).ready(function(){
		$("#filter").keyup(function(){

		// Retrieve the input field text and reset the count to zero
		var filter = $(this).val(), count = 0;

		// Loop through the comment list
		$(".widget-user-header").each(function(){

			// If the list item does not contain the text phrase fade it out
			if ($(this).text().search(new RegExp(filter, "i")) < 0) {
				$(this).fadeOut();

			// Show the list item if the phrase matches and increase the count by 1
			} else {
				$(this).show();
				count++;
			}
		});

		// Update the count
		var numberItems = count;
		//$("#filter-count").text("Number of Comments = "+count);
		});
});
		});
   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>