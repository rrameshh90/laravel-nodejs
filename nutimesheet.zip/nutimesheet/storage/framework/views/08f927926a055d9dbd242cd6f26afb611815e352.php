<?php $__env->startSection('title', 'Task Details'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
       <section class="content-header">
      <h1>
        Task Details Page
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <?php if(!empty(Session::get('userdetails.role')=='3')): ?>
        <li><a href="<?php echo e(url('/mytasklist')); ?>">My Task List</a></li>
        <?php endif; ?>
        <li class="active">Task Details Page</li>
      </ol>
    </section>
     <section class="content">
      <!-- title row -->
         <div class="row">
        <!-- left column -->
			<?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 <?php if(Session::has($key)): ?>
			  <div class="alert alert-<?php echo e($key); ?> alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				<strong><?php echo e(Session::get($key)); ?></strong>
				</div>
				<?php endif; ?>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <section class="invoice">
      <!-- title row -->
      <?php if(!empty($taskdetail_data)): ?>
      <div class="row">
          <h2 class="page-header">
            <i class="fa fa-tasks"></i> &nbsp;<?php echo e($taskdetail_data['name']); ?>

          </h2>
      </div>
      <!-- info row -->
      <div class="row invoice-info">
        <div class="col-sm-9 invoice-col">
		  <strong>Project Name : <?php echo e($taskdetail_data['projectId']['Name']); ?></strong>	<br> 			
          <strong>Project Description : </strong><br> 
				<?php echo e($taskdetail_data['projectId']['desc']); ?>

        </div>
        <!-- /.col -->
        
        <!-- /.col -->
        <div class="col-sm-3 invoice-col">
		   <address class="task-date-section">
		   <b>Start Date :</b> <input type="hidden" id="task_startdate" value="<?php echo e(date('Y,m,d', strtotime($taskdetail_data['startDate']))); ?>"/><?php echo e(date('d-m-Y', strtotime($taskdetail_data['startDate']))); ?><br>
           <b>End Date :</b>  <input type="hidden" id="task_enddate" value="<?php echo e(date('Y,m,d', strtotime($taskdetail_data['endDate']))); ?>"><?php echo e(date('d-m-Y', strtotime($taskdetail_data['endDate']))); ?><br>
           <b>Created Date :</b>  <?php echo e(date('d-m-Y', strtotime($taskdetail_data['createdAt']))); ?><br>
          <b>Last Update :</b>  <?php echo e(date('d-m-Y', strtotime($taskdetail_data['updatedAt']))); ?>

          </address>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- Table row -->
	
       <?php if(!empty(Session::get('userdetails.role')=='3')): ?> 
       <div class="row table-responsive">
       	<div class="card">
			<ul class="nav nav-tabs" role="tablist">
				<li role="presentation" class="active"><a href="#timesheetsavedlist" aria-controls="timesheetsavedlist" role="tab" data-toggle="tab">Timesheet Saved List</a></li>
				<li role="presentation"><a href="#timesheetsubmittedlist" aria-controls="timesheetsubmittedlist" role="tab" data-toggle="tab">Timesheet Submitted List</a></li>
			</ul>

			<!-- Tab panes -->
			<div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="timesheetsavedlist">
				<div class="box-header add-timesheet-header">
                 <div class="pull-right">
							 <div class="btn-group">
								<button type="button" class="btn btn-success" data-toggle="modal" data-target="#importtimeentry">
									Import Time Entry
								</button>
							 </div>
							 <div class="btn-group">
								<button type="button" class="btn btn-success" data-toggle="modal" data-target="#addnewentry">
									Add Time Entry
								</button>
							 </div>
				 </div>
            </div>
            
          <table class="table table-bordered" id="timeentry_datatable">
            <thead>
            <tr>
              <th>Sno</th>
              <th>Project Name</th>
              <th>Task Name</th>
              <th>Date</th>
              <th>Duration</th>
			  <th>Comments</th>
			  <th>Action</th>
            </tr>
            </thead>
            <?php if(!empty($savedtimesheet_list) && !empty(Session::get('userdetails.role')=='3')){ 
				$timesheetentry=$savedtimesheet_list;
				$associate_id=Session::get('associateuserdetails.result.id');
				$user_id=Session::get('userdetails.id');
					?>
				<tbody>
				<?php
					$i=0;
					foreach($timesheetentry as $index =>$entry){
						if($taskdetail_data['id']==$entry['TaskId']['id'] && $taskdetail_data['isTicket']!='1'){
							$i++;
						?>	
					<tr>
					  <td><?php echo $i;?></td>
					  <td><?php echo $entry['ProjectId']['Name'];?></td>
					  <td><?php echo $entry['TaskId']['name'];?></td>
					  <td><?php echo date('m-d-Y', strtotime($entry['DateAndTime']));?></td>	
					  <td><?php echo $entry['hours'];?></td>
					  <td><?php echo $entry['comments'];?></td>
					   <td> <span class="edit" data-toggle="modal" title="edit" data-target="<?php echo "#updatetimeentrymodal".$entry['id'];?>"><i class="fa fa-fw fa-edit"></i></span>&nbsp;&nbsp;&nbsp;
						<a href="<?php echo "/removetimesheet/".$entry['id'].'/'.$associate_id.'/'.$user_id.'/'.$taskdetail_data['id'];?>" title="delete" class="delete" Onclick="return ConfirmDelete();"><i class="fa fa-fw fa-trash"></i></a>&nbsp;&nbsp;&nbsp;
						<a href="<?php echo "/submittimesheet/".$entry['id'].'/'.$user_id.'/'.$taskdetail_data['id'];?>" title="timesheetsubmit" class="timesheetsubmit" Onclick="return ConfirmSubmit();"><i class="fa fa-fw fa-mail-forward"></i></a>
						</td>
					</tr>
					<!-- Timeentry Update Modal Include start -->
					<?php echo $__env->make('task.updatetimeentry_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<!-- Timeentry Updae Modal Include end -->
								<?php } 
				}?>
				</tbody>
            	<?php }?>
          </table>
				
				</div>
				<div role="tabpanel" class="tab-pane" id="timesheetsubmittedlist">
					<br/>
					  <table class="table table-bordered" id="timesubmitted_datatable">
						<thead>
						<tr>
						  <th>Sno</th>
						  <th>Project Name</th>
						  <th>Task Name</th>
						  <th>Date</th>
						  <th>Duration</th>
						  <th>Comments</th>
						  <th>Submitted To</th>			  
						</tr>
						</thead>
						<?php if(!empty($submitted_timesheet_list)){ 
							$submittedtimesheetentry=$submitted_timesheet_list;
							$associate_id=Session::get('associateuserdetails.result.id');
							$user_id=Session::get('userdetails.id');
								?>
							<tbody>
							<?php
								$i=0;
								foreach($submittedtimesheetentry as $index =>$entry){
								if($taskdetail_data['id']==$entry['TaskId']['id'] && $entry['isSubmitted']=='1' && $entry['isApproved']!='1' && $entry['isRejected']!='1' && $taskdetail_data['isTicket']!='1'){
										$i++;
									?>	
								<tr>
								  <td><?php echo $i;?></td>
								  <td><?php echo $entry['ProjectId']['Name'];?></td>
								  <td><?php echo $entry['TaskId']['name'];?></td>
								  <td><?php echo date('m-d-Y', strtotime($entry['DateAndTime']));?></td>	
								  <td><?php echo $entry['hours'];?></td>
								  <td><?php echo $entry['comments'];?></td>
								  <td><?php echo TaskManageController::getAssignName($entry['approvelManager']['profileId']) ?></td>		
								</tr>
								<?php }
								} ?>
							 </tbody>
							 <?php }?>
							 </table>				
				</div>
			</div>
		</div>
	   </div>
		<?php endif; ?>
		<!--  Project Management Submitted list -->
		<?php if(!empty(Session::get('userdetails.role')=='2')): ?> 
		<div class="row table-responsive">
		<div class="box-header">
              <h3 class="box-title">Timesheet Submitted Details</h3>
            </div>
          <table class="table table-bordered" id="timesubmitted_datatable_manager">
            <thead>
            <tr>
              <th>Sno</th>
              <th>Project Name</th>
              <th>Task Name</th>
              <th>Date</th>
              <th>Duration</th>
			  <th>Comments</th>
			  <?php if(!empty(Session::get('userdetails.role')=='2')): ?> 
			  <th>Submitted By</th>
			  <th>Action</th>
			  <?php endif; ?>
			  <?php if(!empty(Session::get('userdetails.role')=='3')): ?> 
			  <th>Submitted To</th>
			  <?php endif; ?>
			  
            </tr>
            </thead>
            <?php if(!empty($submitted_timesheet_list)){ 
				$submittedtimesheetentry=$submitted_timesheet_list;
				$associate_id=Session::get('associateuserdetails.result.id');
				$user_id=Session::get('userdetails.id');
					?>
				<tbody>
				<?php
					$i=0;
					foreach($submittedtimesheetentry as $index =>$entry){
					if($taskdetail_data['id']==$entry['TaskId']['id'] && $entry['isSubmitted']=='1' && $entry['isApproved']!='1' && $entry['isRejected']!='1' && $taskdetail_data['isTicket']!='1'){
							$i++;
						?>	
					<tr>
					  <td><?php echo $i;?></td>
					  <td><?php echo $entry['ProjectId']['Name'];?></td>
					  <td><?php echo $entry['TaskId']['name'];?></td>
					  <td><?php echo date('m-d-Y', strtotime($entry['DateAndTime']));?></td>	
					  <td><?php echo $entry['hours'];?></td>
					  <td><?php echo $entry['comments'];?></td>
					  <?php if(!empty(Session::get('userdetails.role')=='2')): ?> 
					  <td><?php echo TaskManageController::getAssignName($entry['associateId']['profileId']) ?></td>
					  <?php endif; ?>
					  <?php if(!empty(Session::get('userdetails.role')=='3')): ?> 
					  <td><?php echo TaskManageController::getAssignName($entry['approvelManager']['profileId']) ?></td>
					  <?php endif; ?>
					   <?php if(!empty(Session::get('userdetails.role')=='2')): ?> 
					  <td> 
						<span class="edit" data-toggle="modal" title="edit" data-target="<?php echo "#approve_rejecttimeentrymodal".$entry['id'];?>"><i class="fa fa-fw fa-edit"></i></span>&nbsp;&nbsp;&nbsp;
					  </td>
					<?php endif; ?>
					</tr>
					 <!-- Timeentry Submitted list Approved & Reject Modal Include start -->
						<?php echo $__env->make('task.approvedreject_timeentry_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					 <!-- Timeentry Submitted list Approved & Reject Modal Include end -->
					<?php }
					} ?>
				 </tbody>
				 <?php }?>
				 </table>
				 </div>
		<?php endif; ?>
		<?php else: ?>
		   	<span class="red">Currently don't have Task details.</span>
		<?php endif; ?>
      </div>
      <!-- Timeentry Create Modal Include start -->
					<?php echo $__env->make('task.addtimeentry_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	  <!-- Timeentry Create Modal Include end -->
	  <!-- Import Timeentry Modal Include start -->
					<?php echo $__env->make('task.import_tasktimeentry_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	  <!-- Import Timeentry Modal Include end -->
      
    </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>