<?php $__env->startSection('title', 'Emp Details'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
 <section class="content-header">
	<h1>
	Emp Details Page
	<small></small>
	</h1>
	<ol class="breadcrumb">
	<li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
	<li><a href="<?php echo e(url('/user_list')); ?>"><i class="fa fa-users"></i> Employee List</a></li>
	<li class="active">Employee Details</li>
	</ol>
</section>
<section class="content">
      <div class="row">
        <div class="col-md-12">
          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo e(asset('Admin/dist/img/usericon.png')); ?>" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo e($userprofiledetails['result']['name']); ?></h3>

              <p class="text-muted text-center"><?php echo e($userprofiledetails['result']['email']); ?></p>
              <!--<center><a href="#" class="btn btn-primary"><b>Update</b></a></center>-->
            </div>
              <div class="box-body table-responsive">
					 <!-- Table row start-->
  <!-- Tab Card Start-->
  <div class="card">
				<ul class="nav nav-tabs" role="tablist">
					<li role="presentation" class="active" ><a href="#todaytask" aria-controls="todaytask" role="tab" data-toggle="tab">Today Working Task</a></li>
					<li role="presentation"><a href="#projectlist" aria-controls="projectlist" role="tab" data-toggle="tab">Project List</a></li>
				</ul>
	<!-- Tab panes Start-->
				<div class="tab-content">
					<div role="tabpanel" class="tab-pane active" id="todaytask">
						<br/>
						<table class="table table-bordered table-striped" id="todaytask_datatable">
						<thead>
						<tr>
						<th>ID</th>
						<th>Name</th>
						<th class="desc">Description</th>
						<th>Status</th>
						<th>Created Date</th>
						<th>Created By</th>
						</tr>
						</thead>
						<tbody>
						<?php if(!empty($usertodayworkdetails)){
							$i=0;
						foreach($usertodayworkdetails['result'] as $index=>$list){
							$todaydate=date("Y-m-d");
							if($todaydate==$list['createdDate']){ 
								$i++;?>
							<?php $id=$list['id'];?>
						<tr>
						  <td><?php echo $i;?></td>
						  <td><a href="<?php echo "/ticketdetails/".$id;?>"><?php echo $list['Title'];?></a></td>
						  <td><?php echo $list['description'];?></td>
						  <td><span class="col-md-2 badge label_<?php echo HelperController::getticketStatus($list['state'])?>">
							  <?php if(!empty($list['state'])){ echo HelperController::getticketStatus($list['state']);}?></span></td>
						  <td><?php echo date('d-m-Y', strtotime($list['createdDate']));?></td>
						  <td><?php echo $list['createdbyUser']['name'];?></td>
						</tr>
						<?php }
							}
						}?>
						</tbody>
						</table>
					</div>
					<div role="tabpanel" class="tab-pane" id="projectlist">
						<br/>
						<table class="table table-bordered table-striped" id="project_datatable">
						<thead>
						<tr>
						<th>ID</th>
						<th>Name</th>
						<th>Start Date</th>
						<th>End Date</th>
						<th class="desc">Description</th>
						<th>Status</th>
						<!--<th>Actions</th>-->
						</tr>
						</thead>
						<tbody>
						<?php if(!empty($userwiseprojectlist)){
						foreach($userwiseprojectlist['result'] as $index=>$list){ ?>
							<?php $id=$list['id'];?>
						<tr>
						  <td><?php echo $index+1;?></td>
						  <td><a href="<?php echo "/project_details/".$id;?>"><?php echo $list['Name'];?></a></td>
						  <td><?php echo date('m-d-Y', strtotime($list['startDate']));?></td>
						  <td><?php echo date('m-d-Y', strtotime($list['endDate']));?></td>
						  <td><?php echo $list['desc'];?></td>
						  <td><span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
							  <?php if(!empty($list['state'])){ echo HelperController::getprojectStatus($list['state']);}?></span></td>
						  <!--<td><span class="edit" data-toggle="modal" data-target="#updateprojectModal"><i class="fa fa-fw fa-edit"></i></span>&nbsp;&nbsp;&nbsp;<span class="delete"><i class="fa fa-fw fa-trash"></i></span></td>-->
						</tr>
						<?php }
						}?>
						</tbody>
						</table>
					</div>
			    </div>
	<!-- Tab panes End-->	
   </div>
    <!-- Tab Card End-->
				</div>
			</div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>