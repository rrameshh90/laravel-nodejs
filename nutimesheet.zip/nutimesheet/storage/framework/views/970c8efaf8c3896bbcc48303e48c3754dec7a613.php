<div class="modal right fade" id="assignprojectModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="assignprojectLabel1">Assign Project</h4>
				</div>
				<div class="modal-body">
					<div class="row">
							<!-- left column -->
							<div class="col-md-12">
							  <!-- general form elements -->
							  <div class="box box-primary" id="projecttoassociate">
								<div class="box-header with-border">
								  <h3 class="box-title">Assign user to project</h3>
								</div>
								<!-- /.box-header -->
								<!-- form start -->
								<form role="form" method="POST" action="/projectassignuser">
									 <?php echo e(csrf_field()); ?>

								   <div class="box-body">
									  <input type="hidden" name="projectId" class="form-control" id="assignProjectId" value="<?php echo e($project_data['id']); ?>" required>
									<?php $userlist=Session::get('getallassociate');
									 $project_userlist=$project_user;
									if(!empty($userlist)){?>
									<div class="form-group">
									  <label for="SelectAssignuser">Select Associate User<span class="red">*</span></label>
									  <select multiple class="form-control"  name="associateId[]" required>
												<?php foreach($userlist  as $list){?>
												<option value="<?php echo $list['id'].','.$list['profileId']['id'];?>"><?php echo $list['profileId']['name'];?></option>
												<?php }?>
									  </select>
									</div>
									<?php }else{?>
										<div class="form-group">
									  <label for="SelectAssignuser">Select Associate User<span class="red">*</span></label>
									  <select multiple class="form-control" name="assign_user" disabled>
										  <option value="" selected>No Associate User</option>
									  </select>
									</div>
									<?php }?>
									 <input type="hidden" name="loggedInUserId" value="<?php echo e(Session::get('userdetails.id')); ?>" id="loggedin_id"></input>
								  </div>
								  <!-- /.box-body -->
								<?php if(!empty($userlist)){?>
								  <div class="box-footer">
									<button type="submit" class="btn btn-primary">Assign</button>
								  </div>
								<?php }else {?>
									<div class="box-footer">
									<button type="submit" class="btn btn-primary" disabled>Assign</button>
								  </div>
								<?php }?>
								</form>
							  </div>
				</div>
				</div><!-- modal-content -->
			</div><!-- modal-dialog -->
		</div><!-- modal -->
	  </div>
	</div>
