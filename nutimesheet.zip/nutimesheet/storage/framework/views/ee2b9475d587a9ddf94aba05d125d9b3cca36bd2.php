<?php $__env->startSection('title', 'Timesheet All Details'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
<section class="content-header">
	 <?php if(!empty(Session::get('userdetails.role')=='2')): ?>
	<h1>
	Timesheet All List Page
	<small></small>
	</h1>
	<?php else: ?>
	<h1>
	Timesheet Approved List Page
	<small></small>
	</h1>
	<?php endif; ?>
	<ol class="breadcrumb">
	<li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
	<li><a href="<?php echo e(url('/timesheetassociate')); ?>">Timesheet User List</a></li>
	<li class="active">Timesheet All List Page</li>
	</ol>
</section>
 <section class="content">
      <div class="row">
        <!-- left column -->
       <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 <?php if(Session::has($key)): ?>
			  <div class="alert alert-<?php echo e($key); ?> alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				<strong><?php echo e(Session::get($key)); ?></strong>
				</div>
				<?php endif; ?>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <section class="invoice">
		<div class="row table-responsive">
			  <div class="card">
				<ul class="nav nav-tabs" role="tablist">
					<?php if(!empty(Session::get('userdetails.role')=='2')): ?>
					<li role="presentation" class="active"><a href="#timesheetsubmittedlist" aria-controls="timesheetsubmittedlist" id="userwisetimesubmitted" role="tab" data-toggle="tab">Timesheet Submitted List</a></li>
					<?php endif; ?>
					<li role="presentation"><a href="#timesheetapprovedlist" id="userwisetimeapproved" aria-controls="timesheetapprovedlist" role="tab" data-toggle="tab">Timesheet Approved List</a></li>
					<?php if(!empty(Session::get('userdetails.role')=='2')): ?>
					<li role="presentation"><a href="#timesheetrejectedlist" aria-controls="timesheetrejectedlist" id="userwisetimerejected" role="tab" data-toggle="tab">Timesheet Rejected List</a></li>
					<?php endif; ?>
				</ul>

				<!-- Tab panes Start-->
				<div class="tab-content">
					<!-- Tab Submitted Timesheet list Start-->
					<div role="tabpanel" class="tab-pane active" id="timesheetsubmittedlist">
						 <br/>
						 <div class="box-body"> 
							<div class="box-body table-responsive">
											<div class="accordion" id="accordionsubmitted">
									<div class="accordion-group">
										<div class="accordion-heading-submitted custom-filter-search">
										<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionsubmitted" href="#collapseOne">
										 Custom Filters
										</a>
										</div>
									<div id="collapseOne" class="accordion-body collapse">
										<div class="accordion-inner">
											<div class="row">
												<div class="col-md-12">
															 <div class="form-group timesheet_filter">
																<label>Project Name :</label>
																<input type='text' id="project_name_field"  class='form-control submit_filter' data-column-index='1'>
															  </div>
																<div class="form-group timesheet_filter">
																<label>Task / Ticket Name :</label>
																<input type='text' id="ticket_task_field" class='form-control submit_filter' data-column-index='2'>
															  </div>
															  <div class="form-group timesheet_filter">
																<label>Start Date :</label>
																<div class="input-group date">
																<div class="input-group-addon">
																<i class="fa fa-calendar"></i>
																</div>
																<input type="text" name="min"  class="form-control" id="min_submitted" placeholder="Start Date" required>
																</div>
															  </div>
															   <div class="form-group timesheet_filter">
																<label>End Date :</label>
																<div class="input-group date">
																<div class="input-group-addon">
																<i class="fa fa-calendar"></i>
																</div>
																<input type="text" name="max"  class="form-control" id="max_submitted" placeholder="End Date" required>
																</div>
															  </div>
															  <div class="form-group timesheet_filter">
															  <b>Filter By Task / Ticket</b>
																		  <div class="radio">
																			<label>
																			  <input type="radio" class='submit_filter' name="optionsuserSubmitted" id="optionsuserSubmitted1" value="Task" data-column-index='8'>
																			  Task &nbsp;&nbsp;
																			</label>
																			<label>
																			  <input type="radio" class='submit_filter' name="optionsuserSubmitted" id="optionsuserSubmitted2" value="Ticket" data-column-index='8'>
																			   Ticket
																			</label>
																		  </div>
																  </div>
															<div style="clear:both;"></div>
															  <button id="reset_btn_id_submitted" class="pull-left">Reset Filter</button>
															  <br/>
															  <br/>
														</div>
													</div>
												</div>
											</div>
										</div>
								</div>
								  <table class="table table-bordered table-striped" id="timesheet_submitted_list">
									  <thead>
										<tr>
											<th>Sno</th>
											<th>Project Name</th>
											<th>Task / Ticket Name</th>
											<th>Date</th>
											<th>Hours</th>
											<th>Comments</th>
											<th>Submitted By</th>
											<th>Action</th>
											<th>Filter</th>
										</tr>
									</thead>
									<tbody>				
										<?php if(!empty($associatesubmittedtimesheetdata)){
											foreach($associatesubmittedtimesheetdata as $index=>$list){ ?>
												<?php $id=$list['id'];?>
											<tr>
											  <td><?php echo $index+1;?></td>
											   <?php if(!empty($list['ProjectId']['id']) && $list['isTicket']!='1'){?>
											  <td><a href="<?php echo "/project_details/".$list['ProjectId']['id'];?>"><?php echo $list['ProjectId']['Name'];?></a></td>
											  <?php }else if(!empty($list['ProjectId']['id']) && $list['isTicket']=='1'){?>
											  <td><a href="<?php echo "/project_details/".$list['ProjectId']['id'];?>"><?php echo $list['ProjectId']['Name'];?></a></td>
											  <?php }else{?>
											  <td> NA</td>	  
											  <?php }?>
											  <?php if(!empty($list['TaskId']['id']) && $list['isTicket']!='1'){?>
											  <td><a href="<?php echo "/taskdetails/".$list['TaskId']['id'];?>"><?php echo $list['TaskId']['name'];?></a></td>
											  <?php }else {?>
											  <td><a href="<?php echo "/ticketdetails/".$list['ticket']['id'];?>"><?php echo $list['ticket']['Title'];?></a></td>
											  <?php }?>
											  <td><?php echo date('d/m/Y', strtotime($list['DateAndTime']));?></td>	
											  <td><?php echo $list['hours'];?></td>
											  <td><?php echo $list['comments'];?></td>
											  <?php if(!empty(Session::get('userdetails.role')=='2')): ?>
												<td><?php echo TaskManageController::getAssignName($list['associateId']['profileId']) ?></td>
												 <td> 
													<span class="edit" data-toggle="modal" title="edit" data-target="<?php echo "#approve_rejecttimeentrymodal".$list['id'];?>"><i class="fa fa-fw fa-edit"></i></span>&nbsp;&nbsp;&nbsp;
												 </td>
											 <?php endif; ?>
											 <?php if(!empty(Session::get('userdetails.role')=='3')): ?>
												  <td><?php echo TaskManageController::getAssignName($list['approvelManager']['profileId']) ?></td>
											 <?php endif; ?>
											  <?php if($list['isTicket']!='1'){?>
											  <td><span class="task_name_label">Task</span></td>
											  <?php }else{?>
											  <td><span class="ticket_name_label">Ticket</span></td>
											  <?php }?>
											</tr>
										<!-- Timeentry Submitted list Approved & Reject Modal Include start -->
											<?php echo $__env->make('timesheet.timesheet_userwise_timesheet_submitted_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
										<!-- Timeentry Submitted list Approved & Reject Modal Include end -->
											<?php }
												
											}?>
									  </tbody>	
											 <tfoot>
												<tr>
													<th></th>
													<th></th>
													<th></th>
													<th></th>
													<th></th>
													<th></th>
													<?php if(!empty(Session::get('userdetails.role')=='2')): ?>
													<th></th>
													<?php endif; ?>
													<th colspan="2"></th>
												</tr>
											</tfoot>	 
									</table>  
							</div>
					</div>
				</div>
					<!-- Timesheet List for Submitted detaills End -->
					<!-- Tab Approved Timesheet list Start-->
					<div role="tabpanel" class="tab-pane" id="timesheetapprovedlist">
						 <br/>
						 <div class="box-body"> 
						<div class="box-body table-responsive">
						<div class="accordion-approved" id="accordionapproved">
						<div class="accordion-group">
							<div class="accordion-heading-approved custom-filter-search">
							<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionapproved" href="#collapseApproved">
							 Custom Filters
							</a>
							</div>
						<div id="collapseApproved" class="accordion-body collapse">
							<div class="accordion-inner">
								<div class="row">
									<div class="col-md-12">
												 <div class="form-group timesheet_filter">
													<label>Project Name :</label>
													<input type='text' id="project_name_field_app" class='form-control approved_filter' data-column-index='1'/>
												  </div>
													<div class="form-group timesheet_filter">
													<label>Task / Ticket Name:</label>
													<input type='text' id="ticket_task_field_app" class='form-control approved_filter' data-column-index='2'/>
												  </div>
												  <div class="form-group timesheet_filter">
													<label>Start Date :</label>
													<div class="input-group date">
													<div class="input-group-addon">
													<i class="fa fa-calendar"></i>
													</div>
													<input type="text" name="min"  class="form-control" id="min_approved" placeholder="Start Date" required />
													</div>
												  </div>
												   <div class="form-group timesheet_filter">
													<label>End Date :</label>
													<div class="input-group date">
													<div class="input-group-addon">
													<i class="fa fa-calendar"></i>
													</div>
													<input type="text" name="max"  class="form-control" id="max_approved" placeholder="End Date" required />
													</div>
												  </div>
												<div class="form-group timesheet_filter">
												  <b>Filter By Task / Ticket</b>
															  <div class="radio">
																<label>
																  <input type="radio" class='approved_filter' name="optionsuserApproved" id="optionsuserApproved1" value="Task" data-column-index='7' />
																  Task &nbsp;&nbsp;
																</label>
																<label>
															  <input type="radio" class='approved_filter' name="optionsuserApproved" id="optionsuserApproved2" value="Ticket" data-column-index='7'/>
																   Ticket
																</label>
															  </div>
													  </div>
												<div style="clear:both;"></div>
												  <button id="reset_btn_id_approved" class="pull-left">Reset Filter</button>
												  <br/>
												  <br/>
											</div>
										</div>
									</div>
								</div>
							</div>
					</div>
								  <table class="table table-bordered table-striped" id="timesheet_approved_list">
									  <thead>
										<tr>
											<th>Sno</th>
											<th>Project Name</th>
											<th>Task Name / Ticket Name</th>
											<th>Date</th>
											<th>Hours</th>
											<th>Comments</th>
											<th>Approved By</th>
											<th>Filter</th>
										</tr>
									</thead>
									<tbody>				
										<?php if(!empty($associateapprovedtimesheetdata)){
											foreach($associateapprovedtimesheetdata as $index=>$list){ ?>
												<?php $id=$list['id'];?>
												<?php $user_role = Session::get('userdetails.role');?>
											<tr>
											  <td><?php echo $index+1;?></td>
											  <?php if(!empty($list['ProjectId']) && $list['isTicket']!='1'){?>
											  <td><a href="<?php echo "/project_details/".$list['ProjectId'];?>"><?php echo HelperController::getProjectName($list['ProjectId']) ?></a></td>
											  <?php }elseif(!empty($list['ProjectId']) && $list['isTicket']=='1'){?>
											  <td><a href="<?php echo "/project_details/".$list['ProjectId'];?>"><?php echo HelperController::getProjectName($list['ProjectId']) ?></a></td>
											  <?php }else{?>
											  <td> NA </td>
											  <?php }?>
											  <?php if($user_role!='1'){?>
											   <?php if(!empty($list['TaskId']) && $list['isTicket']!='1' ){?>
											  <td><a href="<?php echo "/taskdetails/".$list['TaskId'];?>"><?php echo HelperController::getTaskName($list['TaskId']) ?></a></td>
											  <?php }else {?>
											  <td><a href="<?php echo "/ticketdetails/".$list['ticket'];?>"><?php echo HelperController::getTicketName($list['ticket']) ?></a></td>
											  <?php }?>
											  <?php }else{?>
												   <?php if(!empty($list['TaskId']) && $list['isTicket']!='1' ){?>
											  <td><?php echo HelperController::getTaskName($list['TaskId']) ?></td>
											  <?php }else {?>
											  <td><?php echo HelperController::getTicketName($list['ticket']) ?></td>
											  <?php }?>
											  <?php }?>
											  <td><?php echo date('d/m/Y', strtotime($list['DateAndTime']));?></td>	
											  <td><?php echo $list['hours'];?></td>
											  <td><?php echo $list['comments'];?></td>
											  <td><?php echo HelperController::getProjectManagerName($list['approvelManager']['profileId']) ?></td>
											  <?php if($list['isTicket']!='1'){?>
											  <td><span class="task_name_label">Task</span></td>
											  <?php }else{?>
											  <td><span class="ticket_name_label">Ticket</span></td>
											  <?php }?>
											</tr>
											<?php } 
												}
											  ?>
									  </tbody>	
									   <tfoot>
												<tr>
														<th></th>
														<th></th>
														<th></th>
														<th></th>
														<th></th>
														<th></th>
														<th colspan="2"></th>
													</tr>
												</tfoot>				 
										</table>  
								</div>
								</div>
					</div>
					<!-- Tab Approved Timesheet list End-->
					<!-- Tab Rejected Timesheet list Start-->
					<div role="tabpanel" class="tab-pane" id="timesheetrejectedlist">
						          <!-- Timesheet List for Rejected detaills Start-->
									<br/>
									 <div class="box-body"> 
										 <div class="box-body table-responsive">
												<div class="accordion-rejected" id="accordionrejected">
												<div class="accordion-group">
												<div class="accordion-heading-rejected custom-filter-search">
												<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionrejected" href="#collapseRejected">
												Custom Filters
												</a>
												</div>
												<div id="collapseRejected" class="accordion-body collapse">
												<div class="accordion-inner">
												<div class="row">
												<div class="col-md-12">
													 <div class="form-group timesheet_filter">
														<label>Project Name :</label>
														<input type='text' id="project_name_field_rej" class='form-control rejected_filter' data-column-index='1'>
													  </div>
														<div class="form-group timesheet_filter">
														<label>Task Name :</label>
														<input type='text' id="ticket_task_field_rej" class='form-control rejected_filter' data-column-index='2'>
													  </div>
													  <div class="form-group timesheet_filter">
														<label>Start Date :</label>
														<div class="input-group date">
														<div class="input-group-addon">
														<i class="fa fa-calendar"></i>
														</div>
														<input type="text" name="min"  class="form-control" id="min_rejected" placeholder="Start Date" required>
														</div>
													  </div>
													   <div class="form-group timesheet_filter">
														<label>End Date :</label>
														<div class="input-group date">
														<div class="input-group-addon">
														<i class="fa fa-calendar"></i>
														</div>
														<input type="text" name="max"  class="form-control" id="max_rejected" placeholder="End Date" required>
														</div>
													  </div>
														<div class="form-group timesheet_filter">
														  <b>Filter By Task / Ticket</b>
																	  <div class="radio">
																		<label>
																		  <input type="radio" class='rejected_filter' name="optionsuserRejected" id="optionsuserRejected1" value="Task" data-column-index='9'>
																		  Task &nbsp;&nbsp;
																		</label>
																		<label>
																		  <input type="radio" class='rejected_filter' name="optionsuserRejected" id="optionsuserRejected2" value="Ticket" data-column-index='9'>
																		   Ticket
																		</label>
																	  </div>
															  </div>
															<div style="clear:both;"></div>
															  <button id="reset_btn_id_rejected" class="pull-left">Reset Filter</button>
															  <br/>
															  <br/>
												</div>
												</div>
												</div>
												</div>
												</div>
												</div>
											  <table class="table table-bordered table-striped" id="timesheet_rejected_list">
												  <thead>
													<tr>
														<th>Sno</th>
														<th>Project Name</th>
														<th>Task Name / Ticket Name</th>
														<th>Date</th>
														<th>Hours</th>
														<th>Task Comments</th>
														<th>Rejected Comments</th>
														<th>Rejected Date</th>
														<th>Rejected By</th>
														<th>Filter</th>
													</tr>
												</thead>
												<tbody>				
													<?php if(!empty($associaterejectedtimesheetdata)){
														$i=0;
														foreach($associaterejectedtimesheetdata as $index=>$list){ ?>
															<?php $id=$list['id'];?>
														<tr>
														  <td><?php echo $index+1;?></td>
														  <?php if(!empty($list['submittedTimeSheetId']['ProjectId']) && $list['submittedTimeSheetId']['isTicket']!='1'){?>
															<td><a href="<?php echo "/project_details/".$list['submittedTimeSheetId']['ProjectId'];?>"><?php echo HelperController::getProjectName($list['submittedTimeSheetId']['ProjectId']) ?></a></td>
														   <?php }elseif(!empty($list['submittedTimeSheetId']['ProjectId']) && $list['submittedTimeSheetId']['isTicket']=='1'){?>
															<td><a href="<?php echo "/project_details/".$list['submittedTimeSheetId']['ProjectId'];?>"><?php echo HelperController::getProjectName($list['submittedTimeSheetId']['ProjectId']) ?></a></td>
														  <?php }else{?>
															<td> NA </td>
														   <?php }?>
														  <?php if(!empty($list['submittedTimeSheetId']['TaskId']) && $list['submittedTimeSheetId']['isTicket']!='1' ){?>
														  <td><a href="<?php echo "/taskdetails/".$list['submittedTimeSheetId']['TaskId'];?>"><?php echo HelperController::getTaskName($list['submittedTimeSheetId']['TaskId']) ?></a></td>
														  <?php }else {?>
														  <td><a href="<?php echo "/ticketdetails/".$list['submittedTimeSheetId']['ticket'];?>"><?php echo HelperController::getTicketName($list['submittedTimeSheetId']['ticket']) ?></a></td>
														  <?php }?>
														  <td><?php echo date('d/m/Y', strtotime($list['submittedTimeSheetId']['DateAndTime']));?></td>	
														  <td><?php echo $list['submittedTimeSheetId']['hours'];?></td>
														  <td><?php echo $list['submittedTimeSheetId']['comments'];?></td>
														  <td><?php echo $list['commentsBymanager'];?></td>
														  <td><?php echo date('d/m/Y', strtotime($list['rejectedDate']));?></td>
														  <td><?php echo TaskManageController::getAssignName($list['rejectedBy']['profileId']) ?></td>
														  <?php if($list['submittedTimeSheetId']['isTicket']!='1'){?>
														  <td><span class="task_name_label">Task</span></td>
														  <?php }else{?>
														  <td><span class="ticket_name_label">Ticket</span></td>
														  <?php }?>
														</tr>
														<?php }
															}
														?>
												  </tbody>
												   <tfoot>
															<tr>
																	<th></th>
																	<th></th>
																	<th></th>
																	<th></th>
																	<th></th>
																	<th></th>
																	<th></th>
																	<th colspan="2"></th>
																</tr>
															</tfoot>				 
													</table>  

											  </div>
											</div>	
								</div>
					<!-- Tab Rejected Timesheet list End-->
				</div>
				<!-- Tab panes End-->
			</div>
		</div>
	</section>

     </div>
     </section>
     <script>
	var $=jQuery;
  $(function () {
     /* Custom filtering function which will search data in column four between two values */
        $(document).ready(function () { 
        /** Userwise Submitted Date filter **/
            $.fn.dataTable.ext.search.push(
                function (settings, data, dataIndex) {
                    var min = $('#min_submitted').datepicker("getDate");
                    var max = $('#max_submitted').datepicker("getDate");
                    // need to change str order before making  date obect since it uses a new Date("mm/dd/yyyy") format for short date.
                    var d = data[3].split("/");
                    var startDate = new Date(d[1]+ "/" +  d[0] +"/" + d[2]);

                    if (min == null && max == null) { return true; }
                    if (min == null && startDate <= max) { return true;}
                    if(max == null && startDate >= min) {return true;}
                    if (startDate <= max && startDate >= min) { return true; }
                    return false;
                }
            );
            $("#min_submitted").datepicker({ onSelect: function () { table.draw(); }, changeMonth: true, changeYear: true , dateFormat:"dd/mm/yy"});
            $("#max_submitted").datepicker({ onSelect: function () { table.draw(); }, changeMonth: true, changeYear: true, dateFormat:"dd/mm/yy" });
            var table = $('#timesheet_submitted_list').DataTable();

            // Event listener to the two range filtering inputs to redraw on input
            $('#min_submitted, #max_submitted').change(function () {
                table.draw();
            });
            
            $("#userwisetimeapproved").click(function(){
           /** Userwise Approved Date filter **/
            $.fn.dataTable.ext.search.push(
                function (settings, data, dataIndex) {
                    var min = $('#min_approved').datepicker("getDate");
                    var max = $('#max_approved').datepicker("getDate");
                    // need to change str order before making  date obect since it uses a new Date("mm/dd/yyyy") format for short date.
                    var d = data[3].split("/");
                    var startDate = new Date(d[1]+ "/" +  d[0] +"/" + d[2]);

                    if (min == null && max == null) { return true; }
                    if (min == null && startDate <= max) { return true;}
                    if(max == null && startDate >= min) {return true;}
                    if (startDate <= max && startDate >= min) { return true; }
                    return false;
                }
            );
            $("#min_approved").datepicker({ onSelect: function () { table.draw(); }, changeMonth: true, changeYear: true , dateFormat:"dd/mm/yy"});
            $("#max_approved").datepicker({ onSelect: function () { table.draw(); }, changeMonth: true, changeYear: true, dateFormat:"dd/mm/yy" });
            var table = $('#timesheet_approved_list').DataTable();

            // Event listener to the two range filtering inputs to redraw on input
            $('#min_approved, #max_approved').change(function () {
                table.draw();
            });
			});
            $("#userwisetimerejected").click(function(){
            /** Userwise Rejected Date filter **/
            $.fn.dataTable.ext.search.push(
                function (settings, data, dataIndex) {
                    var min = $('#min_rejected').datepicker("getDate");
                    var max = $('#max_rejected').datepicker("getDate");
                    // need to change str order before making  date obect since it uses a new Date("mm/dd/yyyy") format for short date.
                    var d = data[3].split("/");
                    var startDate = new Date(d[1]+ "/" +  d[0] +"/" + d[2]);

                    if (min == null && max == null) { return true; }
                    if (min == null && startDate <= max) { return true;}
                    if(max == null && startDate >= min) {return true;}
                    if (startDate <= max && startDate >= min) { return true; }
                    return false;
                }
            );
            $("#min_rejected").datepicker({ onSelect: function () { table.draw(); }, changeMonth: true, changeYear: true , dateFormat:"dd/mm/yy"});
            $("#max_rejected").datepicker({ onSelect: function () { table.draw(); }, changeMonth: true, changeYear: true, dateFormat:"dd/mm/yy" });
            var table = $('#timesheet_rejected_list').DataTable();

            // Event listener to the two range filtering inputs to redraw on input
            $('#min_rejected, #max_rejected').change(function () {
                table.draw();
            });
			});
        });
     });
     </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>