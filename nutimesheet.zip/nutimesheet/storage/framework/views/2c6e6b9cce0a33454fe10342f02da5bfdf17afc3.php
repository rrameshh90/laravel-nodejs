<?php echo $__env->make('layouts.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.partials.topbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="clearfix"></div>
<div class="page-container">
<div class="wrapper">
 <!-- Sidebar -->
	<?php echo $__env->make('layouts.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
		<?php echo $__env->yieldContent('content'); ?>
  </div>
  <!-- /.content-wrapper -->


</div>
<!-- ./wrapper -->
</div>
<!-- Scripts links -->
<?php echo $__env->make('layouts.partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Footer -->
<?php echo $__env->make('layouts.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

