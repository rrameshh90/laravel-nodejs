<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
<?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				 <?php if(Session::has($key)): ?>
				 <div class="alert alert-<?php echo e($key); ?> alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong> <?php echo e(Session::get($key)); ?></strong>
				</div>
				<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/')); ?>" class="home_dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
		<?php if(!empty(Session::get('userdetails.role')=='1') || !empty(Session::get('userdetails.role')=='2') || !empty(Session::get('userdetails.role')=='3')): ?>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
			 <?php if(!empty(Session::get('userdetails.role')!='3')): ?>
				<?php if(!empty(Session::get('dashboard_projectcount'))): ?>
				  <h3><?php echo e(Session::get('dashboard_projectcount')); ?></h3>
				  <?php else: ?>
				  <h3><?php echo e(0); ?></h3>
				<?php endif; ?>
			 <?php endif; ?>
             <?php if(!empty(Session::get('userdetails.role')=='3')): ?>
                <?php if(!empty(Session::get('associateprojectcount'))): ?>
				  <h3><?php echo e(Session::get('associateprojectcount')); ?></h3>
				  <?php else: ?>
				  <h3><?php echo e(0); ?></h3>
				<?php endif; ?>
              <?php endif; ?>
              <p>Project Info</p>
            </div>
            <div class="icon">
              <i class="fa fa-th-large"></i>
            </div>
            <a href="<?php echo e(url('/project_list')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <?php endif; ?>
        <?php if(!empty(Session::get('userdetails.role')=='1')): ?>
		<!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <?php if(!empty(Session::get('dashboard_usercount'))): ?>
              <h3><?php echo e(Session::get('dashboard_usercount')); ?></h3>
              <?php else: ?>
              <h3><?php echo e(0); ?></h3>
              <?php endif; ?>
              <p>User Registrations</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="<?php echo e(url('/user_list')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
         <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <?php if(!empty(Session::get('dashboard_usercount'))): ?>
              <h3><?php echo e(Session::get('dashboard_usercount')); ?></h3>
              <?php else: ?>
              <h3><?php echo e(0); ?></h3>
              <?php endif; ?>
              <p>Userwise Today Task</p>
            </div>
            <div class="icon">
              <i class="fa fa-tasks"></i>
            </div>
            <a href="<?php echo e(url('/user_list')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <?php endif; ?>
        <!-- ./col -->
        <?php if(!empty(Session::get('userdetails.role')=='3')): ?>
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-green">
            <div class="inner"> 
			  <?php if(!empty(Session::get('associatetaskcount'))): ?>
              <h3><?php echo e(Session::get('associatetaskcount')); ?></h3>
              <?php else: ?>
              <h3><?php echo e(0); ?></h3>
              <?php endif; ?>
             
              <p>Task Info</p>
            </div>
            <div class="icon">
              <i class="fa fa-tasks"></i>
            </div>
            <?php if(!empty(Session::get('userdetails.role')=='3')): ?>
            <a href="<?php echo e(url('/mytasklist')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              <?php elseif(!empty(Session::get('userdetails.role')=='1') || !empty(Session::get('userdetails.role')=='2')): ?>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              <?php endif; ?>
          </div>
        </div>
        <?php endif; ?>
        <!-- ./col -->
        <?php if(!empty(Session::get('userdetails.role')=='3')): ?>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              
              <?php if(!empty(Session::get('associate_timesheetcount'))): ?>
              <h3><?php echo e(Session::get('associate_timesheetcount')); ?></h3>
              <?php else: ?>
              <h3><?php echo e(0); ?></h3>
              <?php endif; ?>
              <p>Saved Timesheet</p>
            </div>
            <div class="icon">
              <i class="ion ion-clipboard"></i>
            </div>
            <a href="<?php echo e(url('/timesheet')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <?php endif; ?>
        
         <?php if(!empty(Session::get('userdetails.role')=='2') || !empty(Session::get('userdetails.role')=='3')): ?>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              
              <?php if(!empty(Session::get('submitted_timesheetlistcount'))): ?>
              <h3><?php echo e(Session::get('submitted_timesheetlistcount')); ?></h3>
              <?php else: ?>
              <h3><?php echo e(0); ?></h3>
              <?php endif; ?>
              <p>Submitted Timesheet</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
             <?php if(!empty(Session::get('userdetails.role')=='2')): ?>
            <a href="<?php echo e(url('/submittedtimesheetlist')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
			<?php else: ?>
             <a href="<?php echo e(url('/submittedtimesheetlist')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            <?php endif; ?>
          </div>
        </div>
        <?php endif; ?>
        <!-- ./col -->
      </div>
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12">
          <!-- Project List -->
          <div class="box box-primary">
            <div class="box-header">
              <i class="ion ion-clipboard"></i>
              <h3 class="box-title">Project List</h3>
            </div>
            
            
            <!-- /.box-header -->
            <div class="box-body">
				<?php $dashboard_project=Session::get('dashboard_project');?>
				<?php if(!empty(Session::get('userdetails.role')=='2')): ?>
				<?php if(!empty($dashboard_project)){?>
						<strong>Project Status Count: </strong><br> 
						<?php
						$taskstatus=array();
						foreach($dashboard_project as $project){
							$projectstatus[]=$project['state'];
						}
						$counts = array_count_values($projectstatus);
						$total=0;
							foreach($counts as $count){
									$total+=$count;
							}?>
					<address class="task-count-section">
						<?php if(!empty($counts['1'])){?>
						<span class="badge new-label">New <span id="new-count">(<?php echo e($counts['1']); ?>)</span></span>
						<?php }if(!empty($counts['2'])){?>
						<span class="badge inprogress-label">InProgress <span id="inprogress-count">(<?php echo e($counts['2']); ?>)</span></span>
						<?php }if(!empty($counts['3'])){?>
						<span class="badge delayed-label">Deloyed <span id="delayed-count">(<?php echo e($counts['3']); ?>)</span></span>
						<?php }if(!empty($counts['4'])){?>
						<span class="badge closed-label">Closed <span id="closed-count">(<?php echo e($counts['4']); ?>)</span></span>
						<?php }if(!empty($counts['5'])){?>
						<span class="badge deleted-label">Deleted <span id="deleted-count">(<?php echo e($counts['5']); ?>)</span></span>
						<?php }if(!empty($total)){?>
						<span class="badge total-label">Total <span id="total-count">(<?php echo e($total); ?>)</span></span>
						<?php }?>
					</address>
				    <?php }?>
				<?php endif; ?>
              <!-- See dist/js/pages/dashboard.js to activate the todoList plugin -->
                   <div class="box-body table-responsive">
              <table class="table table-bordered table-striped" id="project_datatable">
				  <thead>
					<tr>
					  <th>ID</th>
					  <th>Name</th>
					  <th>Start Date</th>
					  <th>End Date</th>
					  <th class="desc">Description</th>
					  <th>Status</th>
					  <!--<th>Actions</th>-->
					</tr>
                </thead>
                 <?php if(!empty(Session::get('userdetails.role')=='1') || !empty(Session::get('userdetails.role')=='2')): ?>
                <tbody>	
                 <?php if(!empty($dashboard_project)){
						foreach($dashboard_project as $index=>$list){ ?>
							<?php $id=$list['id'];?>
						<tr>
						  <td><?php echo $index+1;?></td>
						  <td><a href="<?php echo "/project_details/".$id;?>"><?php echo $list['Name'];?></a></td>
						  <td><?php echo date('d-m-Y', strtotime($list['startDate']));?></td>
						  <td><?php echo date('d-m-Y', strtotime($list['endDate']));?></td>
						  <td><?php echo $list['desc'];?></td>
						  <td><?php if(!empty($list['state'])){?>
							  <?php $todaydate=date("d-m-Y");?>
							  <?php if(date('d-m-Y', strtotime($list['startDate'])) <= $todaydate){
										if($list['state']=='1'){
										$list['state']='2';?>
										<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php $loggedInUserId=Session::get('user_id'); 
												  $projectid=$list['id'];
												  $project_name=$list['Name'];
												  $project_desc=$list['desc'];
												  $project_status=$list['state'];
											if(!empty($loggedInUserId) && !empty($projectid) && !empty($project_name) && !empty($project_desc) && !empty($project_status)){	  
										      $statusid=HelperController::UpdateProjectStatus($loggedInUserId,$projectid,$project_name,$project_desc,$project_status);
											  if(!empty($statusid['state'])){
												  $list['state']=$statusid['state'];
											  }
											}?>
											<?php echo HelperController::getprojectStatus($list['state']);?>
											</span>
											<?php }else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
												<?php echo HelperController::getprojectStatus($list['state']);?>
											</span>
											<?php }
											}elseif(date('d-m-Y', strtotime($list['endDate'])) == $todaydate){
											if($list['state']!='3' || $list['state']!='4'){
												$list['state']='3';?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php $loggedInUserId=Session::get('user_id'); 
												  $projectid=$list['id'];
												  $project_name=$list['Name'];
												  $project_desc=$list['desc'];
												  $project_status=$list['state'];
													if(!empty($loggedInUserId) && !empty($projectid) && !empty($project_name) && !empty($project_desc) && !empty($project_status)){	  
													 $statusid=HelperController::UpdateProjectStatus($loggedInUserId,$projectid,$project_name,$project_desc,$project_status);
													  if(!empty($statusid['state'])){
														  $list['state']=$statusid['state'];
													  }
													}?>
													<?php echo HelperController::getprojectStatus($list['state']);?>
											</span>
											<?php }else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
												<?php echo HelperController::getprojectStatus($list['state']);?>
										    </span>
											<?php }
											}else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php echo HelperController::getprojectStatus($list['state']);?>
											</span>
											<?php }?>
											<?php }?>
						  </td>
						  <!--<td><span class="edit" data-toggle="modal" data-target="#updateprojectModal"><i class="fa fa-fw fa-edit"></i></span>&nbsp;&nbsp;&nbsp;<span class="delete"><i class="fa fa-fw fa-trash"></i></span></td>-->
						</tr>
						<?php }
						}else{?>
						<tr>
							<td colspan="5"><center><span class="red">No Project found</span></center></td>
						</tr>
						<?php }?>
				  </tbody>
				   <?php elseif(!empty(Session::get('userdetails.role')=='3')): ?>
				   <tbody>
					<?php $dashboard_associateproject=Session::get('associateuserdetails');?>
                 <?php if(!empty($dashboard_associateproject['result'])){
						foreach($dashboard_associateproject['result']['Projects'] as $index=>$list){ ?>
							<?php $id=$list['id'];?>
						<tr>
						  <td><?php echo $index+1;?></td>
						  <td><a href="<?php echo "/project_details/".$id;?>"><?php echo $list['Name'];?></a></td>
						  <td><?php echo date('d-m-Y', strtotime($list['startDate']));?></td>
						  <td><?php echo date('d-m-Y', strtotime($list['endDate']));?></td>
						  <td><?php echo $list['desc'];?></td>
						   <td><?php if(!empty($list['state'])){?>
							  <?php $todaydate=date("m-d-Y");?>
							  <?php if(date('d-m-Y', strtotime($list['startDate'])) <= $todaydate){
										if($list['state']=='1'){
										$list['state']='2';?>
										<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php $loggedInUserId=Session::get('user_id'); 
												  $projectid=$list['id'];
												  $project_name=$list['Name'];
												  $project_desc=$list['desc'];
												  $project_status=$list['state'];
											if(!empty($loggedInUserId) && !empty($projectid) && !empty($project_name) && !empty($project_desc) && !empty($project_status)){	  
										      $statusid=HelperController::UpdateProjectStatus($loggedInUserId,$projectid,$project_name,$project_desc,$project_status);
											  if(!empty($statusid['state'])){
												  $list['state']=$statusid['state'];
											  }
											}?>
											<?php echo HelperController::getprojectStatus($list['state']);?>
											<?php }else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
												<?php echo HelperController::getprojectStatus($list['state']);?>
											</span>
											<?php }
											}elseif(date('d-m-Y', strtotime($list['endDate'])) == $todaydate){
											if($list['state']!='3' || $list['state']!='4'){
												$list['state']='3';?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php $loggedInUserId=Session::get('user_id'); 
												  $projectid=$list['id'];
												  $project_name=$list['Name'];
												  $project_desc=$list['desc'];
												  $project_status=$list['state'];
													if(!empty($loggedInUserId) && !empty($projectid) && !empty($project_name) && !empty($project_desc) && !empty($project_status)){	  
													 $statusid=HelperController::UpdateProjectStatus($loggedInUserId,$projectid,$project_name,$project_desc,$project_status);
													  if(!empty($statusid['state'])){
														  $list['state']=$statusid['state'];
													  }
													}?>
													<?php echo HelperController::getprojectStatus($list['state']);?>
											</span>
											<?php }else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
												<?php echo HelperController::getprojectStatus($list['state']);?>
											</span>
											<?php }
											}else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php echo HelperController::getprojectStatus($list['state']);?>
											</span>
											<?php }?>
											<?php }?>
						  </td>
						  <!--<td><span class="edit" data-toggle="modal" data-target="#updateprojectModal"><i class="fa fa-fw fa-edit"></i></span>&nbsp;&nbsp;&nbsp;<span class="delete"><i class="fa fa-fw fa-trash"></i></span></td>-->
						</tr>
						<?php }
						}else{?>
						<tr>
							<td colspan="5"><center><span class="red">No Project found</span></center></td>
						</tr>
						<?php }?>
				  </tbody>
				 <?php endif; ?> 
				</table>
            </div>
            </div>
            <!-- /.box-body -->
            <?php if(!empty(Session::get('userdetails.role')=='2')): ?>
            <div class="box-footer clearfix no-border">
              <a href="<?php echo e(url('/create_project')); ?>" class="btn btn-default pull-right"><i class="fa fa-plus"></i> Add Project</a>
            </div>
            <?php endif; ?>
          </div>
        </section>
        <!-- /.Left col -->
      </div>
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>