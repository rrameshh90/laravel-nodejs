<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

Route::get('/login', function (Request $request) {
	$userId=$request->session()->get('user_id');
	if(!empty($userId)){
		return redirect('/');
	}else{		
       return view('auth/login');
	}
});

//Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');
Route::get('login/google', 'Auth\LoginController@redirectToProvider');
Route::get('login/google/callback', 'Auth\LoginController@handleProviderCallback');
//Route::get('/', 'Auth\LoginController@index');
Route::get('/', 'UserController@dashboard');
/* User Related Routes */
Route::get('/dashboard', 'UserController@authenticate');
Route::get('/create_user', 'UserManageController@create');
Route::post('/usersubmit', 'UserManageController@store');
Route::get('/userprofile', 'UserManageController@show');
Route::get('/user_list', 'UserManageController@index');
Route::get('/user_onboard_list', 'UserManageController@getOnboardUser');
Route::get('/user_offboard_list', 'UserManageController@getOffboardUser');
Route::post('/updateuserdetails', 'UserManageController@Updateuser');
Route::get('/userdelete/{id}', 'UserManageController@Deleteuser');
Route::get('/userdetails/{id}', 'UserManageController@Userwisealldetails');
Route::post('/restoreexistinguser/', 'UserManageController@RestoreExistinguser');
Route::post('/rolechangeexistinguser/', 'UserManageController@ChangeRoleExistinguser');
/* Project related Routes */
Route::get('/create_project', 'ProjectManageController@create');
Route::post('/projectsubmit', 'ProjectManageController@store');
Route::get('/project_list', 'ProjectManageController@index');
Route::get('/project_details/{id}', 'ProjectManageController@show');
Route::post('/projectassignuser', 'ProjectManageController@projectAssignUser');
Route::post('/updateprojectdetails', 'ProjectManageController@UpdateProjectdetail');
Route::get('/removememberfromproject/{id}/{project_id}', 'ProjectManageController@RemoveMemberFromProject');
/* Task Related Routes */
Route::post('/addtasksubmit', 'TaskManageController@store');
Route::get('/mytasklist', 'TaskManageController@mytasklist');
Route::get('/taskdetails/{id}', 'TaskManageController@show');
Route::post('/updatetaskdetails', 'TaskManageController@UpdateTaskdetail');
Route::post('/addmemberfromtask', 'TaskManageController@AddMemberFromTask');
Route::post('/removememberfromtask', 'TaskManageController@RemoveMemberFromTask');
/* Timesheet Routes */
Route::get('/timesheet', 'TimesheetManageController@index');
Route::post('/newentrysubmit', 'TimesheetManageController@store');
Route::post('/updateentrysubmit', 'TimesheetManageController@UpdateTimeEntry');
Route::get('/removetimesheet/{entry_id}/{associate_id}/{loggedinUser_id}/{task_id}', 'TimesheetManageController@DeleteTimesheet');
Route::get('/submittimesheet/{entry_id}/{loggedinUser_id}/{task_id}', 'TimesheetManageController@SubmitTimesheet');
Route::get('/submittedtimesheetlist', 'TimesheetManageController@getAllSubmittedTimesheet');
Route::post('/approvedandrejecttimesheet', 'TimesheetManageController@Submissionapprovedandreject');
Route::get('/approvedtimesheetlist', 'TimesheetManageController@getApprovedTimesheet');
Route::get('/rejectedtimesheetlist', 'TimesheetManageController@getRejectedTimesheet');
/** Resubmission Api Hit Url Start **/
Route::post('/taskresubmissionentrysubmit', 'TimesheetManageController@getTaskTimesheetResubmission');
Route::post('/ticketresubmissionentrysubmit', 'TimesheetManageController@getTicketTimesheetResubmission');
/** Resubmission Api Hit Url End **/
/** DeleteRejected list Api Hit Url Start **/
Route::get('/removetaskrejectedtimesheet/{entry_id}/{associate_id}/{loggedinUser_id}', 'TimesheetManageController@TaskRejectDeleteTimesheet');
Route::get('/removeticketrejectedtimesheet/{entry_id}/{associate_id}/{loggedinUser_id}/{ticket_id}', 'TimesheetManageController@TicketRejectDeleteTimesheet');
/** DeleteRejected list Api Hit Url End **/
/** Get all associate user listing **/
Route::get('/timesheetassociate', 'TimesheetManageController@getTimesheetAssociates');
/** Get all project listing **/
Route::get('/allprojectlisttimesheet', 'TimesheetManageController@getAllProjectTimesheetDetails');
/** Get the userwise timesheet details**/
Route::get('/associatetimesheetdetails/{profile_id}', 'TimesheetManageController@getAssociateTimesheetDetails');
/** Ticket Related Timesheet action **/
Route::post('/ticketnewentrysubmit', 'TimesheetManageController@Tickettimestore');
Route::post('/ticketupdateentrysubmit', 'TimesheetManageController@TicketUpdateTimeEntry');
Route::get('/ticketremovetimesheet/{entry_id}/{associate_id}/{loggedinUser_id}/{ticket_id}', 'TimesheetManageController@TicketDeleteTimesheet');
Route::get('/ticketsubmittimesheet/{entry_id}/{loggedinUser_id}/{ticket_id}', 'TimesheetManageController@TicketSubmitTimesheet');
Route::post('/ticketapprovedandrejecttimesheet', 'TimesheetManageController@TicketSubmissionapprovedandreject');

/* Tickets Routes */
Route::get('/ticket_list', 'TicketManageController@index');
Route::get('/ticket_create', 'TicketManageController@create');
Route::post('/projectassignee', 'AjaxController@getProjectAssociateuser');
Route::post('/ticketcreatesubmit', 'TicketManageController@store');
Route::post('/updateticketdetails', 'TicketManageController@UpdateTicketdetail');
Route::get('/ticketdetails/{id}', 'TicketManageController@show');

/* Import Task & Ticket Timeentry */
Route::post('/importtasktimeentrysubmit', 'TimesheetManageController@ImportTasktimestore');
Route::post('/importtickettimeentrysubmit', 'TimesheetManageController@ImportTickettimestore');

/* User logout */
Route::get('/logout', 'Auth\LoginController@logout');
