<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Socialite;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use Mail;
class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/dashboard';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
    /**
     * Redirect the user to the GitHub authentication page.
     *
     * @return \Illuminate\Http\Response
     */
      public function index(Request $request)
    {
		$userId=$request->session()->get('user_id');
		if (!empty($userId)) {
            return view('dashboard');
        }else{
			return redirect('/login');
		}
	}
	
    public function redirectToProvider()
    {
        return Socialite::driver('google')->redirect();
    }

    /**
     * Obtain the user information from GitHub.
     *
     * @return \Illuminate\Http\Response
     */
    public function handleProviderCallback(Request $request)
    {
        $user = Socialite::driver('google')->stateless()->user();
        //API URL
		$url=config('app.resturl').'NuTimeSheetApi/UserProfile/userLoginValidation';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		//$loginvalidation = json_encode(array("email" => 'rhls94@gmail.com'));
		$loginvalidation = json_encode(array("email" => $user->getEmail()));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loginvalidation);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if(!empty($resultdetails)){
		if($httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'Logged in successfully!');
			return Redirect::action('UserController@authenticate', array('userdetails'=>$result,'gmaildetail'=>$user));
		}else{
			$message=$resultdetails['StatusInfo']['message'];
			 $request->session()->flash('danger', $message);
			 return redirect('/login');
		}
		}else{
			 $request->session()->flash('danger', "Unable to login right now. please try again after some time");
			 return redirect('/login');
		}
		

    }
    public function logout(Request $request){
		
		 $request->session()->flush();
		 $request->session()->regenerate();
		 $request->session()->flash('success', 'User SignOut Successfully!');
		 return redirect('/login');
		
	}
  
    
}
