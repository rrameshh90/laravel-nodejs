<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use View;
use Mail;
class TaskManageController extends Controller
{
    public function store(Request $request)
    {
		$input = $request->all();
		$taskname=$input['task_name'];
		$projectid=$input['task_projectid'];
		$loggedin_id=$input['loggedin_id'];
		
		if(!empty($input['associateId'])){
			$associate_ids=array();
			foreach($input['associateId'] as $associate_id){
				$associate_ids[]=$associate_id;
			}
		}
		$startdate=date('Y-m-d', strtotime($input['task_startdate']));
		$enddate=date('Y-m-d', strtotime($input['task_enddate']));
		if(!empty($taskname) && !empty($projectid) && !empty($startdate) && !empty($enddate) && !empty($loggedin_id)){
		$url=config('app.resturl').'NuTimeSheetApi/Project/Task/CreateTaskWithoutUserIds';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$taskcreate = json_encode(array("name" => $taskname,"projectId" => $projectid,
		"loggedInUserId" => $loggedin_id,"startDate" => $startdate,"endDate" => $enddate));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $taskcreate);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		$redirectpath="/project_details/".$projectid;
		/* Assign Task to User */
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='201'){
		if(!empty($associate_ids) && !empty($resultdetails['result']['id'])){
		$taskid=$resultdetails['result']['id'];
		$taskassigndetailsarray=array();
		$profileids=array();
		foreach($associate_ids as $id){
		$associateids = explode(',', $id);
		$associateid=$associateids[0];
		$url=config('app.resturl').'NuTimeSheetApi/Project/assignTaskToProjectMember';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$taskcreatewithassign = json_encode(array("loggedInUserId" => $loggedin_id,"taskId" => $taskid,
		"associateId" => $associateid));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $taskcreatewithassign);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$taskassigndetailsarray[] = json_decode($result,true);
		$profile_ids[]=$associateids[1];
		}
		foreach($taskassigndetailsarray as $taskassigndetails){
		 if($httpcode=='201' || $httpcode=='200' && !empty($taskassigndetails['StatusCode']) && $taskassigndetails['StatusCode']=='200'){
			 
			 if(!empty($profile_ids)){
				foreach($profile_ids as $profileid){
				$addedprofiledetails=HelperController::getProfileInfo($profileid);
							try {
								if(!empty($resultdetails['result'])){
									$result=$resultdetails['result'];
									$bodycontent='You are assigned to New task of "'.$result['name'].'"';
									$loggedindetails=$request->session()->get('userdetails');
								$data = array('name'=>$addedprofiledetails['name'],'email'=>$addedprofiledetails['email'],'from'=>$loggedindetails['email'],'from_name'=>$loggedindetails['name'],'headercontent'=>"Nu Timesheet User Assigned To New Task Notification",'body' =>$bodycontent,);
								Mail::send('emails.project_action', $data, function($message) use ($data){
								//$message->from($data['from'],$data['from_name']);
								$message->to($data['email'], $data['name'])
								->subject('User Added on the Created Task');
								});
								}

							$request->session()->flash('success', 'Task created and Assigned & Mail Sent successfully!');
							$request->session()->put('associatetask',$taskcreatewithassign);
							} catch (Exception $ex) {
			  
							$request->session()->flash('success', 'Task created and Assigned successfully!');
							$request->session()->put('associatetask',$taskcreatewithassign);
						}
					}
				}else{
			$request->session()->flash('success', 'Task created and Assigned successfully!');
			$request->session()->put('associatetask',$taskcreatewithassign);
			}
			
			return redirect($redirectpath);
		 }else{
			 $message=$taskassigndetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
			}
		}
		}	
			}else{
			$request->session()->flash('success', 'Task created successfully!');
			return redirect($redirectpath);
			}
		}else{
			$message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
			}
		}
		}else{
			$request->session()->flash('danger', 'Task not created please enter valid inputs');
			return redirect($redirectpath);
		}
    }
    public function mytasklist(Request $request)
    {
		return view('task.task_list');
	}
	
	public static function getAssignName($id){
		$profile_id=$id;
		if(!empty($profile_id)){
		$url=config('app.resturl').'NuTimeSheetApi/UserProfile/getProfileDetailsById';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$assigndetails = json_encode(array("profileId" => $profile_id));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $assigndetails);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		if(!empty($resultdetails['result']['name'])){
		return $resultdetails['result']['name'];
		}else{
			return "No Assignee";
		}
		}
		}
		
	}
	
	public function show($taskid,Request $request)
	{
		if(!empty($taskid)){
		$url=config('app.resturl').'NuTimeSheetApi/Project/taskDetailsByTaskid';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$taskdetails = json_encode(array("taskId" => $taskid));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $taskdetails);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		$userId=$request->session()->get('user_id');
		$userrole=$request->session()->get('user_role');
		$getalltimesheets = $this->getSavedTimesheet($userId,$request);
		if($userrole=='2' || $userrole=='3'){
		$getsubmittedtimesheets = $this->getSubmittedTimesheet($userId,$request);
		}
		//$getapprovedtimesheets = $this->getApprovedTimesheet($userId,$request);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		$data['taskdetail_data'] = $resultdetails['result'];
		if(!empty($getalltimesheets)){
			$data['savedtimesheet_list'] = $getalltimesheets;
		}
		if(!empty($getsubmittedtimesheets)){
			$data['submitted_timesheet_list'] = $getsubmittedtimesheets;
		}
		/*if(!empty($getapprovedtimesheets)){
			$data['approved_timesheet_list'] = $getapprovedtimesheets;
		}*/
			return view('task.task_details', $data);
		}else{
		 $request->session()->flash('danger', 'Unable view Task details right now.Please try after some time!');
		 return redirect('/project_list');
		}	
		}
	}
	public function getSavedTimesheet($userId,$request)
	{
		/* Get the Associate Saved Timesheet list */
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/getSavedTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$loggedinId = json_encode(array("loggedInUserId" => $userId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinId);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		$request->session()->put('associate_timesheetlist', $resultdetails['result']);
		 return $resultdetails['result'];
		}	
		}
	
	}
	
	public function getSubmittedTimesheet($userId,$request)
	{
		/* Get the Associate Submitted Timesheet list */
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/getSubmittedTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		curl_setopt($ch, CURLOPT_URL, $url.'?loggedInUserId='.$userId);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		$request->session()->put('submitted_timesheetlist', $resultdetails['result']);
		$request->session()->put('submitted_timesheetlistcount', count($resultdetails['result']));
		return $resultdetails['result'];
		}	
		}
	
	}
	
	Public function UpdateTaskdetail(Request $request){
		
		$input=$request->all();
		if(!empty($input['associateId'])){
		$associate_id=$input['associateId'];
		}
		$redirectpath="/project_details/".$input['task_projectid'];
		if(!empty($input['loggedin_id']) && !empty($input['task_id']) && !empty($input['task_name']) && !empty($input['task_status'])){
		$url=config('app.resturl').'NuTimeSheetApi/Project/editTaskDetails';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$updatetaskdetails = json_encode(array("loggedInUserId" => $input['loggedin_id'],"taskId" => $input['task_id'],
		"name" => $input['task_name'],"state" => $input['task_status']));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $updatetaskdetails);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);	
		if(!empty($resultdetails)){
			/* Assign Task to User */
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200' || $resultdetails['StatusCode']=='207'){
			$request->session()->flash('success', 'Task Updated successfully!');
			return redirect($redirectpath);
			}
		}else{
			$message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
			}
		}
		}else{
			$request->session()->flash('danger', 'Task not Updated please enter valid inputs');
			return redirect($redirectpath);
		}
	}
	
	Public function RemoveMemberFromTask(Request $request){
		
		$input=$request->all();
		$redirectpath="/project_details/".$input['task_projectid'];
		if(!empty($input['loggedin_id']) && !empty($input['task_id']) && !empty($input['assignee'])){
		$associateids = explode(',', $input['assignee']);
		$associateid=$associateids[0];
		$url=config('app.resturl').'NuTimeSheetApi/Project/removeUserFromTask';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$removeassignee = json_encode(array("loggedInUserId" => $input['loggedin_id'],"taskId" => $input['task_id'],
		"associateId" => $associateid));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $removeassignee);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);	
		$profile_id=$associateids[1];
		if(!empty($resultdetails)){
		if($httpcode=='201'|| $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			 if(!empty($profile_id)){
				$addedprofiledetails=HelperController::getProfileInfo($profile_id);
							try {
								if(!empty($resultdetails['result'])){
									$result=$resultdetails['result'];
									$bodycontent='You are removed from Existing task of "'.$result['name'].'"';
									$loggedindetails=$request->session()->get('userdetails');
								$data = array('name'=>$addedprofiledetails['name'],'email'=>$addedprofiledetails['email'],'from'=>$loggedindetails['email'],'from_name'=>$loggedindetails['name'],'headercontent'=>"Nu Timesheet User Removed From The Existing task Notification",'body' =>$bodycontent,);
								Mail::send('emails.project_action', $data, function($message) use ($data){
								//$message->from($data['from'],$data['from_name']);
								$message->to($data['email'], $data['name'])
								->subject('User Removed from the Existing Task');
								});
								}

							$request->session()->flash('success', 'Remove Member from the Task & Mail Sent Successfully!');
							} catch (Exception $ex) {
			  
							$request->session()->flash('success', 'Remove Member from the Task Successfully!');
						}
				}else{
			$request->session()->flash('success', 'Remove Member from the Task Successfully!');
			}
			
			return redirect($redirectpath);
		}else{
			if(!empty($resultdetails['StatusInfo']['message'])){
				$request->session()->flash('danger', $resultdetails['StatusInfo']['message']);
			}else{
			$request->session()->flash('danger', 'Member unable remove from the task');
			}
			return redirect($redirectpath);
		}
		}
		}else{
		$request->session()->flash('danger', 'Something Went Wrong');
			return redirect($redirectpath);
		}		
	}
	Public function AddMemberFromTask(Request $request){
		
		$input=$request->all();
		if(!empty($input['associateId'])){
			$associate_ids=array();
			foreach($input['associateId'] as $associate_id){
				$associate_ids[]=$associate_id;
			}
		}
		$redirectpath="/project_details/".$input['task_projectid'];
		if(!empty($input['loggedin_id']) && !empty($input['task_id']) && !empty($associate_ids)){
		$taskassigndetailsarray=array();
		$profileids=array();
		foreach($associate_ids as $id){
		$associateids = explode(',', $id);
		$associateid=$associateids[0];
		$url=config('app.resturl').'NuTimeSheetApi/Project/assignTaskToProjectMember';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$addprojectassign=json_encode(array("loggedInUserId" => $input['loggedin_id'],"taskId" => $input['task_id'],
		"associateId" => $associateid));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $addprojectassign);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$taskassigndetailsarray[] = json_decode($result,true);	
		$profile_ids[]=$associateids[1];
		}
		if(!empty($taskassigndetailsarray)){
		foreach($taskassigndetailsarray as $taskassigndetails){
		 if($httpcode=='201' || $httpcode=='200' && !empty($taskassigndetails['StatusCode']) && $taskassigndetails['StatusCode']=='200'){
			 if(!empty($profile_ids)){
				foreach($profile_ids as $profileid){
				$addedprofiledetails=HelperController::getProfileInfo($profileid);
							try {
								if(!empty($taskassigndetails['result'])){
									$result=$taskassigndetails['result'];
									$bodycontent='You are assigned to Existing task of "'.$result['name'].'"';
									$loggedindetails=$request->session()->get('userdetails');
								$data = array('name'=>$addedprofiledetails['name'],'email'=>$addedprofiledetails['email'],'from'=>$loggedindetails['email'],'from_name'=>$loggedindetails['name'],'headercontent'=>"Nu Timesheet User Assigned To Existing task Notification",'body' =>$bodycontent,);
								Mail::send('emails.project_action', $data, function($message) use ($data){
								//$message->from($data['from'],$data['from_name']);
								$message->to($data['email'], $data['name'])
								->subject('User Added on the Existing Task');
								});
								}

							$request->session()->flash('success', 'Member Added this Task & Mail Sent Successfully!');
							} catch (Exception $ex) {
			  
							$request->session()->flash('success', 'Member Added this Task Successfully!');
						}
					}
				}else{
			$request->session()->flash('success', 'Member Added this Task Successfully!');
			}
			
			return redirect($redirectpath);
		 }else{
			 if(!empty($taskassigndetails['StatusInfo']['message'])){
				$request->session()->flash('danger', $taskassigndetails['StatusInfo']['message']);
			}else{
			$request->session()->flash('danger', 'Member unable Add from the task');
			}
			return redirect($redirectpath);
		}
		}
		}else{
			$request->session()->flash('danger', 'Member unable Add from the task');
			}
		}else{
		$request->session()->flash('danger', 'Something Went Wrong');
			return redirect($redirectpath);
		}	
	}
	
}
