<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use View;
use Mail;
class ProjectManageController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
		$userId=$request->session()->get('user_id');
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/Project/getProjectByUserId';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$loggedinid = json_encode(array("id" => $userId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinid);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$projectlist = json_decode($result,true);
		if($httpcode=='200' || $httpcode=='201' && !empty($projectlist['StatusCode']) && $projectlist['StatusCode']=='200'){
		//$request->session()->put('projectlists', $projectlist['result']);
		$data['project_listdata'] = $projectlist['result'];
		if(!empty($projectlist['result'])){
		$request->session()->put('dashboard_project', $projectlist['result']);
		$request->session()->put('dashboard_projectcount', count($projectlist['result']));	
		}
		return view('project.project_lists',$data);		
		}
		else{
			$message=$projectlist['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
				return view('project.project_lists');
			}else{
				return view('project.project_lists');
			}
		}
		}
		else{
			return redirect('/login');
		}
		
	}
		/**
	 * Show the form for creating a new tickets
	 *
     * @return \Illuminate\View\View
	 */
	public function create(Request $request)
	{
		$userId=$request->session()->get('user_id');
		if (!empty($userId)) {
           return view('project.project_create');
        }else{
			return redirect('/login');
		}
	    
	}

    /**
     * Insert new user into the system
     *
     * @param Request $request
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
		$input = $request->all();
		$projectname=$input['project_name'];
		$projectdesc=$input['project_desc'];
		$userId=$request->session()->get('user_id');
		$startdate=date('Y-m-d', strtotime($input['pro_startdate']));
		$enddate=date('Y-m-d', strtotime($input['pro_enddate']));
		if(!empty($projectname) && !empty($projectdesc) && !empty($startdate) && !empty($enddate) && !empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/Project/createBasicProject';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$projectcreate = json_encode(array("Name" => $projectname,"desc" => $projectdesc,
		"startDate" => $startdate,"loggedInUserId" => $userId,"endDate" => $enddate));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $projectcreate);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='201'){
			$request->session()->flash('success', 'Project created successfully!');
			return redirect('/project_list');
		}else{
			$message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect('/create_project');
			}
		}
		}else{
			$request->session()->flash('danger', 'Project not created please enter valid inputs');
			return redirect('/create_project');
		}
    }
    public function show($id,Request $request)
    {
		$project_id=$id;
		if(!empty($project_id)){
		$url=config('app.resturl').'NuTimeSheetApi/Project/getProjectByProjectId';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$projectdetails = json_encode(array("projectId" => $project_id));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $projectdetails);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		$userId=$request->session()->get('user_id');
		/* get the AllAssociate User */
		$getallassociate = $this->getAllAssociate($request);
		if(!empty($getallassociate)){
		$request->session()->put('getallassociate', $getallassociate);
		}
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		$data['project_data'] = $resultdetails['result'];
	
		if(!empty($data['project_data']['tasks'])){
			  $taskdetailsarray=array();
			 foreach($data['project_data']['tasks'] as $tasklist){
				 $task_id=$tasklist['id'];
				 if(!empty($task_id)){
				$url=config('app.resturl').'NuTimeSheetApi/Project/taskDetailsByTaskid';	
				$ch = curl_init($url);
				$username=config('app.api_username');
				$password=config('app.api_password');
				$taskdetails = json_encode(array("taskId" => $task_id));
				curl_setopt($ch, CURLOPT_POSTFIELDS, $taskdetails);
				curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
				curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
				$result = curl_exec($ch);
				$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
				curl_close($ch);
				$taskdetailsarray[]= json_decode($result,true);
				}		
			 }
			 $data['task_listdetail']=$taskdetailsarray;
		}
		/* get the Project User details */
		
		if(!empty($project_id) && !empty($userId)){
		$data['project_user'] = $this->projectMemberDetails($project_id,$userId);
		}
		$inputArray = $getallassociate;
		$getunassigneduser = array();
		if(!empty($getallassociate) && !empty($data['project_user'])){
		foreach ($getallassociate as $val){
		 if(!in_array($val,$data['project_user'])){
		  $getunassigneduser[] = $val;
		 }
		}
		$request->session()->put('getallassociate', $getunassigneduser);
		}
		return view('project.project_details', $data);
		}else{
		 $request->session()->flash('danger', 'Unable view project details right now.Please try after some time!');
		 return redirect('/project_list');
		}
		}
	}
	public function projectAssignUser(Request $request){
		
		$input = $request->all();
		$projectId=$input['projectId'];
		if(!empty($input['associateId'])){
		$associateId=$input['associateId'];
		}
		$loggedInUserId=$input['loggedInUserId'];
		if(!empty($projectId) && !empty($associateId) && !empty($loggedInUserId)){
		$resultdetailsarray=array();
		$profileids=array();
		foreach($associateId as $id){
			/** Splite the associate id and profile id from the selection option**/	
		$associateids = explode(',', $id);
		$associateid=$associateids[0];
		
		$url=config('app.resturl').'NuTimeSheetApi/Project/addMemberToProject';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$assignuser = json_encode(array("projectId" => $projectId,"associateId" => $associateid,"loggedInUserId" => $loggedInUserId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $assignuser);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetailsarray[] = json_decode($result,true);
		$profile_ids[]=$associateids[1];
		}
		foreach($resultdetailsarray as $resultdetails){
		$redirectpath="/project_details/".$projectId;
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			
				if(!empty($profile_ids)){
				foreach($profile_ids as $profileid){
				$addedprofiledetails=HelperController::getProfileInfo($profileid);
							try {
								if(!empty($resultdetails['result'])){
									$result=$resultdetails['result'];
									$bodycontent='You Added from project of '.$result['Name'];
									$loggedindetails=$request->session()->get('userdetails');
								$data = array('name'=>$addedprofiledetails['name'],'email'=>$addedprofiledetails['email'],'from'=>$loggedindetails['email'],'from_name'=>$loggedindetails['name'],'headercontent'=>"Nu Timesheet User Added from Project Notification",'body' =>$bodycontent,);
								Mail::send('emails.project_action', $data, function($message) use ($data){
								//$message->from($data['from'],$data['from_name']);
								$message->to($data['email'], $data['name'])
								->subject('User Added from the Project confirmation mail');
								});
								}

							$request->session()->flash('success', 'Project Associate user added & Mail Sent successfully!');
							} catch (Exception $ex) {
			  
							$request->session()->flash('success', 'Project Associate user added successfully!');
						}
					}
				}else{
			$request->session()->flash('success', 'Project Associate user added successfully!');
			}
		}else if($httpcode=='201' || $httpcode=='200' || $httpcode=='400' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200' && $resultdetails['StatusCode']=='400'){
			$request->session()->flash('success', 'Project Associate user added successfully!');
			$message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
			}
		}else if($httpcode=='400' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='400'){
			$message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
			}
		}
		}
			return redirect($redirectpath);
	}else{
			$request->session()->flash('danger', 'Something went out');
			return redirect($redirectpath);
		}
	}
	public function projectMemberDetails($project_id,$userId){
		if(!empty($project_id) && !empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/Project/getProjectMembersByProjectid';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$projectinput = json_encode(array("loggedInUserId" => $userId,"projectId" => $project_id));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $projectinput);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		return $resultdetails['result'];
	    }
		}
	}
	public function getAllAssociate(Request $request){	
		$userId=$request->session()->get('user_id');
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/UserProfile/getAllAssociate';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$loggedInuser = json_encode(array("loggedInUserId" => $userId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedInuser);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		return $resultdetails['result'];
	    }
		}
	}
	Public function UpdateProjectdetail(Request $request){
		
		$input=$request->all();
		if(!empty($input['loggedInUserId']) && !empty($input['projectid']) && !empty($input['project_name']) && !empty($input['project_desc']) && !empty($input['project_status'])){
		$url=config('app.resturl').'NuTimeSheetApi/Project/editProjectDetails';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$updateprojectdetails = json_encode(array("loggedInUserId" => $input['loggedInUserId'],"projectId" => $input['projectid'],
		"Name" => $input['project_name'],"desc" => $input['project_desc'],"state" => $input['project_status'],"startDate" =>'04-07-2018' ,"endDate" => '31-07-2018'));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $updateprojectdetails);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if(!empty($resultdetails)){
		if($httpcode=='201'|| $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'Project Updated successfully!');
			return redirect('/project_list');
		}else{
			if(!empty($resultdetails['StatusInfo']['message'])){
				$request->session()->flash('danger', $resultdetails['StatusInfo']['message']);
			}else{
			$request->session()->flash('danger', 'Project not Updated please enter valid inputs');
			}	
			return redirect('/project_list');
		}
		}
		}else{
		$request->session()->flash('danger', 'Something Went Wrong');
			return redirect('/project_list');
		}
	}
	public function RemoveMemberFromProject($associate_id,$project_id,Request $request)
	{
		$userId=$request->session()->get('user_id');
		$redirectpath="/project_details/".$project_id;
		if(!empty($associate_id) && !empty($project_id) && !empty($userId)){
			$url=config('app.resturl').'NuTimeSheetApi/Project/removMemberFromProject';	
			$ch = curl_init($url);
			$username=config('app.api_username');
			$password=config('app.api_password');
			$memberdetails = json_encode(array("loggedInUserId" => $userId,"projectId" => $project_id ,"associateId" => $associate_id));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $memberdetails);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			$result = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			$resultdetails = json_decode($result,true);
			if(!empty($resultdetails)){
			if($httpcode=='201'|| $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
				/** Remove User from Project mail Confirmation Start**/
				if(!empty($resultdetails['result']['membares'])){
				foreach($resultdetails['result']['membares'] as $assigneduser){
					if($assigneduser['id']==$associate_id){
						$removedprofiledetails=HelperController::getProfileInfo($assigneduser['profileId']);
							try {
							
								if(!empty($resultdetails['result'])){
									$result=$resultdetails['result'];
									$bodycontent='You removed from project of '.$result['Name'];
									$loggedindetails=$request->session()->get('userdetails');
								$data = array('name'=>$removedprofiledetails['name'],'email'=>$removedprofiledetails['email'],'from'=>$loggedindetails['email'],'from_name'=>$loggedindetails['name'],'headercontent'=>"Nu Timesheet User Removed from Project Notification",'body' =>$bodycontent,);
								Mail::send('emails.project_action', $data, function($message) use ($data){
								$message->to($data['email'], $data['name'])
								->subject('User removed from the Project confirmation mail');
								//$message->from($data['from'],$data['from_name']);
								});
								}

							$request->session()->flash('success', 'Removed Member from the Project & Mail Sent successfully!');
							} catch (Exception $ex) {
			  
							$request->session()->flash('success', 'Removed Member from the project successfully!');
						}
						
					}
				}
				}/** Remove User from Project mail Confirmation End**/
				
				//$request->session()->flash('success', 'Removed Member from the project successfully!');
				return redirect($redirectpath);
			}else{
				if(!empty($resultdetails['StatusInfo']['message'])){
				$request->session()->flash('danger', $resultdetails['StatusInfo']['message']);
				}else{
				$request->session()->flash('danger', 'Unable to remove member from the project');
				}
				return redirect($redirectpath);
			}
			}
		}
		else{
		$request->session()->flash('danger', 'Something Went Wrong');
			return redirect($redirectpath);
		}
	}
}
