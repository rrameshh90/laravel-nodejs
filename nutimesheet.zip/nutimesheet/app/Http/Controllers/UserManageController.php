<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use Mail;
class UserManageController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
		
		$userId=$request->session()->get('user_id');
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/UserProfile/getAllprofile';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$loggedinid = json_encode(array("loggedInUserId" => $userId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinid);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$userlist = json_decode($result,true);
		//$request->session()->put('userlist', $userlist['result']);
		if($httpcode=='201' || $httpcode=='200' && !empty($userlist['StatusCode']) && $userlist['StatusCode']=='200'){
		$data['user_listdata'] = $userlist['result'];
		if(!empty($userlist['result'])){
			$userdetails=array();
			foreach($userlist['result'] as $user){
				$userdetails[]=$user['id'];
			}
		$request->session()->put('dashboard_userdetails', $userdetails);
		$request->session()->put('dashboard_usercount', count($userlist['result']));	
		}
         return view('user.user_list',$data);
		}else{
			return view('user.user_list');
		}
        }else{
			return redirect('/login');
			//return view('user.user_list');
		}
		
	}
		/**
	 * Show the form for creating a new user
	 *
     * @return \Illuminate\View\View
	 */
	public function create(Request $request)
	{
		$userId=$request->session()->get('user_id');
		if (!empty($userId)) {
           return view('user.user_create');
        }else{
			return redirect('/login');
		}
	    
	}

    /**
     * Insert new user into the system
     *
     * @param Request $request
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
		$input = $request->all();
		if(!empty($input['email']) && !empty($input['role']) && !empty($input['employee_name']) && !empty($input['creator_emailid']) && !empty($input['designation'])){
		$url=config('app.resturl').'NuTimeSheetApi/UserProfile/createProfile';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$usercreate = json_encode(array("email" => $input['email'],"role" => $input['role'],
		"name" => $input['employee_name'],"loggedInUser" => $input['creator_emailid'],"loggedInUserId" => $input['creator_loggedinid'],"designation" => $input['designation']));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $usercreate);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if(!empty($resultdetails)){
		if($httpcode=='201'|| $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='201'){
			$request->session()->flash('success', 'Employee created successfully!');
			try {
		   /** User Update mail Confirmation  start**/
					if(!empty($resultdetails['result'])){
						$result=$resultdetails['result'];
						$loggedindetails=$request->session()->get('userdetails');
						$baseurl=url('/');
					$data = array('name'=>$result['name'],'email'=>$result['email'],'from'=>$loggedindetails['email'],'from_name'=>$loggedindetails['name'],'headercontent'=>'Welcome to Nu Timesheet Application','body' =>"Your Email Added successfully on the timesheet application,See below link login to Timesheet Application ".$baseurl);
					Mail::send('emails.user_actions', $data, function($message) use ($data){
					$message->to($data['email'], $data['name'])
					->subject('User Created confirmation mail');
					//$message->from($data['from'],$data['from_name']);
					});
					}

				$request->session()->flash('success', 'Employee Created & Mail Sent Successfully!');
			} catch (Exception $ex) {
  
				$request->session()->flash('success', 'Employee created successfully!');
			}
			/** User update mail Confirmation End**/	
			return redirect('/user_list');
		}else{
			if(!empty($resultdetails['StatusInfo']['message']) && $resultdetails['StatusCode']=='400'){
			$messageinfo=$resultdetails['StatusInfo']['message'];
			$request->session()->flash('danger', $messageinfo);
			}
			return redirect('/create_user');
		}
		}else{
			$request->session()->flash('danger', 'Unable to create new profile right now,please try again after some time');
			return redirect('/create_user');
		}
		}else{
			$request->session()->flash('danger', 'Employee not created please enter valid inputs');
			return redirect('/create_user');
		}
    }
    public function show(Request $request)
    {		
		$userId=$request->session()->get('user_id');
		if (!empty($userId)) {
           return view('user.user_profile');
        }else{
			return redirect('/login');
		}
	}
	
	public function Updateuser(Request $request){
		
		$input = $request->all();
		if(!empty($input['loggedInUserId']) && !empty($input['userprofileId']) && !empty($input['employee_name']) && !empty($input['email_address']) && !empty($input['employee_designation'])){
		$url=config('app.resturl').'NuTimeSheetApi/UserProfile/editUserDetails';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$updateuserdetails = json_encode(array("loggedInUserId" => $input['loggedInUserId'],"name" => $input['employee_name'],
		"email" => $input['email_address'],"designation" => $input['employee_designation'],"profileIdToEdit" => $input['userprofileId']));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $updateuserdetails);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if(!empty($resultdetails)){
		if($httpcode=='201'|| $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			try {
		   /** User Update mail Confirmation  start**/
					if(!empty($resultdetails['result']['0'])){
						$result=$resultdetails['result']['0'];
						$loggedindetails=$request->session()->get('userdetails');
					$data = array('name'=>$result['name'],'email'=>$result['email'],'from'=>$loggedindetails['email'],'from_name'=>$loggedindetails['name'],'headercontent'=>'Nu Timesheet User Updated Notification','body' =>"Your Employee details updated successfully",);
					Mail::send('emails.user_actions', $data, function($message) use ($data){
					$message->to($data['email'], $data['name'])
					->subject('User Updated confirmation mail');
					//$message->from($data['from'],$data['from_name']);
					});
					}

				$request->session()->flash('success', 'Employee Updated & Mail Sent Successfully!');
			} catch (Exception $ex) {
  
				$request->session()->flash('success', 'Employee Updated successfully!');
			}
			/** User update mail Confirmation End**/			
			
			return redirect('/user_list');
		}else{
			if(!empty($resultdetails['StatusInfo']['message'])){
				$request->session()->flash('danger', $resultdetails['StatusInfo']['message']);
			}else{
			$request->session()->flash('danger', 'Employee not Updated please enter valid inputs');
			}
			return redirect('/user_list');
		}
		}
	}else{
		$request->session()->flash('danger', 'Something Went Wrong');
			return redirect('/user_list');
	}
	}
	public function Deleteuser($profile_id,Request $request)
	{
		$userId=$request->session()->get('user_id');
		if(!empty($profile_id) && !empty($userId)){
			$url=config('app.resturl').'NuTimeSheetApi/UserProfile/softDeletUser';	
			$ch = curl_init($url);
			$username=config('app.api_username');
			$password=config('app.api_password');
			$deleteuserdetails = json_encode(array("loggedInUserId" => $userId,"profileIdToDelete" => $profile_id));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $deleteuserdetails);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			$result = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			$resultdetails = json_decode($result,true);
			if(!empty($resultdetails)){
			if($httpcode=='201'|| $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
				return redirect('/user_list');
			}else{
				if(!empty($resultdetails['StatusInfo']['message'])){
				$request->session()->flash('danger', $resultdetails['StatusInfo']['message']);
				}else{
				$request->session()->flash('danger', 'Employee not Deleted');
				}
				return redirect('/user_list');
			}
			}
		}
		else{
		$request->session()->flash('danger', 'Something Went Wrong');
			return redirect('/user_list');
	}
	}
	public function Userwisealldetails($profile_id,Request $request)
	{
		if(!empty($profile_id)){
			$url=config('app.resturl').'NuTimeSheetApi/Project/getProjectByUserId';	
			$ch = curl_init($url);
			$username=config('app.api_username');
			$password=config('app.api_password');
			$loggedinId = json_encode(array("id" => $profile_id));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinId);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			$result = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			$empprojectdetails = json_decode($result,true);
			if(!empty($empprojectdetails)){
			if($httpcode=='201'|| $httpcode=='200' && !empty($empprojectdetails['StatusCode']) && $empprojectdetails['StatusCode']=='200'){
				$data['userwiseprojectlist']=$empprojectdetails;
				$userdetails=$this->UserProfiledetails($profile_id);
				$userworkdetails=$this->UserTodayWorkingTask($profile_id);
				if(!empty($userdetails['StatusCode']) && $userdetails['StatusCode']=='200'){
				$data['userprofiledetails']=$userdetails;
				}
				if(!empty($userworkdetails['StatusCode']) && $userworkdetails['StatusCode']=='200'){
				$data['usertodayworkdetails']=$userworkdetails;
				}
				return view('user.user_details',$data);
			}else{
				if(!empty($empprojectdetails['StatusInfo']['message'])){
				$request->session()->flash('danger', $empprojectdetails['StatusInfo']['message']);
				}else{
				$request->session()->flash('danger', 'Unable view Employee details right now');
				}
				return redirect('/user_list');
			}
			}
		}		
	}
	public function UserProfiledetails($profile_id){
		
		if(!empty($profile_id)){
			$url=config('app.resturl').'NuTimeSheetApi/UserProfile/getProfileDetailsById';	
			$ch = curl_init($url);
			$username=config('app.api_username');
			$password=config('app.api_password');
			$loggedinId = json_encode(array("profileId" => $profile_id));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinId);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			$result = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			$resultdetails = json_decode($result,true);
			if($httpcode=='201'|| $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
				return $resultdetails;
			}
		}	
	}
	
	public function UserTodayWorkingTask($profile_id){
		
		if(!empty($profile_id)){
			$url=config('app.resturl').'NuTimeSheetApi/Project/getListOfTickets';	
			$ch = curl_init($url);
			$username=config('app.api_username');
			$password=config('app.api_password');
			curl_setopt($ch, CURLOPT_URL, $url.'?loggedInUserId='.$profile_id);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			$result = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			$resultdetails = json_decode($result,true);
			if($httpcode=='201'|| $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
				return $resultdetails;
			}
		}	
	}
	public function RestoreExistinguser(Request $request){
		$input=$request->all();
		if(!empty($input['loggedInUserId']) && !empty($input['email_address'])){
			$url=config('app.resturl').'NuTimeSheetApi/UserProfile/reStoreUser';	
			$ch = curl_init($url);
			$username=config('app.api_username');
			$password=config('app.api_password');
			$userrestoredetails = json_encode(array("loggedInUserId" => $input['loggedInUserId'],"profileEmailToReStore" => $input['email_address']));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $userrestoredetails);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			$result = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			$resultdetails = json_decode($result,true);
			if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'User Restored successfully!');
				return redirect('/user_list');
			}else{
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
					$request->session()->flash('danger',$message);
					return redirect('/user_list');
				}
			}
			}else{
				$request->session()->flash('danger', 'Something Went Wrong');
				return redirect('/user_list');
			}
		}
		
		public function ChangeRoleExistinguser(Request $request){
		$input=$request->all();
		if(!empty($input['loggedInUserId']) && !empty($input['email']) && !empty($input['role'])){
			$url=config('app.resturl').'NuTimeSheetApi/UserProfile/editUserRole';	
			$ch = curl_init($url);
			$username=config('app.api_username');
			$password=config('app.api_password');
			$userrestoredetails = json_encode(array("loggedInUserId" => $input['loggedInUserId'],"email" => $input['email'],"role" => $input['role']));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $userrestoredetails);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			$result = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			$resultdetails = json_decode($result,true);
			if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
				/** User Role changes mail Confirmation Start**/
				try {
				
					if(!empty($resultdetails['result'])){
						$result=$resultdetails['result'];
						$bodycontent=$resultdetails['StatusInfo']['message'];
						$loggedindetails=$request->session()->get('userdetails');
					$data = array('name'=>$result['name'],'email'=>$result['email'],'from'=>$loggedindetails['email'],'from_name'=>$loggedindetails['name'],'headercontent'=>"Nu Timesheet User Role Changed Notification",'body' =>$bodycontent,);
					Mail::send('emails.user_actions', $data, function($message) use ($data){
					$message->to($data['email'], $data['name'])
					->subject('User Role Changed confirmation mail');
					//$message->from($data['from'],$data['from_name']);
					});
					}

				$request->session()->flash('success', 'User Role Changed & Mail Sent successfully!');
				} catch (Exception $ex) {
  
				$request->session()->flash('success', 'User Role Changed successfully!');
			}
			/** User Role Changes mail Confirmation End**/
			
				return redirect('/user_list');
			}else{
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
					$request->session()->flash('danger',$message);
					return redirect('/user_list');
				}
			}
			}else{
				$request->session()->flash('danger', 'Something Went Wrong');
				return redirect('/user_list');
			}
		}
		
		public function getOnboardUser(Request $request)
		{
		$userId=$request->session()->get('user_id');
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/UserProfile/getAllprofile';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$loggedinid = json_encode(array("loggedInUserId" => $userId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinid);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$onboardusers = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($onboardusers['StatusCode']) && $onboardusers['StatusCode']=='200'){
			    $onboardemployee=array();
				foreach($onboardusers['result'] as $onboarduser){
					if($onboarduser['role']=='3' || $onboarduser['role']=='2'){
					$onboardemployee[]=$onboarduser;
					}
				}
				$data['user_onboard_listdata'] = $onboardemployee;
				return view('user.user_onboard_list',$data);
			}else{
					return view('user.user_onboard_list');
		}
        }else{
			return redirect('/login');
			//return view('user.user_list');
		}
	}	
	public function getOffboardUser(Request $request)
		{
		
		$userId=$request->session()->get('user_id');
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/UserProfile/getAllprofile';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$loggedinid = json_encode(array("loggedInUserId" => $userId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinid);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$offboardusers = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($offboardusers['StatusCode']) && $offboardusers['StatusCode']=='200'){
			    $offboardemployee=array();
			foreach($offboardusers['result'] as $offboarduser){
					if($offboarduser['role']=='1'){
					$offboardemployee[]=$offboarduser;
					}
				}
				$data['user_offboard_listdata'] = $offboardemployee;
				return view('user.user_offboard_list',$data);
			}else{
					return view('user.user_offboard_list');
		}
        }else{
			return redirect('/login');
			//return view('user.user_list');
		}
	}
}
