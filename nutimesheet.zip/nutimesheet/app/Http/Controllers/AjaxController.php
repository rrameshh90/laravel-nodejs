<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AjaxController extends Controller
{
    public function getProjectAssociateuser(Request $request){
		
		$data = $request->all(); // This will get all the request data.
		$project_id=$data['projectId'];
		$userId=$data['loggedInUserId'];
		$html='';
		if(!empty($project_id) && !empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/Project/getProjectMembersByProjectid';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$projectinput = json_encode(array("loggedInUserId" => $userId,"projectId" => $project_id));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $projectinput);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		return $resultdetails;
		/*if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			if(!empty($resultdetails['result'])){
			foreach($resultdetails['result']  as $result){
				$html.='<option value="'.$result["profileId"]["id"].'">' .$result["profileId"]["name"]. '</option>';
			}
			}else{
				$html.='<option>No Members so far for this Project</option>';
			}
		}
		}else{
			$html.='<option>No Members so far for this Project</option>';
		}
		return $html;*/
		}
	}
}
