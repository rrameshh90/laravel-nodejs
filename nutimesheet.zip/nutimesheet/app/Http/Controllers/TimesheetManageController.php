<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use Mail;
class TimesheetManageController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
		$userId=$request->session()->get('user_id');
		if (!empty($userId)) {	
			$associate_savedtimesheet=$this->getSavedTimesheet($userId,$request);
			if(!empty($associate_savedtimesheet)){
			$data['associate_savedtimesheet']=$associate_savedtimesheet;
			 return view('timesheet.timesheet',$data);
			}else{
			 return view('timesheet.timesheet');
			}
          
        }else{
			return redirect('/login');
			//return view('timesheet.timesheet');
		}
		
	}
	
	public function getSavedTimesheet($userId,$request)
	{
		/* Get the Associate Saved Timesheet list */
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/getSavedTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$loggedinId = json_encode(array("loggedInUserId" => $userId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinId);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		 return $resultdetails['result'];
		}	
		}
	
	}
	public function store(Request $request){
		
		$input = $request->all();
		/* Timesheet Save */
		if ($request->get('action') == 'save') {
			$projectid=$input['task_projectid'];
		$taskid=$input['task_id'];
		$associateid=$input['associate_id'];
		$entrydate=date('Y-m-d', strtotime($input['entrydate']));
		$comment=$input['comment'];
		$hours=$input['hours'];
		$redirectpath="/taskdetails/".$taskid;
		if(!empty($projectid) && !empty($taskid) && !empty($associateid) && !empty($entrydate) && !empty($comment) && !empty($hours)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/saveTimeSheetEntry';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$entrydata = json_encode(array("timeSheetEntries"=>array("projectId" => $projectid,"taskId" => $taskid,
		"dateAndTime" => $entrydate,"comments" => $comment,"associateId" => $associateid,"hours" => $hours)));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $entrydata);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='201'){
			$request->session()->flash('success', 'Time Entry created successfully!');
			return redirect($redirectpath);
		}else{
			$info=$resultdetails['StatusInfo']['info'];
			if(!empty($info)){
			if(!empty($info['StatusInfo'])){
				$message=$info['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
			}else if(!empty($resultdetails['StatusInfo'])){
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
		}
		}else{
			$request->session()->flash('danger', 'Time not created please enter valid inputs');
			return redirect($redirectpath);
		}
		/* Timesheet Save and Submit */
		} elseif ($request->get('action') == 'save_and_submit') {
		$projectid=$input['task_projectid'];
		$taskid=$input['task_id'];
		$associateid=$input['associate_id'];
		$entrydate=date('Y-m-d', strtotime($input['entrydate']));
		$comment=$input['comment'];
		$hours=$input['hours'];
		$loggedinId=$input['loggedin_id'];
		$redirectpath="/taskdetails/".$taskid;
		if(!empty($projectid) && !empty($taskid) && !empty($associateid) && !empty($entrydate) && !empty($comment) && !empty($hours)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/saveTimeSheetEntry';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$entrydata = json_encode(array("timeSheetEntries"=>array("projectId" => $projectid,"taskId" => $taskid,
		"dateAndTime" => $entrydate,"comments" => $comment,"associateId" => $associateid,"hours" => $hours)));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $entrydata);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='201'){
			$entryid=$resultdetails['result']['id'];
			if(!empty($loggedinId) && !empty($entryid) ){
				$saveandsubmit=$this->SaveandSubmitTimesheet($entryid,$loggedinId);
			}
			if(!empty($saveandsubmit)){
			if($httpcode=='201' || $httpcode=='200' && !empty($saveandsubmit['StatusCode']) && $saveandsubmit['StatusCode']=='200'){
			$request->session()->flash('success', 'Time Entry created and Submitted to your manager successfully!');
			}
			}else{
				$request->session()->flash('success', 'Time Entry created successfully!');
			}
			return redirect($redirectpath);
		}else{
			$info=$resultdetails['StatusInfo']['info'];
			if(!empty($info)){
			if(!empty($info['StatusInfo'])){
				$message=$info['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
			}else if(!empty($resultdetails['StatusInfo'])){
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
		}
		}else{
			$request->session()->flash('danger', 'Timesheet not created please enter valid inputs');
			return redirect($redirectpath);
		}
		}
	}
	public function Tickettimestore(Request $request){
		
		$input = $request->all();
		/* Timesheet Save */
		if ($request->get('action') == 'save') {
		$ticketid=$input['ticket_id'];
		$associateid=$input['associate_id'];
		$entrydate=date('Y-m-d', strtotime($input['entrydate']));
		$comment=$input['comment'];
		$hours=$input['hours'];
		$redirectpath="/ticketdetails/".$ticketid;
		if(!empty($ticketid) && !empty($associateid) && !empty($entrydate) && !empty($comment) && !empty($hours)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/saveTimeSheetForTicket';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$entrydata = json_encode(array("ticketId" => $ticketid,
		"entryDate" => $entrydate,"comments" => $comment,"associateId" => $associateid,"hours" => $hours));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $entrydata);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='201'){
			$request->session()->flash('success', 'Time Entry created successfully!');
			return redirect($redirectpath);
		}else{
			$info=$resultdetails['StatusInfo']['info'];
			if(!empty($info)){
			if(!empty($info['StatusInfo'])){
				$message=$info['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}else if(!empty($resultdetails['StatusInfo'])){
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
			}else if(!empty($resultdetails['StatusInfo'])){
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
		}
		}else{
			$request->session()->flash('danger', 'Time not created please enter valid inputs');
			return redirect($redirectpath);
		}
		/* Timesheet Save and Submit */
		} elseif ($request->get('action') == 'save_and_submit') {
		$ticketid=$input['ticket_id'];
		$associateid=$input['associate_id'];
		$entrydate=date('Y-m-d', strtotime($input['entrydate']));
		$comment=$input['comment'];
		$hours=$input['hours'];
		$redirectpath="/ticketdetails/".$ticketid;
		if(!empty($ticketid) && !empty($associateid) && !empty($entrydate) && !empty($comment) && !empty($hours)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/saveTimeSheetForTicket';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$entrydata = json_encode(array("ticketId" => $ticketid,"entryDate" => $entrydate,"comments" => $comment,"associateId" => $associateid,"hours" => $hours));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $entrydata);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $entrydata);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		$redirectpath="/ticketdetails/".$ticketid;
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='201'){
			$entryid=$resultdetails['result']['id'];
			$loggedinId=$request->session()->get('user_id');
			if(!empty($loggedinId) && !empty($entryid) ){
				$saveandsubmit=$this->SaveandSubmitTimesheet($entryid,$loggedinId);
			}
			if(!empty($saveandsubmit)){
			if($httpcode=='201' || $httpcode=='200' && !empty($saveandsubmit['StatusCode']) && $saveandsubmit['StatusCode']=='200'){
			$request->session()->flash('success', 'Time Entry created and Submitted to your manager successfully!');
			}
			}else{
				$request->session()->flash('success', 'Time Entry created successfully!');
			}
			return redirect($redirectpath);
		}else{
			$info=$resultdetails['StatusInfo']['info'];
			if(!empty($info)){
			if(!empty($info['StatusInfo'])){
				$message=$info['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}else if(!empty($resultdetails['StatusInfo'])){
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
			}else if(!empty($resultdetails['StatusInfo'])){
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
		}
		}else{
			$request->session()->flash('danger', 'Timesheet not created please enter valid inputs');
			return redirect($redirectpath);
		}
		}
	}
	/** Task UpdateTimeentry **/
	public function UpdateTimeEntry(Request $request){
		
		$input=$request->all();
		$redirectpath="/taskdetails/".$input['task_id'];
		if(!empty($input['loggedin_id']) && !empty($input['entry_id']) && !empty($input['comments']) && !empty($input['hours']) && !empty($input['associate_id'])){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/editSavedTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$updatetimeentry = json_encode(array("loggedInUserId" => $input['loggedin_id'],"associateId" => $input['associate_id'],
		"entryId" => $input['entry_id'],"comments" => $input['comments'],"hours" => $input['hours']));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $updatetimeentry);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);	
		 if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'Updated the Time Entry successfully!');
			return redirect($redirectpath);
		 }else{
			 $message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
			}
		}
	}else{	
		$request->session()->flash('danger', 'Something Went Wrong');
			return redirect($redirectpath);
	}
	}
	/** Task DeleteTimesheet **/
	public function DeleteTimesheet($entry_id,$associate_id,$user_id,$task_id,Request $request){
		$url = parse_url($_SERVER['HTTP_REFERER']);
		$trimmedHeader = $url['path'];
		if($trimmedHeader=='/timesheet'){
			$redirectpath="/timesheet";
		}else{
			$redirectpath="/taskdetails/".$task_id;
		}
		if(!empty($user_id) && !empty($entry_id) && !empty($associate_id)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/deleteTimeSheetEntry';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$deletetimeentry = json_encode(array("loggedInUserId" => $user_id,"associateId" => $associate_id,
		"entryId" => $entry_id));
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $deletetimeentry);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);	

		 if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'The Time Entry Deleted Successfully!');
			return redirect($redirectpath);
		 }else{
			 $message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
			}
		}
		}else{	
			$request->session()->flash('danger', 'Something Went Wrong');
				return redirect($redirectpath);
		}
	}
	/** Task SubmittedTimesheet **/
	public function SubmitTimesheet($entry_id,$user_id,$task_id,Request $request){
		$url = parse_url($_SERVER['HTTP_REFERER']);
		$trimmedHeader = $url['path'];
		if($trimmedHeader=='/timesheet'){
			$redirectpath="/timesheet";
		}else{
			$redirectpath="/taskdetails/".$task_id;
		}
		if(!empty($user_id) && !empty($entry_id)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/submitTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$sumbittimeentry = json_encode(array("loggedInUserId" => $user_id,"entryId" => $entry_id));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $sumbittimeentry);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);	
		 if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'Your Time Sheet has been submitted to Project Manager Successfully!');
			return redirect($redirectpath);
		 }else{
			 $message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
			}
		}
		}else{	
			$request->session()->flash('danger', 'Something Went Wrong');
				return redirect($redirectpath);
		}
	}
	/** Ticket Updated Timesheet **/
		public function TicketUpdateTimeEntry(Request $request){
		
		$input=$request->all();
		$redirectpath="/ticketdetails/".$input['ticket_id'];
		if(!empty($input['loggedin_id']) && !empty($input['entry_id']) && !empty($input['comments']) && !empty($input['hours']) && !empty($input['associate_id'])){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/editSavedTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$updatetimeentry = json_encode(array("loggedInUserId" => $input['loggedin_id'],"associateId" => $input['associate_id'],
		"entryId" => $input['entry_id'],"comments" => $input['comments'],"hours" => $input['hours']));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $updatetimeentry);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);	
		 if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'Updated the Time Entry successfully!');
			return redirect($redirectpath);
		 }else{
			 $message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
			}
		}
	}else{	
		$request->session()->flash('danger', 'Something Went Wrong');
			return redirect($redirectpath);
	}
	}
	
	/** Ticket Deleted Timesheet **/
	public function TicketDeleteTimesheet($entry_id,$associate_id,$user_id,$ticket_id,Request $request){
		$url = parse_url($_SERVER['HTTP_REFERER']);
		$trimmedHeader = $url['path'];
		if($trimmedHeader=='/timesheet'){
			$redirectpath="/timesheet";
		}else{
			$redirectpath="/ticketdetails/".$ticket_id;
		}
		if(!empty($user_id) && !empty($entry_id) && !empty($associate_id)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/deleteTimeSheetEntry';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$deletetimeentry = json_encode(array("loggedInUserId" => $user_id,"associateId" => $associate_id,
		"entryId" => $entry_id));
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $deletetimeentry);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);	

		 if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'The Time Entry Deleted Successfully!');
			return redirect($redirectpath);
		 }else{
			 $message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
			}
		}
		}else{	
			$request->session()->flash('danger', 'Something Went Wrong');
				return redirect($redirectpath);
		}
	}
	/** Ticket Submitted Timesheet **/
	public function TicketSubmitTimesheet($entry_id,$user_id,$ticket_id,Request $request){
		$url = parse_url($_SERVER['HTTP_REFERER']);
		$trimmedHeader = $url['path'];
		if($trimmedHeader=='/timesheet'){
			$redirectpath="/timesheet";
		}else{
			$redirectpath="/ticketdetails/".$ticket_id;
		}
		if(!empty($user_id) && !empty($entry_id)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/submitTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$sumbittimeentry = json_encode(array("loggedInUserId" => $user_id,"entryId" => $entry_id));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $sumbittimeentry);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);	
		 if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'Your Time Sheet has been submitted to Project Manager Successfully!');
			return redirect($redirectpath);
		 }else{
			 $message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
			}
		}
		}else{	
			$request->session()->flash('danger', 'Something Went Wrong');
				return redirect($redirectpath);
		}
	}
	
	/** Ticket SaveandSubmit **/
	public function TicketSavedAndSubmitTimesheet($entry_id,$user_id){
		if(!empty($user_id) && !empty($entry_id)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/submitTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$sumbittimeentry = json_encode(array("loggedInUserId" => $user_id,"entryId" => $entry_id));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $sumbittimeentry);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);	
		 if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			return $resultdetails;
		 }else{
			 return '';
		 }
	 }
	}
		/** Task SaveandSubmit Timesheet**/
	public function SaveandSubmitTimesheet($entry_id,$user_id){
		if(!empty($user_id) && !empty($entry_id)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/submitTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$sumbittimeentry = json_encode(array("loggedInUserId" => $user_id,"entryId" => $entry_id));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $sumbittimeentry);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);	
		 if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			return $resultdetails;
		 }else{
			 return '';
		 }
		}
	}
	
	public function getAllSubmittedTimesheet(Request $request)
	{
		/* Get the Submitted Timesheet list */
		$userId=$request->session()->get('user_id');
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/getSubmittedTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		curl_setopt($ch, CURLOPT_URL, $url.'?loggedInUserId='.$userId);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		$data['submittedtimesheet_listdata'] = $resultdetails['result'];
		$request->session()->put('submitted_timesheetlist', $resultdetails['result']);
		$request->session()->put('submitted_timesheetlistcount', count($resultdetails['result']));
		return view('timesheet.timesheet_submit_list',$data);
		}else{
		return view('timesheet.timesheet_submit_list');	
		}	
		}
	
	}
		public function Submissionapprovedandreject(Request $request)
	{
		
		$input=$request->all();
		$task_id=$input['task_id'];
		$url = parse_url($_SERVER['HTTP_REFERER']);
		$trimmedHeader = $url['path'];
		if($trimmedHeader=='/submittedtimesheetlist'){
			$redirectpath="/submittedtimesheetlist";
		}else{
			$redirectpath="/taskdetails/".$task_id;
		}
		if ($request->get('action') == 'timesheet_approved') {
		$timesheetid=$input['entry_id'];
		$loggedinId=$input['loggedin_id'];
		if(!empty($timesheetid) && !empty($loggedinId)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/approveSubmittedTimeSheets';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$approvedinput = json_encode(array("loggedInUserId" => $loggedinId,"timesheetIds"=>array($timesheetid)));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $approvedinput);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'Time Entry Approved successfully!');
			return redirect($redirectpath);
		}else{
			$info=$resultdetails['StatusInfo']['info'];
			if(!empty($info)){
			if(!empty($info['StatusInfo'])){
				$message=$info['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
			}else if(!empty($resultdetails['StatusInfo'])){
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
		}
		}else{
			$request->session()->flash('danger', 'Timeentry not Approved please enter valid inputs');
			return redirect($redirectpath);
		}
		}elseif($request->get('action') == 'timesheet_rejected') {
			
		$timesheetid=$input['entry_id'];
		$loggedinId	=$input['loggedin_id'];
		$reason_comment=$input['reason_of_reject'];
		if(!empty($timesheetid) && !empty($loggedinId) && !empty($reason_comment)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/rejectSubmittedTimeSheets';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$rejectedinput = json_encode(array("loggedInUserId" => $loggedinId,"timesheetIds"=>array($timesheetid),"comments" => $reason_comment));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $rejectedinput);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'Time Entry Rejected successfully!');
			return redirect($redirectpath);
		}else{
			$info=$resultdetails['StatusInfo']['info'];
			if(!empty($info)){
			if(!empty($info['StatusInfo'])){
				$message=$info['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
			}else if(!empty($resultdetails['StatusInfo'])){
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
		}
		}else{
			$request->session()->flash('danger', 'Timeentry not rejected please enter valid inputs');
			return redirect($redirectpath);
		}
		}
	}
	
	/** Ticket Timesheet Approved and Reject Function **/
	public function TicketSubmissionapprovedandreject(Request $request)
	{
		
		$input=$request->all();
		$ticket_id=$input['ticket_id'];
		$url = parse_url($_SERVER['HTTP_REFERER']);
		$trimmedHeader = $url['path'];
		if($trimmedHeader=='/submittedtimesheetlist'){
			$redirectpath="/submittedtimesheetlist";
		}else{
			$redirectpath="/ticketdetails/".$ticket_id;
		}
		if ($request->get('action') == 'timesheet_approved') {
		$timesheetid=$input['entry_id'];
		$loggedinId=$input['loggedin_id'];
		if(!empty($timesheetid) && !empty($loggedinId)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/approveSubmittedTimeSheets';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$approvedinput = json_encode(array("loggedInUserId" => $loggedinId,"timesheetIds"=>array($timesheetid)));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $approvedinput);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'Time Entry Approved successfully!');
			return redirect($redirectpath);
		}else{
			$info=$resultdetails['StatusInfo']['info'];
			if(!empty($info)){
			if(!empty($info['StatusInfo'])){
				$message=$info['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
			}else if(!empty($resultdetails['StatusInfo'])){
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
		}
		}else{
			$request->session()->flash('danger', 'Timeentry not Approved please enter valid inputs');
			return redirect($redirectpath);
		}
		}elseif($request->get('action') == 'timesheet_rejected') {
			
		$timesheetid=$input['entry_id'];
		$loggedinId	=$input['loggedin_id'];
		$reason_comment=$input['reason_of_reject'];
		if(!empty($timesheetid) && !empty($loggedinId) && !empty($reason_comment)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/rejectSubmittedTimeSheets';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$rejectedinput = json_encode(array("loggedInUserId" => $loggedinId,"timesheetIds"=>array($timesheetid),"comments" => $reason_comment));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $rejectedinput);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'Time Entry Rejected successfully!');
			return redirect($redirectpath);
		}else{
			$info=$resultdetails['StatusInfo']['info'];
			if(!empty($info)){
			if(!empty($info['StatusInfo'])){
				$message=$info['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
			}else if(!empty($resultdetails['StatusInfo'])){
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
				}
			}
		}
		}else{
			$request->session()->flash('danger', 'Timeentry not rejected please enter valid inputs');
			return redirect($redirectpath);
		}
		}
	}
	/** Associate Userwise Timesheet user **/
	public function getTimesheetAssociates(Request $request){	
		$userId=$request->session()->get('user_id');
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/UserProfile/getAllAssociate';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$loggedInuser = json_encode(array("loggedInUserId" => $userId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedInuser);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		$data['timesheetassociatelist'] = $resultdetails['result'];
		return view('timesheet.timesheet_userlist',$data);
		}else{
		return view('timesheet.timesheet_userlist');	
		}	
		}
	}
	
	/**get the allproject wise Timesheet **/
	public function getAllProjectTimesheetDetails(Request $request){	
		$userId=$request->session()->get('user_id');
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/Project/getProjectByUserId';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$loggedInuser = json_encode(array("id" => $userId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedInuser);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		$data['timesheetprojectlist'] = $resultdetails['result'];
		return view('timesheet.timesheet_projectlist',$data);
		}else{
		return view('timesheet.timesheet_projectlist');	
		}	
		}
	}
	public function getApprovedTimesheet(Request $request)
	{
		/* Get the Approved Timesheet list */
		$userId=$request->session()->get('user_id');
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/getApprovedTimeSheetEntryByAssociate';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		curl_setopt($ch, CURLOPT_URL, $url.'?profileId='.$userId);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		$data['approvedtimesheet_listdata'] = $resultdetails['result'];
		return view('timesheet.timesheet_approved_list',$data);
		}else{
		return view('timesheet.timesheet_approved_list');	
		}	
		}
	
	}
	
	public function getRejectedTimesheet(Request $request)
	{
		/* Get the Reject Timesheet list */
		$userId=$request->session()->get('user_id');
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/getRejectedTimeSheetEntryByAssociate';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		curl_setopt($ch, CURLOPT_URL, $url.'?profileId='.$userId);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		$data['rejectedtimesheet_listdata'] = $resultdetails['result'];
		return view('timesheet.timesheet_rejected_list',$data);
		}else{
		return view('timesheet.timesheet_rejected_list');	
		}	
		}
	
	}
	/** Task Timesheet Reject resubmission **/
	
	public function getTaskTimesheetResubmission(Request $request)
	{
		$input=$request->all();
		if(!empty($input['loggedin_id']) && !empty($input['entry_id']) && !empty($input['associate_id']) && !empty($input['comments']) && !empty($input['hours'])){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/resubmitRejectedTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$resubmissiondetails = json_encode(array("loggedInUserId" => $input['loggedin_id'],"timeSheetId" => $input['entry_id'],
		"associateId" => $input['associate_id'],"comments" => $input['comments'],"hours" => $input['hours']));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $resubmissiondetails);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if(!empty($resultdetails)){
		if($httpcode=='201'|| $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'Timeentry Resubmitted successfully!');
			return redirect('/rejectedtimesheetlist');
		}else{
			if(!empty($resultdetails['StatusInfo']['message'])){
				$request->session()->flash('danger', $resultdetails['StatusInfo']['message']);
			}else{
			$request->session()->flash('danger', 'Timeentry Not Resubmitt please enter valid inputs');
			}	
			return redirect('/rejectedtimesheetlist');
		}
		}
		}else{
			$request->session()->flash('danger', 'Something Went Wrong');
			return redirect('/rejectedtimesheetlist');
		}
	
	}
	
	/** Ticket Timesheet Reject resubmission **/
	
	public function getTicketTimesheetResubmission(Request $request)
	{
		$input=$request->all();
		if(!empty($input['loggedin_id']) && !empty($input['entry_id']) && !empty($input['associate_id']) && !empty($input['comments']) && !empty($input['hours'])){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/resubmitRejectedTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$resubmissiondetails = json_encode(array("loggedInUserId" => $input['loggedin_id'],"timeSheetId" => $input['entry_id'],
		"associateId" => $input['associate_id'],"comments" => $input['comments'],"hours" => $input['hours']));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $resubmissiondetails);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if(!empty($resultdetails)){
		if($httpcode=='201'|| $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'Timeentry Resubmitted successfully!');
			return redirect('/rejectedtimesheetlist');
		}else{
			if(!empty($resultdetails['StatusInfo']['message'])){
				$request->session()->flash('danger', $resultdetails['StatusInfo']['message']);
			}else{
			$request->session()->flash('danger', 'Timeentry Not Resubmitt please enter valid inputs');
			}	
			return redirect('/rejectedtimesheetlist');
		}
		}
		}else{
			$request->session()->flash('danger', 'Something Went Wrong');
			return redirect('/rejectedtimesheetlist');
		}
	
	}
	
	/** Task Rejected Timesheet Delete  **/
	public function TaskRejectDeleteTimesheet($entry_id,$associate_id,$user_id,Request $request){
		$url = parse_url($_SERVER['HTTP_REFERER']);
		$trimmedHeader = $url['path'];
		if($trimmedHeader=='/rejectedtimesheetlist'){
			$redirectpath="/rejectedtimesheetlist";
		}else{
			$redirectpath="/rejectedtimesheetlist/";
		}
		if(!empty($user_id) && !empty($entry_id) && !empty($associate_id)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/deletRejectedTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$deletetimeentry = json_encode(array("loggedInUserId" => $user_id,"associateId" => $associate_id,
		"timeSheetId" => $entry_id));
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $deletetimeentry);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);	
		 if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'The Time Entry Deleted Successfully!');
			return redirect($redirectpath);
		 }else{
			 $message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
			}
		}
		}else{	
			$request->session()->flash('danger', 'Something Went Wrong');
				return redirect($redirectpath);
		}
	}
	
	/** Ticket Rejected Timesheet Delete  **/
	public function TicketRejectDeleteTimesheet($entry_id,$associate_id,$user_id,Request $request){
		$url = parse_url($_SERVER['HTTP_REFERER']);
		$trimmedHeader = $url['path'];
		if($trimmedHeader=='/rejectedtimesheetlist'){
			$redirectpath="/rejectedtimesheetlist";
		}else{
			$redirectpath="/rejectedtimesheetlist/";
		}
		if(!empty($user_id) && !empty($entry_id) && !empty($associate_id)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/deletRejectedTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$deletetimeentry = json_encode(array("loggedInUserId" => $user_id,"associateId" => $associate_id,
		"timeSheetId" => $entry_id));
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $deletetimeentry);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);	
		 if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'The Time Entry Deleted Successfully!');
			return redirect($redirectpath);
		 }else{
			 $message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
				return redirect($redirectpath);
			}
		}
		}else{	
			$request->session()->flash('danger', 'Something Went Wrong');
				return redirect($redirectpath);
		}
	}
	/** 
	 * Get the Associate id based Timesheet Details
	 * like Approved and Rejected
	 * return store data value
	 **/
	public function getAssociateTimesheetDetails(Request $request,$associate_id)
	{

		$associateProfileid=$associate_id;
		if(!empty($associateProfileid)){
			
		/* Get the Submitted Timesheet list */
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/getSubmittedTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		curl_setopt($ch, CURLOPT_URL, $url.'?loggedInUserId='.$associateProfileid);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$submittedresult = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($submittedresult['StatusCode']) && $submittedresult['StatusCode']=='200'){
		$data['associatesubmittedtimesheetdata'] = $submittedresult['result'];
		}
		/* Get the Approved Timesheet list */
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/getApprovedTimeSheetEntryByAssociate';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		curl_setopt($ch, CURLOPT_URL, $url.'?profileId='.$associateProfileid);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$approvedresult = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($approvedresult['StatusCode']) && $approvedresult['StatusCode']=='200'){
		$data['associateapprovedtimesheetdata'] = $approvedresult['result'];
		}
		/* Get the Rejected Timesheet list */
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/getRejectedTimeSheetEntryByAssociate';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		curl_setopt($ch, CURLOPT_URL, $url.'?profileId='.$associateProfileid);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$rejectedresult = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($rejectedresult['StatusCode']) && $rejectedresult['StatusCode']=='200'){
		$data['associaterejectedtimesheetdata'] = $rejectedresult['result'];
		}
		$userId=$request->session()->get('user_role');
		if($userId=='2'){
		if(!empty($data)){
			return view('timesheet.timesheet_userwise_timesheet_2',$data);
		}else{
			return view('timesheet.timesheet_userwise_timesheet_2');	
		}
		}else{
		if(!empty($data)){
			return view('timesheet.timesheet_userwise_timesheet_1',$data);
		}else{
			return view('timesheet.timesheet_userwise_timesheet_1');	
		}
			
			
		}	
	  }
	}
	/** Import Task Time Entry */
	public function ImportTasktimestore(Request $request)
	{	
		/* Timesheet Save */
		if ($request->get('action') == 'save') {
		$input = $request->all();
		$projectid=$input['task_projectid'];
		$taskid=$input['task_id'];
		$associateid=$input['associate_id'];
		$redirectpath="/taskdetails/".$taskid;
		$mimes = array('application/vnd.ms-excel','text/plain','text/csv','text/tsv');
		if(in_array($_FILES['file']['type'],$mimes)){
		$filename=$_FILES["file"]["tmp_name"];
		 if($_FILES["file"]["size"] > 0)
		 {
		  	$file = fopen($filename, "r");
		  	$flag = true;
		  	$timeentryData=array();
	         while (($importtimeData = fgetcsv($file, 10000, ",")) !== FALSE)
	         { if($flag) { $flag = false; continue; }
				 $timeentryData[]=$importtimeData;
				 
			 }
	   $resultdetailsarray=array();
	   foreach($timeentryData as $index=>$value){
				$entrydate=date('Y-m-d', strtotime($value['0']));
				$comment=$value['1'];
				$hours=$value['2'];
				$redirectpath="/taskdetails/".$taskid;
		if(!empty($projectid) && !empty($taskid) && !empty($associateid) && !empty($entrydate) && !empty($comment) && !empty($hours)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/saveTimeSheetEntry';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$entrydata = json_encode(array("timeSheetEntries"=>array("projectId" => $projectid,"taskId" => $taskid,
		"dateAndTime" => $entrydate,"comments" => $comment,"associateId" => $associateid,"hours" => $hours)));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $entrydata);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetailsarray[] = json_decode($result,true);
		}
		else{
			$request->session()->flash('danger', 'Time not created please enter valid inputs');
			}
		}
		foreach($resultdetailsarray as $resultdetails){
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='201'){
			$request->session()->flash('success', 'Time Entry created successfully!');
		}else{
			$info=$resultdetails['StatusInfo']['info'];
			if(!empty($info)){
			if(!empty($info['StatusInfo'])){
				$message=$info['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				}
			}
			}else if(!empty($resultdetails['StatusInfo'])){
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				}
			}
		}
		}
		}else{
			$request->session()->flash('danger', 'Something Went Wrong');
			}	 
	    }
	    else {
		$request->session()->flash('danger', 'Sorry, Timesheet Import only Accept the CSV file');
		}
		return redirect($redirectpath);
		/* Timesheet Save and Submit */
		} elseif ($request->get('action') == 'save_and_submit') {
		$input = $request->all();
		$projectid=$input['task_projectid'];
		$taskid=$input['task_id'];
		$associateid=$input['associate_id'];
		$loggedinId=$input['loggedin_id'];
		$redirectpath="/taskdetails/".$taskid;
		$mimes = array('application/vnd.ms-excel','text/plain','text/csv','text/tsv');
		if(in_array($_FILES['file']['type'],$mimes)){
		$filename=$_FILES["file"]["tmp_name"];
		 if($_FILES["file"]["size"] > 0)
		 {
		  	$file = fopen($filename, "r");
		  	$flag = true;
		  	$timeentryData=array();
	         while (($importtimeData = fgetcsv($file, 10000, ",")) !== FALSE)
	         { if($flag) { $flag = false; continue; }
				 $timeentryData[]=$importtimeData;
				 
			 }
			$resultdetailsarray=array();
		foreach($timeentryData as $index=>$value){
				$entrydate=date('Y-m-d', strtotime($value['0']));
				$comment=$value['1'];
				$hours=$value['2'];
				$redirectpath="/taskdetails/".$taskid;
		if(!empty($projectid) && !empty($taskid) && !empty($associateid) && !empty($entrydate) && !empty($comment) && !empty($hours)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/saveTimeSheetEntry';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$entrydata = json_encode(array("timeSheetEntries"=>array("projectId" => $projectid,"taskId" => $taskid,
		"dateAndTime" => $entrydate,"comments" => $comment,"associateId" => $associateid,"hours" => $hours)));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $entrydata);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetailsarray[] = json_decode($result,true);
		}
		}
		foreach($resultdetailsarray as $resultdetails){
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='201'){
			$entryid=$resultdetails['result']['id'];
			if(!empty($loggedinId) && !empty($entryid) ){
				$saveandsubmit=$this->SaveandSubmitTimesheet($entryid,$loggedinId);
			}
			if(!empty($saveandsubmit)){
			if($httpcode=='201' || $httpcode=='200' && !empty($saveandsubmit['StatusCode']) && $saveandsubmit['StatusCode']=='200'){
			$request->session()->flash('success', 'Time Entry created and Submitted to your manager successfully!');
			}
			}else{
				$request->session()->flash('success', 'Time Entry created successfully!');
			}
		}else{
			$info=$resultdetails['StatusInfo']['info'];
			if(!empty($info)){
			if(!empty($info['StatusInfo'])){
				$message=$info['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				}
			}
			}else if(!empty($resultdetails['StatusInfo'])){
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				}
			}
		}
		}
		}else{
			$request->session()->flash('danger', 'Timesheet not created please enter valid inputs');
		}
		}else{
			$request->session()->flash('danger', 'Sorry, Timesheet Import only Accept the CSV file');	
		}
		return redirect($redirectpath);
	}	
	}	
	
	/** Import Ticket Time Entry */
	public function ImportTickettimestore(Request $request)
	{	
		/* Timesheet Save */
		if ($request->get('action') == 'save') {
		$input = $request->all();
		$ticketid=$input['ticket_id'];
		$associateid=$input['associate_id'];
		$redirectpath="/ticketdetails/".$ticketid;
		$mimes = array('application/vnd.ms-excel','text/plain','text/csv','text/tsv');
		if(in_array($_FILES['file']['type'],$mimes)){
		$filename=$_FILES["file"]["tmp_name"];
		 if($_FILES["file"]["size"] > 0)
		 {
		  	$file = fopen($filename, "r");
		  	$flag = true;
		  	$timeentryData=array();
	         while (($importtimeData = fgetcsv($file, 10000, ",")) !== FALSE)
	         { if($flag) { $flag = false; continue; }
				 $timeentryData[]=$importtimeData;
				 
			 }
	   $resultdetailsarray=array();
	   foreach($timeentryData as $index=>$value){
				$entrydate=date('Y-m-d', strtotime($value['0']));
				$comment=$value['1'];
				$hours=$value['2'];
				$redirectpath="/ticketdetails/".$ticketid;
		if(!empty($ticketid) && !empty($associateid) && !empty($entrydate) && !empty($comment) && !empty($hours)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/saveTimeSheetForTicket';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$entrydata = json_encode(array("ticketId" => $ticketid,
		"entryDate" => $entrydate,"comments" => $comment,"associateId" => $associateid,"hours" => $hours));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $entrydata);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetailsarray[] = json_decode($result,true);
		}
		}
		foreach($resultdetailsarray as $resultdetails){
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='201'){
			$request->session()->flash('success', 'Time Entry created successfully!');
		}else{
			$info=$resultdetails['StatusInfo']['info'];
			if(!empty($info)){
			if(!empty($info['StatusInfo'])){
				$message=$info['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				}
			}
			}else if(!empty($resultdetails['StatusInfo'])){
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				}
			}
		}
		}
		}else{
			$request->session()->flash('danger', 'Something Went Wrong');
			}	 
	    }
	    else {
		$request->session()->flash('danger', 'Sorry, Timesheet Import only Accept the CSV file');
		}
		return redirect($redirectpath);
		/* Timesheet Save and Submit */
		} elseif ($request->get('action') == 'save_and_submit') {
		$input = $request->all();
		$ticketid=$input['ticket_id'];
		$associateid=$input['associate_id'];
		$loggedinId=$input['loggedin_id'];
		$redirectpath="/ticketdetails/".$ticketid;
		$mimes = array('application/vnd.ms-excel','text/plain','text/csv','text/tsv');
		if(in_array($_FILES['file']['type'],$mimes)){
		$filename=$_FILES["file"]["tmp_name"];
		 if($_FILES["file"]["size"] > 0)
		 {
		  	$file = fopen($filename, "r");
		  	$flag = true;
		  	$timeentryData=array();
	         while (($importtimeData = fgetcsv($file, 10000, ",")) !== FALSE)
	         { if($flag) { $flag = false; continue; }
				 $timeentryData[]=$importtimeData;
				 
			 }
		$resultdetailsarray=array();
		foreach($timeentryData as $index=>$value){
				$entrydate=date('Y-m-d', strtotime($value['0']));
				$comment=$value['1'];
				$hours=$value['2'];
				$redirectpath="/ticketdetails/".$ticketid;
		if(!empty($ticketid) && !empty($associateid) && !empty($entrydate) && !empty($comment) && !empty($hours)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/saveTimeSheetForTicket';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$entrydata = json_encode(array("ticketId" => $ticketid,
		"entryDate" => $entrydate,"comments" => $comment,"associateId" => $associateid,"hours" => $hours));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $entrydata);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetailsarray[] = json_decode($result,true);
		}
		}
		foreach($resultdetailsarray as $resultdetails){
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='201'){
			$entryid=$resultdetails['result']['id'];
			if(!empty($loggedinId) && !empty($entryid) ){
				$saveandsubmit=$this->TicketSavedAndSubmitTimesheet($entryid,$loggedinId);
			}
			if(!empty($saveandsubmit)){
			if($httpcode=='201' || $httpcode=='200' && !empty($saveandsubmit['StatusCode']) && $saveandsubmit['StatusCode']=='200'){
				$request->session()->flash('success', 'Time Entry created and Submitted to your manager successfully!');
			}
			}else{
				$request->session()->flash('success', 'Time Entry created successfully!');
			}
		}else if($httpcode=='400' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='400'){
			$message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
			}
		}else{
			$info=$resultdetails['StatusInfo']['info'];
			if(!empty($info)){
			if(!empty($info['StatusInfo'])){
				$message=$info['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
			   }
			}
			}
			if(!empty($resultdetails['StatusInfo'])){
				$message=$resultdetails['StatusInfo']['message'];
				if(!empty($message)){
				$request->session()->flash('danger',$message);
				}
			}
			
		}
		}
		}else{
			$request->session()->flash('danger', 'Timesheet not created please enter valid inputs');
		}
		}else{
			$request->session()->flash('danger', 'Sorry, Timesheet Import only Accept the CSV file');
		}
		return redirect($redirectpath);
	  }	
	}	
}
