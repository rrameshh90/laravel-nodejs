<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use View;
class HelperController extends Controller
{
	public static function gettaskStatus($status_id)
	{
			$status='';
			if($status_id=='1'){
				$status="New";
			}elseif($status_id=='2'){
				$status="Inprogress";
			}elseif($status_id=='3'){ 
				$status="Delayed";
			}elseif($status_id=='4'){ 
				$status="Closed";
			}
			elseif($status_id=='5'){ 
				$status="Deleted";
			}
			return $status;
	}
	public static function getticketStatus($status_id)
	{
			$status='';
			if($status_id=='1'){
				$status="Open";
			}elseif($status_id=='2'){
				$status="Closed";
			}
			return $status;
	}
	public static function getprojectStatus($status_id)
	{
			$status='';
			if($status_id=='1'){
				$status="New";
			}elseif($status_id=='2'){
				$status="Inprogress";
			}elseif($status_id=='3'){ 
				$status="Delayed";
			}elseif($status_id=='4'){ 
				$status="Closed";
			}
			return $status;
	}		
	public static function getEditProjectstatus($status_id){
		
		$status=$status_id;
		$selected="selected";
		$html='';
		$html.='<div class="form-group">
				<label for="ProjectStatus">Project Status<span class="red">*</span></label>
				<select class="form-control"  name="project_status" required>
				<option value="">Select Option</option>';
				if($status_id=='1'){
		$html.='<option value="1"'.$selected.'>New</option>
		       <option value="2">InProgress</option>
		       <option value="3">Delayed</option>
		       <option value="4">Closed</option>';
				}elseif($status_id=='2'){
		$html.='<option value="1">New</option>
		       <option value="2"'.$selected.'>InProgress</option>
		       <option value="3">Delayed</option>
		       <option value="4">Closed</option>';
		         }elseif($status_id=='3'){
		$html.='<option value="1">New</option>
		       <option value="2">InProgress</option>
		       <option value="3"'.$selected.'>Delayed</option>
		       <option value="4">Closed</option>';
		          }elseif($status_id=='4'){ 
	   $html.='<option value="1">New</option>
		       <option value="2">InProgress</option>
		       <option value="3">Delayed</option>
		       <option value="4" '.$selected.'>Closed</option>';
				 } 
											
		$html.='</select></div>';
		return $html;
		
	}
	
	public static function getEditTaskstatus($status_id){
		
		$status=$status_id;
		$selected="selected";
		$html='';
		$html.='<div class="form-group">
				<label for="ProjectStatus">Task Status<span class="red">*</span></label>
				<select class="form-control"  name="task_status" required>
				<option value="">Select Option</option>';
				if($status_id=='1'){
		$html.='<option value="1"'.$selected.'>New</option>
		       <option value="2">InProgress</option>
		       <option value="3">Delayed</option>
		       <option value="4">Closed</option>
		       <option value="5">Deleted</option>';
				}elseif($status_id=='2'){
		$html.='<option value="1">New</option>
		       <option value="2"'.$selected.'>InProgress</option>
		       <option value="3">Delayed</option>
		       <option value="4">Closed</option>
		       <option value="5">Deleted</option>';
		         }elseif($status_id=='3'){
		$html.='<option value="1">New</option>
		       <option value="2">InProgress</option>
		       <option value="3"'.$selected.'>Delayed</option>
		       <option value="4">Closed</option>
		       <option value="5">Deleted</option>';
		          }elseif($status_id=='4'){ 
	   $html.='<option value="1">New</option>
		       <option value="2">InProgress</option>
		       <option value="3">Delayed</option>
		       <option value="4" '.$selected.'>Closed</option>
		       <option value="5">Deleted</option>';
				 }elseif($status_id=='5'){ 
		$html.='<option value="1">New</option>
		       <option value="2">InProgress</option>
		       <option value="3">Delayed</option>
		       <option value="4" >Closed</option>
		       <option value="5" '.$selected.'>Deleted</option>';
		} 									
		$html.='</select></div>';
		return $html;
		
	}
	public static function getEditTicketstatus($status_id){
		
		$status=$status_id;
		$selected="selected";
		$html='';
		$html.='<div class="form-group">
				<label for="ProjectStatus">Ticket Status<span class="red">*</span></label>
				<select class="form-control"  name="ticket_status" required>
				<option value="">Select Option</option>';
				if($status_id=='1'){
		$html.='<option value="1"'.$selected.'>Open</option>
		       <option value="2">Closed</option>';
				}elseif($status_id=='2'){
		$html.='<option value="1">Open</option>
		       <option value="2"'.$selected.'>Closed</option>';
		         }						
		$html.='</select></div>';
		return $html;
		
	}
	public static function getProjectManagerName($manager_id)
	{
		if (!empty($manager_id)) {
			$url=config('app.resturl').'NuTimeSheetApi/UserProfile/getProfileDetailsById';	
			$ch = curl_init($url);
			$username=config('app.api_username');
			$password=config('app.api_password');
			$managerprofileid = json_encode(array("profileId" => $manager_id));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $managerprofileid);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			$result = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			$managerdetails = json_decode($result,true);
			if($httpcode=='200' || $httpcode=='201' && !empty($managerdetails['StatusCode']) && $managerdetails['StatusCode']=='200'){
				return $managerdetails['result']['name'];
			}else{
				return '';
			}
			
			
		}
	}
	
	public static function getProfileInfo($profile_id)
	{
		if (!empty($profile_id)) {
			$url=config('app.resturl').'NuTimeSheetApi/UserProfile/getProfileDetailsById';	
			$ch = curl_init($url);
			$username=config('app.api_username');
			$password=config('app.api_password');
			$profileid = json_encode(array("profileId" => $profile_id));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $profileid);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			$result = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			$profiledetails = json_decode($result,true);
			if($httpcode=='200' || $httpcode=='201' && !empty($profiledetails['StatusCode']) && $profiledetails['StatusCode']=='200'){
				return $profiledetails['result'];
			}else{
				return '';
			}
			
			
		}
	}
	public static function getProjectName($project_id)
	{
		if (!empty($project_id)) {
			$url=config('app.resturl').'NuTimeSheetApi/Project/getProjectByProjectId';	
			$ch = curl_init($url);
			$username=config('app.api_username');
			$password=config('app.api_password');
			$projectid = json_encode(array("projectId" => $project_id));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $projectid);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			$result = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			$projectdetails = json_decode($result,true);
			if($httpcode=='200' || $httpcode=='201' && !empty($projectdetails['StatusCode']) && $projectdetails['StatusCode']=='200'){
				return $projectdetails['result']['Name'];
			}else{
				return '';
			}	
		}
	}	
	public static function getTaskName($task_id)
	{
		if (!empty($task_id)) {
			$url=config('app.resturl').'NuTimeSheetApi/Project/taskDetailsByTaskid';	
			$ch = curl_init($url);
			$username=config('app.api_username');
			$password=config('app.api_password');
			$taskId = json_encode(array("taskId" => $task_id));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $taskId);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			$result = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			$taskdetails = json_decode($result,true);
			if($httpcode=='200' || $httpcode=='201' && !empty($taskdetails['StatusCode']) && $taskdetails['StatusCode']=='200'){
				return $taskdetails['result']['name'];
			}else{
				return '';
			}
			
			
		}
	}	
	
	public static function getTicketName($ticket_id)
	{
		if(!empty($ticket_id)){
		$url=config('app.resturl').'NuTimeSheetApi/Project/getTicketDetailsByTicketId';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		curl_setopt($ch, CURLOPT_URL, $url.'?ticketId='.$ticket_id);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$ticketdetails = json_decode($result,true);
			if($httpcode=='200' || $httpcode=='201' && !empty($ticketdetails['StatusCode']) && $ticketdetails['StatusCode']=='200'){
				return $ticketdetails['result']['Title'];
			}else{
				return '';
			}
			
			
		}
	}	
	/**
	 * Updated ProjectStatus 
	 **/
	Public static function UpdateProjectStatus($loggedInUserId,$projectid,$project_name,$project_desc,$project_status){
		if(!empty($loggedInUserId) && !empty($projectid) && !empty($project_name) && !empty($project_desc) && !empty($project_status)){
		$url=config('app.resturl').'NuTimeSheetApi/Project/editProjectDetails';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$updateprojectdetails = json_encode(array("loggedInUserId" => $loggedInUserId,"projectId" => $projectid,
		"Name" => $project_name,"desc" => $project_desc,"state" => $project_status));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $updateprojectdetails);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			return $resultdetails['result'];
		}
		}
	}
	/**
	 * Updated TaskStatus 
	 **/
	Public static function UpdateTaskStatus($loggedInUserId,$taskid,$task_name,$task_status){
		if(!empty($loggedInUserId) && !empty($taskid) && !empty($task_name) && !empty($task_status)){
		$url=config('app.resturl').'NuTimeSheetApi/Project/editTaskDetails';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$updatetaskdetails = json_encode(array("loggedInUserId" => $loggedInUserId,"taskId" => $taskid,
		"name" => $task_name,"state" => $task_status));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $updatetaskdetails);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			return $resultdetails['result'];
		}
	}
	}
	
}

