<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use Mail;
class TicketManageController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
		$userId=$request->session()->get('user_id');
		if (!empty($userId)) {
		$url=config('app.resturl').'NuTimeSheetApi/Project/getListOfTickets';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		curl_setopt($ch, CURLOPT_URL, $url.'?loggedInUserId='.$userId);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='200' || $httpcode=='201' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		//$request->session()->put('projectlists', $projectlist['result']);
		$data['ticket_listdata'] = $resultdetails['result'];
		return view('ticket.tickets_list',$data);		
        }else{
			//return redirect('/login');
			return view('ticket.tickets_list');
		}
		
	}
	}
		/**
	 * Show the form for creating a new tickets
	 *
     * @return \Illuminate\View\View
	 */
	public function create(Request $request)
	{
		$userId=$request->session()->get('user_id');
		if (!empty($userId)) {
		$getallprofile=$this->getAllUserDetails($request,$userId);
		$getallproject=$this->getAllProjectDetails($request,$userId);
           if(!empty($getallprofile)){
			    $managementuser=array();
			    $managers=array();
			    $associates=array();
				foreach($getallprofile as $user){
					if($user['role']=='1'){
						$managementuser[]=$user;
					}
					if($user['role']=='2'){
						$managers[]=$user;
					}
					if($user['role']=='3'){
						$associates[]=$user;
					}
				}
				$data['management_user'] = $managementuser;
				$data['managers_list'] = $managers;
				$data['associate_list'] = $associates;
				}
			if(!empty($getallproject)){
				foreach($getallproject as $project){
						$projectlists[]=$project;
				}
				if(!empty($projectlists)){
				$data['project_list'] = $projectlists;
				}
			}
			if(!empty($data)){
				return view('ticket.ticket_create',$data);
			}else{
				return view('ticket.ticket_create');
			}
        }else{
			return redirect('/login');
		}
	    
	}
	public function getAllUserDetails(Request $request,$userId)
	{
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/UserProfile/getAllprofile';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$loggedinid = json_encode(array("loggedInUserId" => $userId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinid);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$getalluser = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($getalluser['StatusCode']) && $getalluser['StatusCode']=='200')
		{
		    return $getalluser['result'];
        }else{
			return redirect('/login');
		}
	  }
	}
	
	public function getAllProjectDetails(Request $request,$userId)
	{
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/Project/getProjectByUserId';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$loggedinid = json_encode(array("id" => $userId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinid);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$getallproject = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($getallproject['StatusCode']) && $getallproject['StatusCode']=='200')
		{
		    return $getallproject['result'];
        }else{
			return redirect('/login');
		}
	  }
	}
	public function store(Request $request){
		
		$input = $request->all();
		$ticketname=$input['ticket_name'];
		$ticketdesc=$input['ticket_desc'];
		if(!empty($input['associateId'])){
		$associateId=$input['associateId'];
		}
		$loggedinId=$request->session()->get('user_id');
		$managementid=$input['management_id'];
		$projectid=$input['project_id'];
		if(!empty($ticketname) && !empty($ticketdesc) && !empty($loggedinId) && !empty($associateId) && !empty($managementid) && !empty($projectid)){
		$resultdetailsarray=array();
		foreach($associateId as $id){
		$url=config('app.resturl').'NuTimeSheetApi/Project/creatTicketTask';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$entrydata = json_encode(array("title" => $ticketname,"description" => $ticketdesc,"loggedInUserId" => $loggedinId,"associateProfileIds"=>array($id),"superVisor" => $managementid,"projectId" => $projectid));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $entrydata);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetailsarray[] = json_decode($result,true);
		}	
		foreach($resultdetailsarray as $resultdetails){
		$redirectpath="/ticket_list/";
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'Ticket created successfully!');
			return redirect($redirectpath);
		}else if($httpcode=='201' || $httpcode=='200' || $httpcode=='400' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200' && $resultdetails['StatusCode']=='400'){
			$request->session()->flash('success', 'Ticket created successfully!');
			$message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
			}
			return redirect($redirectpath);
		}else if($httpcode=='400' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='400'){
			$message=$resultdetails['StatusInfo']['message'];
			if(!empty($message)){
				$request->session()->flash('danger',$message);
			}
				return redirect($redirectpath);
		}
		}
		}else{
			$request->session()->flash('danger', 'Ticket not created please enter valid inputs');
			return redirect($redirectpath);
		}
	}
	public function show($ticketid,Request $request)
	{
		if(!empty($ticketid)){
		$url=config('app.resturl').'NuTimeSheetApi/Project/getTicketDetailsByTicketId';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		curl_setopt($ch, CURLOPT_URL, $url.'?ticketId='.$ticketid);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		$userId=$request->session()->get('user_id');
		$userrole=$request->session()->get('user_role');
		$getalltimesheets = $this->getSavedTimesheet($userId,$request);
		if($userrole=='2' || $userrole=='3'){
		$getsubmittedtimesheets = $this->getSubmittedTimesheet($userId,$request);
		}
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		$data['ticketdetail_data'] = $resultdetails['result'];
		if(!empty($getalltimesheets)){
			$data['savedtimesheet_list'] = $getalltimesheets;
		}
		if(!empty($getsubmittedtimesheets)){
			$data['submitted_timesheet_list'] = $getsubmittedtimesheets;
		}
			return view('ticket.ticket_details', $data);
		}else{
		 $request->session()->flash('danger', 'Unable view Ticket details right now.Please try after some time!');
		 return redirect('/ticket_list');
		}	
		}
	}
	public function getSavedTimesheet($userId,$request)
	{
		/* Get the Associate Saved Timesheet list */
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/getSavedTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$loggedinId = json_encode(array("loggedInUserId" => $userId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinId);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		$request->session()->put('associate_timesheetlist', $resultdetails['result']);
		 return $resultdetails['result'];
		}	
		}
	
	}
	
	public function getSubmittedTimesheet($userId,$request)
	{
		/* Get the Associate Submitted Timesheet list */
		if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/getSubmittedTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		curl_setopt($ch, CURLOPT_URL, $url.'?loggedInUserId='.$userId);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if($httpcode=='201' || $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
		$request->session()->put('submitted_timesheetlist', $resultdetails['result']);
		$request->session()->put('submitted_timesheetlistcount', count($resultdetails['result']));
		return $resultdetails['result'];
		}	
		}
	
	}
	Public function UpdateTicketdetail(Request $request){
		
		$input=$request->all();
		if(!empty($input['ticketid']) && !empty($input['ticket_name']) && !empty($input['ticket_desc']) && !empty($input['ticket_status'])){
		$url=config('app.resturl').'NuTimeSheetApi/Project/editTicket';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$updateticketdetails = json_encode(array("ticketId" => $input['ticketid'],"title" => $input['ticket_name'],"description" => $input['ticket_desc'],"state" => $input['ticket_status']));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $updateticketdetails);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		if(!empty($resultdetails)){
		if($httpcode=='201'|| $httpcode=='200' && !empty($resultdetails['StatusCode']) && $resultdetails['StatusCode']=='200'){
			$request->session()->flash('success', 'Ticket Updated successfully!');
			return redirect('/ticket_list');
		}else{
			if(!empty($resultdetails['StatusInfo']['message'])){
				$request->session()->flash('danger', $resultdetails['StatusInfo']['message']);
			}else{
			$request->session()->flash('danger', 'Ticket not Updated please enter valid inputs');
			}	
			return redirect('/ticket_list');
		}
		}
		}else{
		$request->session()->flash('danger', 'Something Went Wrong');
			return redirect('/ticket_list');
		}
	}
	
	

	

}
