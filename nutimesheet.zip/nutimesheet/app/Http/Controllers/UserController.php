<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
class UserController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function authenticate(Request $request)
    {
		$userdetail = Input::get('userdetails');
		$gmailuserdetail = Input::get('gmaildetail');
		$logindetails=array();
		$logindetails = json_decode($userdetail,true);
		$user_id=$logindetails['result']['id'];
		$user_role=$logindetails['result']['role'];
		$user_info=$logindetails['result'];
		$user_status=$logindetails['StatusCode'];
		$request->session()->put('user_id', $user_id);
		$request->session()->put('user_role', $user_role);
		$request->session()->put('userdetails', $user_info);
		$request->session()->put('gmaildetails', $gmailuserdetail);
		$userId=$request->session()->get('user_id');
		if(!empty($userId)){
		$dashboard_user = $this->getUserDashboard($userId);
		$dashboard_associateuser = $this->getAssociateUserDashboard($userId);
		if(!empty($dashboard_user['StatusCode']) && $dashboard_user['StatusCode']=='200' && !empty($dashboard_user['result'])){
			$userdetails=array();
			foreach($dashboard_user['result'] as $user){
				$userdetails[]=$user['id'];
		}
		$request->session()->put('dashboard_usercount', count($userdetails));
		$request->session()->put('dashboard_userdetails', $userdetails);
		}
		if(!empty($dashboard_associateuser['StatusCode']) && $dashboard_associateuser['StatusCode']=='200' && !empty($dashboard_associateuser['result'])){
			//$associateuserdetails=array();
				$associateuserdetails=$dashboard_associateuser;
		/* Associate User Task & Project */
		$request->session()->put('associateuserdetails', $associateuserdetails);
		$request->session()->put('associateprojectcount', count($associateuserdetails['result']['Projects']));
		$request->session()->put('associatetaskcount', count($associateuserdetails['result']['tasks']));
		}
		$dashboard_project = $this->getProjectDashboard($userId);
		if(!empty($dashboard_project['StatusCode']) && $dashboard_project['StatusCode']=='200' && !empty($dashboard_project['result'])){
		$request->session()->put('dashboard_projectcount', count($dashboard_project['result']));
		$request->session()->put('dashboard_project', $dashboard_project['result']);
		}
		
		$getassociatetimesheets = $this->getAssociateTimesheetList($userId);
	
		if(!empty($getassociatetimesheets['StatusCode']) && $getassociatetimesheets['StatusCode']=='200'){
		if(!empty($getassociatetimesheets['result'])){
		$request->session()->put('associate_timesheetlist', $getassociatetimesheets['result']);
		$request->session()->put('associate_timesheetcount', count($getassociatetimesheets['result']));
		}
		}
		if($user_role=='2' || $user_role=='3'){
		$getsubmittedtimesheets = $this->getSubmittedTimesheetList($userId);
		if(!empty($getsubmittedtimesheets['StatusCode']) && $getsubmittedtimesheets['StatusCode']=='200'){
		if(!empty($getsubmittedtimesheets['result'])){
		$submittedtimesheet=array();
		foreach($getsubmittedtimesheets['result'] as $getsubmittedresult){
			if($getsubmittedresult['isSubmitted']=='1'){
			  $submittedtimesheet[]=$getsubmittedresult;
		    }
		}
		if(!empty($submittedtimesheet)){
		$request->session()->put('submitted_timesheetlist', $submittedtimesheet);
		$request->session()->put('submitted_timesheetlistcount', count($submittedtimesheet));
		}
		}
		}
		}
		 return $this->dashboard($request);
        }else{
			return Redirect::route('login');
		}
    }
    public function dashboard(Request $request)
    {	
		$userId=$request->session()->get('user_id');
		if (!empty($userId)) {
		$dashboard_project = $this->getProjectDashboard($userId);
		if(!empty($dashboard_project['StatusCode']) && $dashboard_project['StatusCode']=='200' && !empty($dashboard_project['result'])){
		$request->session()->put('dashboard_projectcount', count($dashboard_project['result']));
		$request->session()->put('dashboard_project', $dashboard_project['result']);
		}
		$user_role=$request->session()->get('user_role');
		if($user_role=='2' || $user_role=='3'){
		$getsubmittedtimesheets = $this->getSubmittedTimesheetList($userId);
		if(!empty($getsubmittedtimesheets['StatusCode']) && $getsubmittedtimesheets['StatusCode']=='200'){
		if(!empty($getsubmittedtimesheets['result'])){
		$submittedtimesheet=array();
		foreach($getsubmittedtimesheets['result'] as $getsubmittedresult){
			if($getsubmittedresult['isSubmitted']=='1'){
			  $submittedtimesheet[]=$getsubmittedresult;
		    }
		}
		if(!empty($submittedtimesheet)){
		$request->session()->put('submitted_timesheetlist', $submittedtimesheet);
		$request->session()->put('submitted_timesheetlistcount', count($submittedtimesheet));
		}
		}
		}
		}
		$getassociatetimesheets = $this->getAssociateTimesheetList($userId);
	
		if(!empty($getassociatetimesheets['StatusCode']) && $getassociatetimesheets['StatusCode']=='200'){
		if(!empty($getassociatetimesheets['result'])){
		$request->session()->put('associate_timesheetlist', $getassociatetimesheets['result']);
		$request->session()->put('associate_timesheetcount', count($getassociatetimesheets['result']));
		}
		}
		return view('dashboard');
		}else{
			return redirect('/login');
		}
	}
	
	public function getUserDashboard($userId)
	{
		if (!empty($userId)) {
			/* get AllAssociate User */
			$url=config('app.resturl').'NuTimeSheetApi/UserProfile/getAllprofile';	
			$ch = curl_init($url);
			$username=config('app.api_username');
			$password=config('app.api_password');
			$loggedinid = json_encode(array("loggedInUserId" => $userId));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinid);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			$result = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			$userdetails = json_decode($result,true);
			return $userdetails;
			
		}
	}
	public function getAssociateUserDashboard($userId)
	{
		if (!empty($userId)) {
		/* Associate User Project And Task details */ 
			$url=config('app.resturl').'NuTimeSheetApi/UserProfile/getAssociateById';	
			$ch = curl_init($url);
			$username=config('app.api_username');
			$password=config('app.api_password');
			$loggedinid = json_encode(array("loggedInUserId" => $userId));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinid);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			$result = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			$associateuserdetails = json_decode($result,true);
			return $associateuserdetails;	
			}
	}
	public function getProjectDashboard($userId)
	{
	if (!empty($userId)) {
		/* get All Project Details */
		$url2=config('app.resturl').'NuTimeSheetApi/Project/getProjectByUserId';	
		$ch = curl_init($url2);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$loggedinid = json_encode(array("id" => $userId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinid);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$projectdetails = json_decode($result,true);
		return $projectdetails;	
		}	
		
	}
	
	public function getAssociateTimesheetList($userId)
	{
	if(!empty($userId)){
		$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/getSavedTimeSheet';	
		$ch = curl_init($url);
		$username=config('app.api_username');
		$password=config('app.api_password');
		$loggedinId = json_encode(array("loggedInUserId" => $userId));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loggedinId);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		$result = curl_exec($ch);
		$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		$resultdetails = json_decode($result,true);
		return $resultdetails;
		}		
	}
	
	public function getSubmittedTimesheetList($userId)
	{
		if(!empty($userId)){
			$url=config('app.resturl').'NuTimeSheetApi/TimeSheet/getSubmittedTimeSheet';	
			$ch = curl_init($url);
			$username=config('app.api_username');
			$password=config('app.api_password');
			curl_setopt($ch, CURLOPT_URL, $url.'?loggedInUserId='.$userId);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			$result = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			$resultdetails = json_decode($result,true);
			return $resultdetails;
		}	
	}
}
