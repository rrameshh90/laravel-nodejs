<div class="modal right fade" id="<?php echo "updatetimeentrymodal".$entry['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
					<div class="modal-dialog" role="document">
						<div class="modal-content">

							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								<h4 class="modal-title" id="addentryLabel1">Update Time Entry</h4>
							</div>
					
							<div class="modal-body">
								<div class="row">
										<!-- left column -->
										<div class="col-md-12">
										  <!-- general form elements -->
										  <div class="box box-primary">
											<div class="box-header with-border">
											  <h3 class="box-title">Update Time Entry</h3>
											</div>
											<!-- /.box-header -->
											<!-- form start -->
											<form role="form" method="POST" action="/ticketupdateentrysubmit" id="updatetimeentryform">
												 {{ csrf_field() }}
											  <div class="box-body">
												  <input type="hidden" name="loggedin_id" value="{{Session::get('userdetails.id')}}" id="user_id"></input>
												  <input type="hidden" name="entry_id" value="{{$entry['id']}}" id="entry_id"></input>
												  <input type="hidden" name="ticket_id" value="{{$ticketdetail_data['id']}}" id="ticket_id"></input>
												<div class="form-group">
												   <label for="Inputcomment">Comment<span class="red">*</span></label>
												  <textarea type="text" name="comments" class="form-control" id="Inputcomment"  placeholder="Task Comments" required>{{$entry['comments']}}</textarea>
												</div>	
												<div class="form-group">
												   <label for="Inputhours">Hours<span class="red">*</span></label>
												  <input type="text" name="hours" class="form-control" value="{{$entry['hours']}}" id="Inputhours" placeholder="Task Hours" required>
												</div>	
												 <input type="hidden" name="associate_id" value="{{Session::get('associateuserdetails.result.id')}}" id="associate_id"></input>
											  </div>
											  <!-- /.box-body -->
											  <div class="box-footer">
												<button type="submit" class="btn btn-primary">Save</button>
												<button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Cancel</button>
												
											  </div>
											</form>
										  </div>
								 </div>
							</div><!-- modal-content -->
						</div><!-- modal-dialog -->
					</div><!-- modal -->
				  </div>
				</div>
