@extends('layouts.app')
@section('title', 'Ticket List')
@section('content')
    <!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	Ticket List Page
	<small></small>
	</h1>
	<ol class="breadcrumb">
	<li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i> Home</a></li>
	<li class="active">Ticket List Page</li>
	</ol>
</section>
 <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-xs-12">
			<div class="box">		
				@foreach (['danger', 'warning', 'success', 'info'] as $key)
				 @if(Session::has($key))
				 <div class="alert alert-{{ $key }} alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong> {{ Session::get($key) }}</strong>
				 </div>
				 @endif
			   @endforeach
			 <div class="box-header">
              <h3 class="box-title">Ticket List Page</h3>
				<p class="pull-right">
					<a href="{{ url('/ticket_create') }}" class="btn btn-block btn-success">
						Ticket Create
					</a>
                 </p>
              </div>
			  <div class="box-body"> 
				   <div class="accordion-ticketlist" id="accordionticketlist">
						<div class="accordion-group">
							<div class="accordion-heading-ticketlist custom-filter-search">
							<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionticketlist" href="#collapseTicketlist">
							 Custom Filters
							</a>
							</div>
						<div id="collapseTicketlist" class="accordion-body collapse">
							<div class="accordion-inner">
								<div class="row">
									<div class="col-md-12">
												 <div class="form-group timesheet_filter">
													<label>Project Name :</label>
													<input type='text' id="project_name_field"  class='form-control filter' data-column-index='1'>
												  </div>
													<div class="form-group timesheet_filter">
													<label>Ticket Name :</label>
													<input type='text' id="ticket_field" class='form-control filter' data-column-index='2'>
												  </div>
												  <div class="form-group timesheet_filter">
													<label>Start Date :</label>
													<div class="input-group date">
													<div class="input-group-addon">
													<i class="fa fa-calendar"></i>
													</div>
													<input type="text" name="min"  class="form-control" id="min" placeholder="Start Date" required>
													</div>
												  </div>
												   <div class="form-group timesheet_filter">
													<label>End Date :</label>
													<div class="input-group date">
													<div class="input-group-addon">
													<i class="fa fa-calendar"></i>
													</div>
													<input type="text" name="max"  class="form-control" id="max" placeholder="End Date" required>
													</div>
												  </div>
												  @if(!empty(Session::get('userdetails.role')=='1') || !empty(Session::get('userdetails.role')=='2'))
												  <div class="form-group timesheet_filter">
													<label>Employee :</label>
													<input type='text' id="employee_field" class='form-control filter' data-column-index='8'>
												  </div>
												  @endif
												  <div style="clear:both"></div>
												  <button id="reset_btn_id_ticket" class="pull-left">Reset Filter</button>
												  <br/>
												  <br/>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
		      <div class="box-body table-responsive">
              <table class="table table-bordered table-striped" id="ticket_datatable">
				  <thead>
					<tr>
					  <th>Sno</th>
					  <th>Project Name</th>
					  <th>Ticket Name</th>
					  <th>Description</th>
					  <th>Created Date</th>
					  <th>Created By</th>
					  <th>Manager</th>
					  <th>Requested By</th>
					  @if(!empty(Session::get('userdetails.role')=='1') || !empty(Session::get('userdetails.role')=='2'))
					  <th>Assigned To</th>
					  @endif
					  <th>Status</th>
					  <th>Action</th>
					</tr>
                </thead>
                <tbody>
					<?php if(!empty($ticket_listdata)){
						foreach($ticket_listdata as $index=>$list){ ?>
							<?php $id=$list['id'];?>
							<?php $user_role = Session::get('userdetails.role');?>
						<tr>
						  <td><?php echo $index+1;?></td>
						  <?php if(!empty($list['project'])){?>
						   <td><a href="<?php echo "/project_details/".$list['project']['id'];?>"><?php echo $list['project']['Name'];?></a></td>
						   <?php }else{?>
						   <td>NA</td>
						   <?php }?>
						  <?php if($user_role!='1'){?>
						  <td><a href="<?php echo "/ticketdetails/".$id;?>"><?php echo $list['Title'];?></a></td>
						  <?php }else{?>
							   <td><?php echo $list['Title'];?></td>
						  <?php }?>
						  <td><?php echo $list['description'];?></td>
						  <td><?php echo date('d/m/Y', strtotime($list['createdDate']));?></td>
						  <td><?php echo $list['createdbyUser']['name'];?></td>
						  <td><?php if(!empty($list['reportingUser']['profileId'])){ echo HelperController::getProjectManagerName($list['reportingUser']['profileId']);}?></td>
						  <td><?php echo $list['superVisorUser']['name'];?></td>
						  @if(!empty(Session::get('userdetails.role')=='1') || !empty(Session::get('userdetails.role')=='2'))
						  <td><?php if(!empty($list['Task']['assignedTo']['0']['profileId'])){
							   $profileinfo=HelperController::getProfileInfo($list['Task']['assignedTo']['0']['profileId']); 		   
							   echo $profileinfo['name'];
							   }?></td>
						  @endif
						  <td><?php if(!empty($list['state'])){ ?>
							 <span class="col-md-2 badge label_<?php echo HelperController::getticketStatus($list['state'])?>">  
							  <?php echo HelperController::getticketStatus($list['state']);}?>
							  </span>
						  </td>
						  <td><span class="edit" data-toggle="modal" title="edit" data-target="<?php echo "#updateticketModal".$list['id'];?>"><i class="fa fa-fw fa-edit"></i></span>
						</tr>
						<!-- Timeentry Update Modal Include start -->
							@include('ticket.update_ticket_modal')
						<!-- Timeentry Updae Modal Include end -->
						<?php }
						}?>
				  </tbody>				 
				</table>  
      </div>
          <!-- /.box -->
                     <script>
	var $=jQuery;
  $(function () {
     /* Custom filtering function which will search data in column four between two values */
        $(document).ready(function () { 
						
				/* Ticket List Custom Filter */
			var dtable_tickets = $('#ticket_datatable').DataTable({
				  'paging'      : true,
				  'lengthChange': true,
				  'searching'   : true,
				  'ordering'    : true,
				  'info'        : true,
				  'autoWidth'   : true,
				  'pageLength': '100',
				  'iDisplayLength': '100',
				  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]],      
				  "dom": 'lBfrtip',
				  "buttons": [
						{
							extend: 'collection',
							className: 'ticketlist',
							text: 'Export',
							buttons: [
								{ extend: 'excelHtml5',exportOptions: { columns: [0,1,2,3,4,5,6,7] }, footer: true },
								{ extend: 'csvHtml5', exportOptions: { columns: [0,1,2,3,4,5,6,7] }, footer: true },
								{ extend: 'pdfHtml5', exportOptions: { columns: [0,1,2,3,4,5,6,7] }, footer: true }
							]
						}
					],
					"drawCallback": function( settings ) {
						var table = this.api();
						if (table.page.info().recordsTotal < 1 ) {
						 $('button.dt-button').css( 'display', 'none' );
						}
					}
				});  
			/** Accordion Action **/
					$(document).on('show','.accordion-ticketlist', function (e) {
						 $(e.target).prev('.accordion-heading-ticketlist').addClass('accordion-opened-ticketlist');
					});
					
					$(document).on('hide','.accordion-ticketlist', function (e) {
						$(this).find('.accordion-heading-ticketlist').not($(e.target)).removeClass('accordion-opened-ticketlist');
					});
			/** Date wise Search filter **/
            $.fn.dataTable.ext.search.push(
                function (settings, data, dataIndex) {
                    var min = $('#min').datepicker("getDate");
                    var max = $('#max').datepicker("getDate");
                    // need to change str order before making  date obect since it uses a new Date("mm/dd/yyyy") format for short date.
                    var d = data[4].split("/");
                    var startDate = new Date(d[1]+ "/" +  d[0] +"/" + d[2]);
                    if (min == null && max == null) { return true; }
                    if (min == null && startDate <= max) { return true;}
                    if(max == null && startDate >= min) {return true;}
                    if (startDate <= max && startDate >= min) { return true; }
                    return false;
                }
            );
            $("#min").datepicker({ onSelect: function () { table.draw(); }, changeMonth: true, changeYear: true , dateFormat:"dd/mm/yy"});
            $("#max").datepicker({ onSelect: function () { table.draw(); }, changeMonth: true, changeYear: true, dateFormat:"dd/mm/yy" });
            var table = dtable_tickets;

            // Event listener to the two range filtering inputs to redraw on input
            $('#min, #max').change(function () {
                table.draw();
            });
            
            /** Ticket List Custom Filter Start**/
			$('.filter').on('keyup change', function() {
			//clear global search values
			//dtable is object of the #timesheet_submitted_list
			dtable_tickets.search('');
			dtable_tickets.column($(this).data('columnIndex')).search(this.value).draw();
			});
			$(".dataTables_filter input").on('keyup change', function() {
			//clear column search values
			dtable_submitted.columns().search('');
			//clear input values
			$('.filter').val('');
			});
			/** Ticket List Custom Filter End **/
			
			$('#reset_btn_id_ticket').on('click', function(){
				$("#project_name_field").val('');
				$("#ticket_field").val('');
				$("#employee_field").val('');
				$('input[name=min]').val('').datepicker("update");
				$('input[name=max]').val('').datepicker("update");
				dtable_tickets.search( '' ).columns().search( '' ).draw();
			});
        });
     });
     </script>
     </section>
@endsection
