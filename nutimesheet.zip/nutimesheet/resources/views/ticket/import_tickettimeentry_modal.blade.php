<!-- Add Time Entry Modal Code Start-->
			  <div class="modal right fade" id="importtimeentry" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
					<div class="modal-dialog" role="document">
						<div class="modal-content">

							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								<h4 class="modal-title" id="addentryLabel1">Import New Entry</h4>
							</div>
					
				<div class="modal-body">
					<div class="row">
							<!-- left column -->
							<div class="col-md-12">
							  <!-- general form elements -->
							  <div class="box box-primary">
								<div class="box-header with-border">
								  <h3 class="box-title">Import Time Entry</h3>
								</div>
								<!-- /.box-header -->
								<!-- form start -->
								<form role="form" method="POST" action="/importtickettimeentrysubmit" id="importtickettimeentryform" accept-charset="UTF-8" enctype="multipart/form-data">
									 {{ csrf_field() }}
								  <div class="box-body">
									<div class="form-group">
									   <label for="InputTaskname">CSV File<span class="red">*</span></label>
									  <input type="file" name="file" id="file" class="input-large" required>
									</div>	
									<a href="{{asset('download/sample_Timesheetentry.csv')}}" download>Sample Format CSV File</a>
									 <input type="hidden" name="ticket_id" value="{{$ticketdetail_data['id']}}" id="ticket_id"></input>
									 <input type="hidden" name="associate_id" value="{{Session::get('associateuserdetails.result.id')}}" id="associate_id"></input>
									 <input type="hidden" name="loggedin_id" value="{{Session::get('userdetails.id')}}" id="user_id"></input>
								  </div>
								  <!-- /.box-body -->
								  <div class="box-footer">
									<button type="submit" name="action" class="btn btn-primary" value="save">Import & Save</button>
									<button type="submit" name="action" class="btn btn-primary" value="save_and_submit">Import & Submit</button>
									<button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Cancel</button>
								  </div>
								</form>
							  </div>
					 </div>
				</div><!-- modal-content -->
			</div><!-- modal-dialog -->
		</div><!-- modal -->
	  </div>
	</div>
	<!-- Add Time Entry Modal Code End-->
