@extends('layouts.app')
@section('title', 'Ticket Details')
@section('content')
    <!-- Content Header (Page header) -->
       <section class="content-header">
      <h1>
        Ticket Details Page
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Ticket Details Page</li>
      </ol>
    </section>
     <section class="content">
      <!-- title row -->
         <div class="row">
        <!-- left column -->
			@foreach (['danger', 'warning', 'success', 'info'] as $key)
			 @if(Session::has($key))
			  <div class="alert alert-{{ $key }} alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				<strong>{{ Session::get($key) }}</strong>
				</div>
				@endif
			 @endforeach
         <section class="invoice">
      <!-- title row -->
      @if(!empty($ticketdetail_data))
      <div class="row">
          <h2 class="page-header">
            <i class="fa fa-tasks"></i> &nbsp;{{$ticketdetail_data['Title']}}
             <div class="pull-right">
			@if(!empty(Session::get('userdetails.role')=='3'))
				 <!--<div class="btn-group">
					<button type="button" class="btn btn-success" data-toggle="modal" data-target="#addnewentry">
									Add Time Entry
					</button>
				</div>-->
			 @endif	
                </div>
                <br><br>
          </h2>
      </div>
      <!-- info row -->
      <div class="row invoice-info">
        <div class="col-sm-9 invoice-col">
		  <strong>Ticket Name : {{$ticketdetail_data['Title']}}</strong>	<br> 			
          <strong>Ticket Description : </strong><br> 
				{{$ticketdetail_data['description']}}<br>
        </div>
        <!-- /.col -->
        
        <!-- /.col -->
        <div class="col-sm-3 invoice-col">
		   <address class="task-date-section">
			   
           <b>Created Date :</b><input type="hidden" id="ticket_createddate" value="{{$ticketdetail_data['createdDate']}}"/>  {{ date('d-m-Y', strtotime($ticketdetail_data['createdDate']))}}<br>
           <strong>Supervisor :</strong> <span>{{$ticketdetail_data['superVisorUser']['name']}}</span><br>
		 <strong>Manager :</strong> <span><?php if(!empty($ticketdetail_data['reportingUser']['profileId'])){ echo HelperController::getProjectManagerName($ticketdetail_data['reportingUser']['profileId']);} ?></span>	<br>
		 <strong>Created By :</strong> <span>{{$ticketdetail_data['createdbyUser']['name']}}</span>	<br>
          </address>
        </div>
        <!-- /.col -->
      </div>
            <!-- Table row -->
	
       @if(!empty(Session::get('userdetails.role')=='3')) 
       <div class="row table-responsive">
       	<div class="card">
			<ul class="nav nav-tabs" role="tablist">
				<li role="presentation" class="active"><a href="#timesheetsavedlist" aria-controls="timesheetsavedlist" role="tab" data-toggle="tab">Timesheet Saved List</a></li>
				<li role="presentation"><a href="#timesheetsubmittedlist" aria-controls="timesheetsubmittedlist" role="tab" data-toggle="tab">Timesheet Submitted List</a></li>
			</ul>

			<!-- Tab panes -->
			<div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="timesheetsavedlist">
				<div class="box-header add-timesheet-header">
                 <div class="pull-right">
							 <div class="btn-group">
								<button type="button" class="btn btn-success" data-toggle="modal" data-target="#importtimeentry">
									Import Time Entry
								</button>
							 </div>
							 <div class="btn-group">
								<button type="button" class="btn btn-success" data-toggle="modal" data-target="#addnewentry">
									Add Time Entry
								</button>
							 </div>
				 </div>
            </div>
            
          <table class="table table-bordered" id="timeentry_datatable">
            <thead>
            <tr>
              <th>Sno</th>
              <th>Project Name</th>
              <th>Ticket Name</th>
              <th>Date</th>
              <th>Duration</th>
			  <th>Comments</th>
			  <th>Action</th>
            </tr>
            </thead>
            <?php if(!empty($savedtimesheet_list) && !empty(Session::get('userdetails.role')=='3')){ 
				$timesheetentry=$savedtimesheet_list;
				$associate_id=Session::get('associateuserdetails.result.id');
				$user_id=Session::get('userdetails.id');
					?>
				<tbody>
				<?php
					$i=0;
					foreach($timesheetentry as $index =>$entry){
						
						if($ticketdetail_data['Task']==$entry['TaskId']['id'] && $entry['isTicket']=='1'){
							$i++;
						?>	
					<tr>
					  <td><?php echo $i;?></td>
					  <td><a href="<?php echo "/project_details/".$entry['ProjectId']['id'];?>"><?php echo $entry['ProjectId']['Name'];?></a></td>
					  <td><?php echo $entry['ticket']['Title'];?></td>
					  <td><?php echo date('m-d-Y', strtotime($entry['DateAndTime']));?></td>	
					  <td><?php echo $entry['hours'];?></td>
					  <td><?php echo $entry['comments'];?></td>
					   <td> <span class="edit" data-toggle="modal" title="edit" data-target="<?php echo "#updatetimeentrymodal".$entry['id'];?>"><i class="fa fa-fw fa-edit"></i></span>&nbsp;&nbsp;&nbsp;
						<a href="<?php echo "/ticketremovetimesheet/".$entry['id'].'/'.$associate_id.'/'.$user_id.'/'.$ticketdetail_data['id'];?>" title="delete" class="delete" Onclick="return ConfirmDelete();"><i class="fa fa-fw fa-trash"></i></a>&nbsp;&nbsp;&nbsp;
						<a href="<?php echo "/ticketsubmittimesheet/".$entry['id'].'/'.$user_id.'/'.$ticketdetail_data['id'];?>" title="timesheetsubmit" class="timesheetsubmit" Onclick="return ConfirmSubmit();"><i class="fa fa-fw fa-mail-forward"></i></a>
						</td>
					</tr>
					<!-- Timeentry Update Modal Include start -->
					@include('ticket.updatetimeentry_modal')
					<!-- Timeentry Updae Modal Include end -->
								<?php } 
				}?>
				</tbody>
            	<?php }?>
          </table>
				
				</div>
				<div role="tabpanel" class="tab-pane" id="timesheetsubmittedlist">
					<br/>
					  <table class="table table-bordered" id="timesubmitted_datatable">
						<thead>
						<tr>
						  <th>Sno</th>
						  <th>Project Name</th>
						  <th>Ticket Name</th>
						  <th>Date</th>
						  <th>Duration</th>
						  <th>Comments</th>
						  <th>Submitted To</th>			  
						</tr>
						</thead>
						<?php if(!empty($submitted_timesheet_list)){ 
							$submittedtimesheetentry=$submitted_timesheet_list;
							$associate_id=Session::get('associateuserdetails.result.id');
							$user_id=Session::get('userdetails.id');
								?>
							<tbody>
							<?php
								$i=0;
								foreach($submittedtimesheetentry as $index =>$entry){
								if($ticketdetail_data['Task']==$entry['TaskId']['id'] && $entry['isTicket']=='1' && $entry['isSubmitted']=='1' && $entry['isApproved']!='1' && $entry['isRejected']!='1'){
										$i++;
									?>	
								<tr>
								  <td><?php echo $i;?></td>
								  <td><a href="<?php echo "/project_details/".$entry['ProjectId']['id'];?>"><?php echo $entry['ProjectId']['Name'];?></a></td>
								  <td><?php echo $entry['ticket']['Title'];?></td>
								  <td><?php echo date('m-d-Y', strtotime($entry['DateAndTime']));?></td>	
								  <td><?php echo $entry['hours'];?></td>
								  <td><?php echo $entry['comments'];?></td>
								  <td><?php echo TaskManageController::getAssignName($entry['approvelManager']['profileId']) ?></td>		
								</tr>
								<?php }
								} ?>
							 </tbody>
							 <?php }?>
							 </table>				
				</div>
			</div>
		</div>
	   </div>
		@endif
		<!--  Project Management Submitted list -->
		@if(!empty(Session::get('userdetails.role')=='2')) 
		<div class="row table-responsive">
		<div class="box-header">
              <h3 class="box-title">Timesheet Submitted Details</h3>
            </div>
          <table class="table table-bordered" id="timesubmitted_datatable_manager">
            <thead>
            <tr>
              <th>Sno</th>
              <th>Project Name</th>
              <th>Ticket Name</th>
              <th>Date</th>
              <th>Duration</th>
			  <th>Comments</th>
			  @if(!empty(Session::get('userdetails.role')=='2')) 
			  <th>Submitted By</th>
			  <th>Action</th>
			  @endif
			  @if(!empty(Session::get('userdetails.role')=='3')) 
			  <th>Submitted To</th>
			  @endif
			  
            </tr>
            </thead>
            <?php if(!empty($submitted_timesheet_list)){ 
				$submittedtimesheetentry=$submitted_timesheet_list;
				$associate_id=Session::get('associateuserdetails.result.id');
				$user_id=Session::get('userdetails.id');
					?>
				<tbody>
				<?php
					$i=0;
					foreach($submittedtimesheetentry as $index =>$entry){
					if($ticketdetail_data['Task']==$entry['TaskId']['id'] && $entry['isTicket']=='1' && $entry['isSubmitted']=='1' && $entry['isApproved']!='1' && $entry['isRejected']!='1'){
							$i++;
						?>	
					<tr>
					  <td><?php echo $i;?></td>
					  <td><a href="<?php echo "/project_details/".$entry['ProjectId']['id'];?>"><?php echo $entry['ProjectId']['Name'];?></a></td>
					  <td><?php echo $entry['ticket']['Title'];?></td>
					  <td><?php echo date('m-d-Y', strtotime($entry['DateAndTime']));?></td>	
					  <td><?php echo $entry['hours'];?></td>
					  <td><?php echo $entry['comments'];?></td>
					  @if(!empty(Session::get('userdetails.role')=='2')) 
					  <td><?php echo TaskManageController::getAssignName($entry['associateId']['profileId']) ?></td>
					  @endif
					  @if(!empty(Session::get('userdetails.role')=='3')) 
					  <td><?php echo TaskManageController::getAssignName($entry['approvelManager']['profileId']) ?></td>
					  @endif
					   @if(!empty(Session::get('userdetails.role')=='2')) 
					  <td> 
						<span class="edit" data-toggle="modal" title="edit" data-target="<?php echo "#approve_rejecttimeentrymodal".$entry['id'];?>"><i class="fa fa-fw fa-edit"></i></span>&nbsp;&nbsp;&nbsp;
					  </td>
					@endif
					</tr>
					 <!-- Timeentry Submitted list Approved & Reject Modal Include start -->
						@include('ticket.approvedreject_timeentry_modal')
					 <!-- Timeentry Submitted list Approved & Reject Modal Include end -->
					<?php }
					} ?>
				 </tbody>
				 <?php }?>
				 </table>
				 </div>
		@endif
		@else
		   	<span class="red">Currently don't have Ticket details.</span>
		@endif
      </div>
		 <!-- Timeentry Create Modal Include start -->
					@include('ticket.addtimeentry_modal')
	  <!-- Timeentry Create Modal Include end -->
        <!-- Import Timeentry Modal Include start -->
					@include('ticket.import_tickettimeentry_modal')
	  <!-- Import Timeentry Modal Include end -->
    </section>
    </div>
@endsection
