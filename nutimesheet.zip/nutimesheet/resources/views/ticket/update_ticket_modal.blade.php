<div class="modal right fade" id="<?php echo "updateticketModal".$list['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<h4 class="modal-title" id="updateticketLabel">Edit Ticket</h4>
									</div>
									<div class="modal-body">
										<div class="row">
												<!-- left column -->
												<div class="col-md-12">
												  <!-- general form elements -->
												  <div class="box box-primary" id="projecttoassociate">
													<div class="box-header with-border">
													  <h3 class="box-title">Update Ticket Details</h3>
													</div>
													<!-- /.box-header -->
													<!-- form start -->
													<form role="form" method="POST" action="/updateticketdetails">
														 {{ csrf_field() }}
													   <div class="box-body">
														 <input type="hidden" name="loggedInUserId" value="{{Session::get('userdetails.id')}}" id="loggedin_id"></input>
														 <input type="hidden" name="ticketid" value="<?php echo $list['id'];?>" id="ticket_id"></input>
														  <div class="form-group">
															  <label for="ticket_name">Ticket Name<span class="red">*</span></label>
															  <input type="text" name="ticket_name" class="form-control" id="ticket_name" value="<?php echo $list['Title'];?>" placeholder="Enter ticket name" required>
															</div>
															<div class="form-group">
															  <label>Description<span class="red">*</span></label>
															  <textarea class="form-control" name="ticket_desc" required><?php echo $list['description'];?></textarea>
															</div>
															<!-- Add Select Field for Status -->
															<?php if(!empty($list['state'])){ echo HelperController::getEditTicketstatus($list['state']);}?>
															<!-- Add Select Field for Status -->
													  </div>
													  <!-- /.box-body -->
												
													<div class="box-footer">
														<button type="submit" class="btn btn-primary">Update</button>
													  </div>
													</form>
												  </div>
												</div>
											</div><!-- modal-content -->
										</div><!-- modal-dialog -->
									</div><!-- modal -->
									</div>
							</div>
