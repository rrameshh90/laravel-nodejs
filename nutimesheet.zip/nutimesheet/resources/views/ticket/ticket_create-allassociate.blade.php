@extends('layouts.app')
@section('title', 'Ticket Create')
@section('content')
    <!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	Ticket Create Page
	<small></small>
	</h1>
	<ol class="breadcrumb">
	<li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i> Home</a></li>
	<li class="active">Ticket Create Page</li>
	</ol>
</section>
 <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
			@foreach (['danger', 'warning', 'success', 'info'] as $key)
				 @if(Session::has($key))
				 <div class="alert alert-{{ $key }} alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong> {{ Session::get($key) }}</strong>
				</div>
				@endif
			 @endforeach
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Ticket Creation Form</h3>
               <p class="pull-right">
					<a href="{{ url('/ticket_list') }}" class="btn btn-block btn-success">
						Ticket List
					</a>
                 </p>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
             <form role="form"  method="POST" action="/ticketcreatesubmit">
                        {{ csrf_field() }}
              <div class="box-body">
                <div class="form-group">
                  <label for="ticketname">Ticket Name<span class="red">*</span></label>
                  <input type="text" name="ticket_name"  class="form-control" id="ticket_name" placeholder="Ticket Name" required>
                </div>
                 <div class="form-group">
                  <label for="description">Ticket Description<span class="red">*</span></label>
                  <textarea type="text" name="ticket_desc"  class="form-control" id="ticket_desc" placeholder="Ticket Description" required></textarea>
                </div>
               @if(!empty(Session::get('userdetails.role')=='1'))
                <input type="hidden" name="management_id"  class="form-control" id="management_id" placeholder="Management Name" value="<?php echo Session::get('user_id')?>">
               @else
                <div class="form-group">
                  <label>Select Management User<span class="red">*</span></label>
                  <select class="form-control" name="management_id" required>
					  <?php if(!empty($management_user)){?>
						<option value="">Please select Management User</option>
						 <?php foreach($management_user as $management){?>
						<option value="<?php echo $management['id'];?>"><?php echo $management['name'];?></option>
						<?php }
						}else{?>
						  <option value="">No Management User</option>
						<?php }?>
                  </select>
                </div>
                @endif
				<div class="form-group">
                  <label>Select Project<span class="red">*</span></label>
                  <select class="form-control" name="project_id" id="project_id" required>
					  <?php if(!empty($project_list)){?>
						<option value="">Please select Project</option>
						 <?php foreach($project_list as $project){?>
						<option value="<?php echo $project['id'];?>"><?php echo $project['Name'];?></option>
						<?php }
						}else{?>
						  <option value="">No Project</option>
					   <?php  }?>
                  </select>
                </div>
                
                @if(!empty(Session::get('userdetails.role')=='3'))
                <input type="hidden" name="associateId[]"  class="form-control" id="associateId" placeholder="Associate Name" value="<?php echo Session::get('user_id')?>">
                @else
				<div class="form-group">
				  <label for="SelectAssignuser">Select Associate User<span class="red">* <!--(Based On Project Selection Users Will Display)--></span></label>
				  <select multiple class="form-control"  name="associateId[]" id="associate_option" required>
					  <?php if(!empty($associate_list)){?>
						 <?php foreach($associate_list as $associate){?>
						<option value="<?php echo $associate['id'];?>"><?php echo $associate['name'];?></option>
						<?php }
						}else{?>
						  <option>No Associate User</option>
					   <?php }?>
				  </select>
				</div>
				@endif
				<!--<div class="form-group">
                    <div class="checkbox">
                      <label>
                        <input type="checkbox" name="is_ticket" required><span class="red">*</span> Is Ticket 
                      </label>
                    </div>
                </div>-->
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Create Ticket</button>
              </div>
            </form>
          </div>
      </div>
      </div>
      </div>
     </section>
@endsection
