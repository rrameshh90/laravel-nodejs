@section('title', 'Login')
@include('layouts.partials.header')
<div class="login-box">
  <div class="login-logo">
    <img src="{{asset('images/nu-logo.png')}}"></img>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
		@foreach (['danger', 'warning', 'success', 'info'] as $key)
		@if(Session::has($key))
		  <div class="alert alert-{{ $key }} alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong>{{ Session::get($key) }}</strong>
		  </div>
		@endif
		@endforeach
    <p class="login-box-msg">Sign in to start your session</p>
    <div class="social-auth-links text-center">
      <a href="{{ url('/login/google') }}" class="btn btn-block btn-social btn-google btn-flat"><i class="fa fa-google-plus"></i> Sign in using
        Google+</a>
    </div>
    <!-- /.social-auth-links -->

  </div>
  <!-- /.login-box-body -->
</div>
@include('layouts.partials.scripts')
</body>
<footer class="main-footer login-footer">
    <!-- Default to the left -->
    <strong>Copyright © 2018 <a href="http://www.nutechnologyinc.com/">NU Technologyinc</a>.</strong> All rights reserved.
</footer>
</html>
