@extends('layouts.app')
@section('title', 'Task List')
@section('content')
    <!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	Task List Page
	<small></small>
	</h1>
	<ol class="breadcrumb">
	<li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i> Home</a></li>
	<li class="active">Task List Page</li>
	</ol>
</section>
 <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-xs-12">
			<div class="box">		
				@foreach (['danger', 'warning', 'success', 'info'] as $key)
				 @if(Session::has($key))
				 <div class="alert alert-{{ $key }} alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong> {{ Session::get($key) }}</strong>
				 </div>
				 @endif
			   @endforeach
			 <div class="box-header">
              <h3 class="box-title">Task List Page</h3>
              </div>
			  <div class="box-body"> 
		      <div class="box-body table-responsive">
              <table class="table table-bordered table-striped" id="project_datatable">
				  <thead>
					<tr>
					  <th>Sno</th>
					  <th>Name</th>
					  <th>Start Date</th>
					  <th>End Date</th>
					  <th>Status</th>
					</tr>
                </thead>
                <tbody>
					<?php $dashboard_associateproject=Session::get('associateuserdetails');?>
					<?php if(!empty($dashboard_associateproject['result'])){
						foreach($dashboard_associateproject['result']['tasks'] as $index=>$list){ ?>
							<?php $id=$list['id'];?>
						<tr>
						  <td><?php echo $index+1;?></td>
						  <td><a href="<?php echo "/taskdetails/".$id;?>"><?php echo $list['name'];?></a></td>
						  <td><?php echo date('d-m-Y', strtotime($list['startDate']));?></td>
						  <td><?php echo date('d-m-Y', strtotime($list['endDate']));?></td>
						  <td><?php if(!empty($list['state'])){ ?>
							 <span class="col-md-2 badge label_<?php echo HelperController::gettaskStatus($list['state'])?>">  
							  <?php echo HelperController::gettaskStatus($list['state']);}?>
							  </span>
							</td>
						</tr>
						<?php }
						}else{?>
						<tr>
							<td colspan="5"><center><span class="red">No Task found</span></center></td>
						</tr>
						<?php }?>
				  </tbody>				 
				</table>  
      </div>
          <!-- /.box -->
     </section>
@endsection
