@include('layouts.partials.header')
@include('layouts.partials.topbar')
<div class="clearfix"></div>
<div class="page-container">
<div class="wrapper">
 <!-- Sidebar -->
	@include('layouts.partials.sidebar')

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
		@yield('content')
  </div>
  <!-- /.content-wrapper -->


</div>
<!-- ./wrapper -->
</div>
<!-- Scripts links -->
@include('layouts.partials.scripts')
<!-- Footer -->
@include('layouts.partials.footer')

