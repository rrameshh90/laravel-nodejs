<!-- Left side column. contains the sidebar -->
@if(!empty(Session::get('gmaildetails') && Session::get('userdetails'))) 
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
       <div class="user-panel">
        <div class="pull-left image">
         <img src="{!! Session::get('gmaildetails.avatar_original') !!}" class="img-circle" alt="User Image" />
        </div>
        <div class="pull-left info">
         <p>{!! Session::get('gmaildetails.name') !!}</p>
         <a href="{{ url('/userprofile') }}" title="Profile Page"><i class="fa fa-circle text-success"></i>Online</a>
        </div>
      </div>
      <!-- search form 
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
       /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i><span>Dashboard</span></a></li>
        @if(!empty(Session::get('userdetails.role')=='1'))
	    <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i> <span>Employee</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="{{ url('/user_list') }}"><i class="fa fa-user"></i><span>User List</span></a></li>
            <li><a href="{{ url('/create_user') }}"><i class="fa fa-user-plus"></i>Add User</a></li>
          </ul>
        </li>
		<!--<li><a href="{{ url('/user_onboard_list') }}"><i class="fa fa-tasks"></i><span>OnBoard Employee</span></a></li>
		<li><a href="{{ url('/user_offboard_list') }}"><i class="fa fa-tasks"></i><span>OffBoard Employee</span></a></li>-->
		@endif
		@if(!empty(Session::get('userdetails.role')=='2') || !empty(Session::get('userdetails.role')=='1') || !empty(Session::get('userdetails.role')=='3'))
		  <li class="treeview">
          <a href="#">
			@if(!empty(Session::get('userdetails.role')=='3'))
            <i class="fa fa-th-large"></i> <span>My Project</span>
            @else
            <i class="fa fa-th-large"></i> <span>Project</span>
            @endif
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="{{ url('/project_list') }}"><i class="fa fa-circle-o"></i><span>Project List</span></a></li>
            @if(!empty(Session::get('userdetails.role')=='2'))
            <li><a href="{{ url('/create_project') }}"><i class="fa fa-circle-o"></i>Add Project</a></li>
            @endif
          </ul>
        </li>
        @endif
        @if(!empty(Session::get('userdetails.role')=='3'))
		<li><a href="{{ url('/mytasklist') }}"><i class="fa fa-tasks"></i><span>My Task</span></a></li>
		@endif
		@if(!empty(Session::get('userdetails.role')=='3'))
		<li class="treeview">
          <a href="#">
            <i class="ion ion-clipboard"></i> <span>My Timesheet</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="{{ url('/timesheet') }}"><i class="ion ion-clipboard"></i><span>My Saved Timesheet</span></a></li>
            <li><a href="{{ url('/submittedtimesheetlist') }}"><i class="ion ion-clipboard"></i><span>My Submitted Timesheet</span></a></li>
			<li><a href="{{ url('/approvedtimesheetlist') }}"><i class="ion ion-clipboard"></i><span>My Approved Timesheet</span></a></li>
			<li><a href="{{ url('/rejectedtimesheetlist') }}"><i class="ion ion-clipboard"></i><span>My Rejected Timesheet</span></a></li>
          </ul>
        </li>
		@endif
		@if(!empty(Session::get('userdetails.role')=='1') || !empty(Session::get('userdetails.role')=='2'))
		<li class="treeview">
          <a href="#">
             <i class="ion ion-clipboard"></i> <span>Timesheet</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
			<li><a href="{{ url('/timesheetassociate') }}"><i class="ion ion-clipboard"></i><span>Userwise Timesheet</span></a></li>
			<!--@if(!empty(Session::get('userdetails.role')=='1'))
			<li><a href="{{ url('/allprojectlisttimesheet') }}"><i class="ion ion-clipboard"></i><span>Projectwise Timesheet</span></a></li>
			@endif-->
			@if(!empty(Session::get('userdetails.role')=='2'))
			<li><a href="{{ url('/submittedtimesheetlist') }}"><i class="ion ion-clipboard"></i><span>Submitted Timesheet</span></a></li>
			@endif
          </ul>
        </li>
		@endif
		
		<li class="treeview">
          <a href="#">
			@if(!empty(Session::get('userdetails.role')=='3'))
            <i class="fa fa-ticket"></i> <span>My Ticket</span>
            @else
            <i class="fa fa-ticket"></i> <span>Ticket</span>
            @endif
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="{{ url('/ticket_create') }}"><i class="fa fa-ticket"></i><span>Create Ticket</span></a></li>
            @if(!empty(Session::get('userdetails.role')=='3'))
            <li><a href="{{ url('/ticket_list') }}"><i class="fa fa-ticket"></i><span>My Ticket list</span></a></li>
            @else
            <li><a href="{{ url('/ticket_list') }}"><i class="fa fa-ticket"></i><span>Ticket list</span></a></li>
            @endif
          </ul>
        </li>
		<li><a href="{{ url('/logout') }}"><i class="fa fa-sign-out"></i><span>Logout</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
@endif
