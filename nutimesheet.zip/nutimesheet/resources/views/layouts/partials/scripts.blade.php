<!-- jQuery 3 -->
<!--<script src="{{asset('Admin/bower_components/jquery/dist/jquery.min.js')}}"></script>-->
<!-- jQuery UI 1.11.4 -->
<!--<script src="{{asset('Admin/bower_components/jquery-ui/jquery-ui.min.js')}}"></script>-->
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="{{asset('Admin/bower_components/bootstrap/dist/js/bootstrap.min.js')}}"></script>
<!-- Morris.js charts -->
<script src="{{asset('Admin/bower_components/raphael/raphael.min.js')}}"></script>
<script src="{{asset('Admin/bower_components/morris.js/morris.min.js')}}"></script>
<!-- Sparkline -->
<script src="{{asset('Admin/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js')}}"></script>
<!-- jvectormap -->
<script src="{{asset('Admin/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js')}}"></script>
<script src="{{asset('Admin/plugins/jvectormap/jquery-jvectormap-world-mill-en.js')}}"></script>
<!-- jQuery Knob Chart -->
<script src="{{asset('Admin/bower_components/jquery-knob/dist/jquery.knob.min.js')}}"></script>
<!-- daterangepicker -->
<script src="{{asset('Admin/bower_components/moment/min/moment.min.js')}}"></script>
<script src="{{asset('Admin/bower_components/bootstrap-daterangepicker/daterangepicker.js')}}"></script>
<!-- datepicker -->
<script src="{{asset('Admin/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')}}"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="{{asset('Admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')}}"></script>
<!-- DataTables -->
<script src="{{asset('Admin/bower_components/datatables.net/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('Admin/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')}}"></script>
<script src="{{asset('Admin/bower_components/datatables.net-bs/js/dataTables.buttons.min.js')}}"></script>
<script src="{{asset('Admin/bower_components/datatables.net-bs/js/pdfmake.min.js')}}"></script>
<script src="{{asset('Admin/bower_components/datatables.net-bs/js/buttons.html5.min.js')}}"></script>
<script src="{{asset('Admin/bower_components/datatables.net-bs/js/jszip.min.js')}}"></script>
<script src="{{asset('Admin/bower_components/datatables.net-bs/js/vfs_fonts.js')}}"></script>
<!-- Slimscroll -->
<script src="{{asset('Admin/bower_components/jquery-slimscroll/jquery.slimscroll.min.js')}}"></script>
<!-- FastClick -->
<script src="{{asset('Admin/bower_components/fastclick/lib/fastclick.js')}}"></script>
<!-- AdminLTE App -->
<script src="{{asset('Admin/dist/js/adminlte.min.js')}}"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="{{asset('Admin/dist/js/pages/dashboard.js')}}"></script>
<!-- AdminLTE for demo purposes -->
<!--<script src="{{asset('Admin/dist/js/demo.js')}}"></script>
<script src="{{asset('Admin/bower_components/moment/moment.js')}}"></script>
<script src="{{asset('Admin/bower_components/fullcalendar/dist/fullcalendar.min.js')}}"></script>-->
<script>
	var $=jQuery;
  $(function () {
    $('#user_datatable').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
	  'autoWidth'   : false,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]]
    });
    $('#project_datatable').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
	  'autoWidth'   : false,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]]
    });
     $('#task_datatable').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
	  'autoWidth'   : false,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]]
    });
     $('#projectuser_datatable').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
	  'autoWidth'   : false,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]]
    });
	 $('#timeentry_datatable').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
	  'autoWidth'   : false,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]]
    });
    $('#timesubmitted_datatable').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
	  'autoWidth'   : false,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]]
    });
     $('#timesubmitted_datatable_manager').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
	  'autoWidth'   : false,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]]
    });
     $('#timeapproved_datatable').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
	  'autoWidth'   : false,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]]
    });
     $('#timerejected_datatable').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
	  'autoWidth'   : false,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]]
    });
    $('#timesheet_saved_list').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
	  'autoWidth'   : false,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]]
    });
    $('#ticket_timesheet_saved_list').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
	  'autoWidth'   : false,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]]
    });
  
    $('#todaytask_datatable').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false,
      'pageLength': '100',
      'iDisplayLength': '100',
      'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]]
    });
    
       //Date picker
    var dateToday = new Date();
	dateToday.setDate(dateToday.getDate());
    $('#pro_startdate').datepicker({
      autoclose: true,
      startDate: dateToday
    });
	//$("#pro_startdate").datepicker("setDate",currentDate);
    $('#pro_enddate').datepicker({
      autoclose: true,
      startDate: dateToday
    });
    /** Based Project Start date and End date Display date on Task Creation Code **/
    var projectstartdate =$("#project_startdate").val();
    var projectenddate=$("#project_enddate").val();
	$('#InputTaskstartdate').datepicker(
		"setStartDate",new Date(projectstartdate)
    );
    $('#InputTaskstartdate').datepicker(
		"setEndDate",new Date(projectenddate)
    );
	$('#InputTaskenddate').datepicker(
		"setStartDate",new Date(projectstartdate)
    );
    $('#InputTaskenddate').datepicker(
		"setEndDate",new Date(projectenddate)
    );
	
	$(document).ready(function(){

    $("#InputTaskstartdate").datepicker({
        autoclose: true,
    }).on('changeDate', function (selected) {
        var minDate = new Date(selected.date.valueOf());
        $('#InputTaskenddate').datepicker('setStartDate', minDate);
    });

    $("#InputTaskenddate").datepicker()
        .on('changeDate', function (selected) {
            var maxDate = new Date(selected.date.valueOf());
            $('#InputTaskstartdate').datepicker('setEndDate', maxDate);
        });

	});
	/** Based Project Start date and End date Display date on Task Creation Code **/

    /** Based Task Start date and End date Display date on Timesheet Creation Code **/
	$('#Inputtimeentrydate').datepicker({
	 autoclose: true
	});
    var taskstartdate =$("#task_startdate").val();
    var taskenddate=$("#task_enddate").val();
	$('#Inputtimeentrydate').datepicker(
		"setStartDate",new Date(taskstartdate)
    );
    $('#Inputtimeentrydate').datepicker(
		"setEndDate",new Date(taskenddate)
    );
	/** Based Task Start date and End date Display date on Timesheet Creation Code **/
   
   /** Based Ticket Created date and End date Display date on Timesheet Creation Code **/
   
	$('#Inputtickettimeentrydate').datepicker({
	 autoclose: true
	});
    var ticketcreateddate =$("#ticket_createddate").val();
	$('#Inputtickettimeentrydate').datepicker(
		"setStartDate",new Date(ticketcreateddate)
    );
	$('#Inputtickettimeentrydate').datepicker(
		"setEndDate",new Date(dateToday)
    );
   
	/** Based Ticket Created date and End date Display date on Timesheet Creation Code **/

  var user_role ="<?php echo Session::get('userdetails.role');?>";
	if(user_role=='3'){
		   var dtable_submitted = $('#timesheet_submitted_list').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : true,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]],
      "dom": 'lBfrtip',
      "buttons": [
            {
                extend: 'collection',
                className: 'submitted',
                text: 'Export',
                buttons: [
					{ extend: 'excelHtml5',exportOptions: { columns: [0,1,2,3,4,5,6,7] }, footer: true },
					{ extend: 'csvHtml5', exportOptions: { columns: [0,1,2,3,4,5,6,7] }, footer: true },
					{ extend: 'pdfHtml5', exportOptions: { columns: [0,1,2,3,4,5,6,7] }, footer: true }
                ]
            }
        ],
        "footerCallback": function (nRow,row, data, start, end, display ) {
            var api = this.api(), data;
		
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
                .column( 4 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 ); 
            // Total over this page
            pageTotal = api
                .column( 4, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            // Update footer
            $($(nRow).children().get(data-1)).html('<div class="totalhrs"><span class="pagetotal">Total: '+pageTotal +' Hrs</span></div>');
        },
		"drawCallback": function( settings ) {
			var table = this.api();
			if (table.page.info().recordsTotal < 1 ) {
			 $('button.dt-button').css( 'display', 'none' );
			}
		}
    });   
	}else{
		  var dtable_submitted = $('#timesheet_submitted_list').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : true,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]],
      "dom": 'lBfrtip',
      "buttons": [
            {
                extend: 'collection',
                className: 'submitted',
                text: 'Export',
                buttons: [
					{ extend: 'excelHtml5',exportOptions: { columns: [0,1,2,3,4,5,6,8] }, footer: true },
					{ extend: 'csvHtml5', exportOptions: { columns: [0,1,2,3,4,5,6,8] }, footer: true },
					{ extend: 'pdfHtml5', exportOptions: { columns: [0,1,2,3,4,5,6,8] }, footer: true }
                ]
            }
        ],
        "footerCallback": function (nRow,row, data, start, end, display ) {
            var api = this.api(), data;
		
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
                .column( 4 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 ); 
            // Total over this page
            pageTotal = api
                .column( 4, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            // Update footer
            $($(nRow).children().get(data-1)).html('<div class="totalhrs"><span class="pagetotal">Total: '+pageTotal +' Hrs</span></div>');
        },
		"drawCallback": function( settings ) {
			var table = this.api();
			if (table.page.info().recordsTotal < 1 ) {
			 $('button.dt-button').css( 'display', 'none' );
			}
		}
    });  
	}
 
    /* Approved Timesheet Custom Filter */
     var dtable_approved = $('#timesheet_approved_list').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : true,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]],      
      "dom": 'lBfrtip',
      "buttons": [
            {
                extend: 'collection',
                className: 'approved',
                text: 'Export',
                buttons: [
					{ extend: 'excelHtml5',exportOptions: { columns: [0,1,2,3,4,5,6,7] }, footer: true },
					{ extend: 'csvHtml5', exportOptions: { columns: [0,1,2,3,4,5,6,7] }, footer: true },
					{ extend: 'pdfHtml5', exportOptions: { columns: [0,1,2,3,4,5,6,7] }, footer: true }
                ]
            }
        ],
        "footerCallback": function (nRow,row, data, start, end, display ) {
            var api = this.api(), data;
		
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
                .column( 4 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 ); 
            // Total over this page
            pageTotal = api
                .column( 4, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            // Update footer
            $($(nRow).children().get(data-1)).html('<div class="totalhrs"><span class="pagetotal">Total: '+pageTotal +' Hrs</span></div>');
        },
		"drawCallback": function( settings ) {
			var table = this.api();
			if (table.page.info().recordsTotal < 1 ) {
			 $('button.dt-button').css( 'display', 'none' );
			}
		}
    });  
    /* Rejected Timesheet Custom Filter */
    var user_role ="<?php echo Session::get('userdetails.role');?>";
	if(user_role=='3'){
     var dtable_rejected = $('#timesheet_rejected_list').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : true,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]],
      "dom": 'lBfrtip',
      "buttons": [
            {
                extend: 'collection',
                className: 'rejected',
                text: 'Export',
                buttons: [
					{ extend: 'excelHtml5',exportOptions: { columns: [0,1,2,3,4,5,6,7,8,10] }, footer: true },
					{ extend: 'csvHtml5', exportOptions: { columns: [0,1,2,3,4,5,6,7,8,10] }, footer: true },
					{ extend: 'pdfHtml5', exportOptions: { columns: [0,1,2,3,4,5,6,7,8,10] }, footer: true }
                ]
            }
        ],
        "footerCallback": function (nRow,row, data, start, end, display ) {
            var api = this.api(), data;
		
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
                .column( 4 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 ); 
            // Total over this page
            pageTotal = api
                .column( 4, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            // Update footer
            $($(nRow).children().get(data-1)).html('<div class="totalhrs"><span class="pagetotal">Total: '+pageTotal +' Hrs</span></div>');
        },
		"drawCallback": function( settings ) {
			var table = this.api();
			if (table.page.info().recordsTotal < 1 ) {
			 $('button.dt-button').css( 'display', 'none' );
			}
		}
	});  
	}else{
	     var dtable_rejected = $('#timesheet_rejected_list').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : true,
	  'pageLength': '100',
	  'iDisplayLength': '100',
	  'lengthMenu': [[10, 25, 50, 100,-1], [10, 25, 50,100,"All"]],
      "dom": 'lBfrtip',
      "buttons": [
            {
                extend: 'collection',
                className: 'rejected',
                text: 'Export',
                buttons: [
					{ extend: 'excelHtml5',exportOptions: { columns: [0,1,2,3,4,5,6,7,8,9] }, footer: true },
					{ extend: 'csvHtml5', exportOptions: { columns: [0,1,2,3,4,5,6,7,8,9] }, footer: true },
					{ extend: 'pdfHtml5', exportOptions: { columns: [0,1,2,3,4,5,6,7,8,9] }, footer: true }
                ]
            }
        ],
        "footerCallback": function (nRow,row, data, start, end, display ) {
            var api = this.api(), data;
		
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
                .column( 4 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 ); 
            // Total over this page
            pageTotal = api
                .column( 4, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            // Update footer
            $($(nRow).children().get(data-1)).html('<div class="totalhrs"><span class="pagetotal">Total: '+pageTotal +' Hrs</span></div>');
        },
		"drawCallback": function( settings ) {
			var table = this.api();
			if (table.page.info().recordsTotal < 1 ) {
			 $('button.dt-button').css( 'display', 'none' );
			}
		}
 }); 	
}
		/* Position for the Export Button */
	$('.dt-buttons.submitted').insertAfter($('#timesheet_submitted_list_length'));
	$('.dt-buttons.approved').insertAfter($('#timesheet_approved_list_length'));
	$('.dt-buttons.rejected').insertAfter($('#timesheet_rejected_list_length'));
			/** Timesheet Submit Custom Filter  Start**/
			$('.filter').on('keyup change', function() {
			//clear global search values
			//dtable is object of the #timesheet_submitted_list
			dtable_submitted.search('');
			dtable_submitted.column($(this).data('columnIndex')).search(this.value).draw();
			});
			$(".dataTables_filter input").on('keyup change', function() {
			//clear column search values
			dtable_submitted.columns().search('');
			//clear input values
			$('.filter').val('');
			});
			/** Timesheet Submit Custom Filter End **/
			/** Timesheet Approved Custom Filter  Start**/
			$('.filter').on('keyup change', function() {
			//clear global search values
			//dtable is object of the #timesheet_approved_list
			dtable_approved.search('');
			dtable_approved.column($(this).data('columnIndex')).search(this.value).draw();
			});
			$(".dataTables_filter input").on('keyup change', function() {
			//clear column search values
			dtable_approved.columns().search('');
			//clear input values
			$('.filter').val('');
			});
			/** Timesheet Approved Custom Filter End **/
			/** Timesheet Rejected Custom Filter  Start**/
			$('.filter').on('keyup change', function() {
			//clear global search values
			//dtable is object of the #timesheet_rejected_list
			dtable_rejected.search('');
			dtable_rejected.column($(this).data('columnIndex')).search(this.value).draw();
			});
			$(".dataTables_filter input").on('keyup change', function() {
			//clear column search values
			dtable_rejected.columns().search('');
			//clear input values
			$('.filter').val('');
			});
			/** Timesheet Rejected Custom Filter End **/
			
			
			
			/** User Wise Timesheet Submitted list filter **/
			$('.submit_filter').on('keyup change', function() {
			//clear global search values
			//dtable is object of the #timesheet_submitted_list
			dtable_submitted.search('');
			dtable_submitted.column($(this).data('columnIndex')).search(this.value).draw();
			});
			$(".dataTables_filter input").on('keyup change', function() {
			//clear column search values
			dtable_submitted.columns().search('');
			//clear input values
			$('.submit_filter').val('');
			});
			/** User Wise Timesheet Submitted list filter **/
			
			
			/** User Wise Timesheet Approved list filter Start **/
			$('.approved_filter').on('keyup change', function() {
			//clear global search values
			//dtable is object of the #timesheet_approved_list
			dtable_approved.search('');
			dtable_approved.column($(this).data('columnIndex')).search(this.value).draw();
			});
			$(".dataTables_filter input").on('keyup change', function() {
			//clear column search values
			dtable_approved.columns().search('');
			//clear input values
			$('.approved_filter').val('');
			});
			/** User Wise Timesheet Approved list filter End **/
			
			/** User Wise Timesheet Rejected list filter Start **/
			$('.rejected_filter').on('keyup change', function() {
			//clear global search values
			//dtable is object of the #timesheet_approved_list
			dtable_rejected.search('');
			dtable_rejected.column($(this).data('columnIndex')).search(this.value).draw();
			});
			$(".dataTables_filter input").on('keyup change', function() {
			//clear column search values
			dtable_rejected.columns().search('');
			//clear input values
			$('.rejected_filter').val('');
			});
			/** User Wise Timesheet Rejected list filter End **/
	
    $(document).on('show','.accordion-submitted', function (e) {
         $(e.target).prev('.accordion-heading-submitted').addClass('accordion-opened-submitted');
    });
    
    $(document).on('hide','.accordion-submitted', function (e) {
        $(this).find('.accordion-heading-submitted').not($(e.target)).removeClass('accordion-opened-submitted');
    });
    /** Timesheet Approved Custom Filter **/
    $(document).on('show','.accordion-approved', function (e) {
         $(e.target).prev('.accordion-heading-approved').addClass('accordion-opened-approved');
    });
    
    $(document).on('hide','.accordion-approved', function (e) {
        $(this).find('.accordion-heading-approved').not($(e.target)).removeClass('accordion-opened-approved');
    });
    /** Timesheet Rejected Custom Filter **/
    $(document).on('show','.accordion-rejected', function (e) {
         $(e.target).prev('.accordion-heading-rejected').addClass('accordion-opened-rejected');
    });
    
    $(document).on('hide','.accordion-rejected', function (e) {
        $(this).find('.accordion-heading-rejected').not($(e.target)).removeClass('accordion-opened-rejected');
    });
    /** User list Custom filter **/
      $(document).on('show','.accordion-userlist', function (e) {
         $(e.target).prev('.accordion-heading-userlist').addClass('accordion-opened-userlist');
    });
    
    $(document).on('hide','.accordion-userlist', function (e) {
        $(this).find('.accordion-heading-userlist').not($(e.target)).removeClass('accordion-opened-userlist');
    });
    		
			/** Reset Filter Button **/
			
			$('#reset_btn_id').on('click', function(){
				<!-- Submitted Table -->
				dtable_submitted.search( '' ).columns().search( '' ).draw();
				$('input[name=optionsSubmitted]').prop('checked', false);
				<!-- Approved Table -->
				dtable_approved.search( '' ).columns().search( '' ).draw();
				$('input[name=optionsApproved]').prop('checked', false);
				<!-- Rejected Table -->
				dtable_rejected.search( '' ).columns().search( '' ).draw();
				$('input[name=optionsRejected]').prop('checked', false);
				$("#project_name_field").val('');
				$("#ticket_task_field").val('');
				$("#employee_field").val('');
				$('input[name=min]').val('').datepicker("update");
				$('input[name=max]').val('').datepicker("update");
			});
			$('#reset_btn_id_submitted').on('click', function(){
				$("#project_name_field").val('');
				$("#ticket_task_field").val('');
				$("#employee_field").val('');
				$('input[name=min]').val('').datepicker("update");
				$('input[name=max]').val('').datepicker("update");
				dtable_submitted.search( '' ).columns().search( '' ).draw();
				$('input[name=optionsuserSubmitted]').prop('checked', false);
			});
			$('#reset_btn_id_approved').on('click', function(){
				$("#project_name_field_app").val('');
				$("#ticket_task_field_app").val('');
				$("#employee_field").val('');
				$('input[name=min]').val('').datepicker("update");
				$('input[name=max]').val('').datepicker("update");
				dtable_approved.search( '' ).columns().search( '' ).draw();
				$('input[name=optionsuserApproved]').prop('checked', false);
			});
			$('#reset_btn_id_rejected').on('click', function(){
				$("#project_name_field_rej").val('');
				$("#ticket_task_field_rej").val('');
				$("#employee_field").val('');
				$('input[name=min]').val('').datepicker("update");
				$('input[name=max]').val('').datepicker("update");
				dtable_rejected.search( '' ).columns().search( '' ).draw();
				$('input[name=optionsuserRejected]').prop('checked', false);
			});
  });
</script>
 <script>
    function ConfirmDelete()
    {
      var x = confirm("Are you sure you want to delete?");
      if (x){
          return true;
     }else{
        return false;
	}
    }
    function ConfirmSubmit()
    {
      var x = confirm("Are you sure you want to Submit Timesheet?");
      if (x){
          return true;
     }else{
        return false;
	}
    }
     /** Time Entry Validation **/
       <!--
       function isNumberKey(evt)
       {
          var charCode = (evt.which) ? evt.which : event.keyCode
          if (charCode != 46 && charCode > 31 
            && (charCode < 48 || charCode > 57))
             return false;

          return true;
       }
       //-->
</script>
