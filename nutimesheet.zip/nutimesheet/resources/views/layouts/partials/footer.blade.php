</body>
<footer class="main-footer">
    <!-- Default to the left -->
    <strong>Copyright © 2018 <a href="http://www.nutechnologyinc.com/">NU Technologyinc</a>.</strong> All rights reserved.
</footer>
</html>
