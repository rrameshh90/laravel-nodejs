@extends('layouts.app')
@section('title', 'Timesheet Rejected List')
@section('content')
    <!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	Timesheet Rejected List Page
	<small></small>
	</h1>
	<ol class="breadcrumb">
	<li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i> Home</a></li>
	<li class="active">Timesheet Rejected Page</li>
	</ol>
</section>
 <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-xs-12">
			<div class="box">		
				@foreach (['danger', 'warning', 'success', 'info'] as $key)
				 @if(Session::has($key))
				 <div class="alert alert-{{ $key }} alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong> {{ Session::get($key) }}</strong>
				 </div>
				 @endif
			   @endforeach
				<!-- Timesheet List for Rejected detaills -->
			  <div class="box-header">
			<h3 class="box-title">Timesheet Rejected List</h3>
			</div>
			 <div class="box-body"> 
				 <div class="accordion-rejected" id="accordionrejected">
						<div class="accordion-group">
							<div class="accordion-heading-rejected custom-filter-search">
							<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionrejected" href="#collapseRejected">
							 Custom Filters
							</a>
							</div>
						<div id="collapseRejected" class="accordion-body collapse">
							<div class="accordion-inner">
								<div class="row">
									<div class="col-md-12">
												 <div class="form-group timesheet_filter">
													<label>Project Name :</label>
													<input type='text' id="project_name_field"  class='form-control filter' data-column-index='1'>
												  </div>
													<div class="form-group timesheet_filter">
													<label>Task / Ticket Name :</label>
													<input type='text' id="ticket_task_field" class='form-control filter' data-column-index='2'>
												  </div>
												  <div class="form-group timesheet_filter">
													<label>Start Date :</label>
													<div class="input-group date">
													<div class="input-group-addon">
													<i class="fa fa-calendar"></i>
													</div>
													<input type="text" name="min"  class="form-control" id="min" placeholder="Start Date" required>
													</div>
												  </div>
												   <div class="form-group timesheet_filter">
													<label>End Date :</label>
													<div class="input-group date">
													<div class="input-group-addon">
													<i class="fa fa-calendar"></i>
													</div>
													<input type="text" name="max"  class="form-control" id="max" placeholder="End Date" required>
													</div>
												  </div>
												  <div class="form-group timesheet_filter">
													<label>Employee :</label>
													<input type='text' id="employee_field" class='form-control filter' data-column-index='6'>
												  </div>
												  <div class="form-group timesheet_filter">
													  <b>Filter By Task / Ticket</b>
														  <div class="radio">
															<label>
															  <input type="radio" class='filter' name="optionsRejected" id="optionsRejected1" value="Task" data-column-index='10'>
															  Task &nbsp;&nbsp;
															</label>
															<label>
															  <input type="radio" class='filter' name="optionsRejected" id="optionsRejected2" value="Ticket" data-column-index='10'>
															   Ticket
															</label>
														  </div>
												  </div>
												  <button id="reset_btn_id" class="pull-right">Reset Filter</button>
												  <br/>
												  <br/>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="box-body table-responsive">
					  <table class="table table-bordered table-striped" id="timesheet_rejected_list">
						  <thead>
						   <tr>
								<th>Sno</th>
								<th>Project Name</th>
								<th>Task /Ticket Name</th>
								<th>Date</th>
								<th>Hours</th>
								<th>Task Comments</th>
								<th>Rejected Comments</th>
								<th>Rejected Date</th>
								<th>Rejected By</th>
						        <th>Action</th>
						        <th>Filter</th>
							</tr>
						</thead>
						<tbody>				
							<?php if(!empty($rejectedtimesheet_listdata)){
								$i=0;
								foreach($rejectedtimesheet_listdata as $index=>$list){
										$associate_id=Session::get('associateuserdetails.result.id');
										$user_id=Session::get('userdetails.id');
										$i++;
									?>
								<tr>
								  <td><?php echo $i;?></td>
								  <?php if(!empty($list['submittedTimeSheetId']['ProjectId']) && $list['submittedTimeSheetId']['isTicket']!='1'){?>
								  <td><a href="<?php echo "/project_details/".$list['submittedTimeSheetId']['ProjectId'];?>"><?php echo HelperController::getProjectName($list['submittedTimeSheetId']['ProjectId']) ?></a></td>
								  <?php }elseif(!empty($list['submittedTimeSheetId']['ProjectId']) && $list['submittedTimeSheetId']['isTicket']=='1'){?>
								  <td><a href="<?php echo "/project_details/".$list['submittedTimeSheetId']['ProjectId'];?>"><?php echo HelperController::getProjectName($list['submittedTimeSheetId']['ProjectId']) ?></a></td>
								  <?php }else{?>
								  <td> NA</td>
								  <?php }?>
								 <?php if(!empty($list['submittedTimeSheetId']['TaskId']) && $list['submittedTimeSheetId']['isTicket']!='1'){?>
								  <td><a href="<?php echo "/taskdetails/".$list['submittedTimeSheetId']['TaskId'];?>"><?php echo HelperController::getTaskName($list['submittedTimeSheetId']['TaskId']) ?></a></td>
								 <?php }else{?>
									 <td><a href="<?php echo "/ticketdetails/".$list['submittedTimeSheetId']['ticket'];?>"><?php echo HelperController::getTicketName($list['submittedTimeSheetId']['ticket']) ?></a></td>
								 <?php }?>
								  <td><?php echo date('d/m/Y', strtotime($list['submittedTimeSheetId']['DateAndTime']));?></td>	
								  <td><?php echo $list['submittedTimeSheetId']['hours'];?></td>
								  <td><?php echo $list['submittedTimeSheetId']['comments'];?></td>
								  <td><?php echo $list['commentsBymanager'];?></td>
								  <td><?php echo date('d/m/Y', strtotime($list['rejectedDate']));?></td>
								  <td><?php echo TaskManageController::getAssignName($list['rejectedBy']['profileId']) ?></td>
								  <td> 
										<span class="edit" data-toggle="modal" title="edit" data-target="<?php echo "#task_resubmissiontimeentrymodal".$list['id'];?>"><i class="fa fa-fw fa-edit"></i></span>&nbsp;&nbsp;&nbsp;
										<a href="<?php echo "/removetaskrejectedtimesheet/".$list['submittedTimeSheetId']['id'].'/'.$associate_id.'/'.$user_id;?>" title="delete" class="delete" Onclick="return ConfirmDelete();"><i class="fa fa-fw fa-trash"></i></a>
								  </td>
								  <?php if($list['submittedTimeSheetId']['isTicket']!='1'){?>
								  <td><span class="task_name_label">Task</span></td>
								  <?php }else{?>
								  <td><span class="ticket_name_label">Ticket</span></td>
								  <?php }?>
								</tr>
								<!-- Timeentry Resubmission Modal Include start -->
								@include('timesheet.taskresubmissiontimeentry_modal')
								<!-- Timeentry Resubmission Modal Include end -->
								<?php }
									}?>
						  </tbody>
						   <tfoot>
									<tr>
											<th></th>
											<th></th>
											<th></th>
											<th></th>
											<th></th>
											<th></th>
											<th></th>
											<th></th>
											<th></th>
											<th colspan="2"></th>
										</tr>
									</tfoot>				 
							</table>  
					  </div>
					</div>							
			</div>  
		</div>
	</div> 
          <!-- /.box -->
           <script>
	var $=jQuery;
  $(function () {
     /* Custom filtering function which will search data in column four between two values */
        $(document).ready(function () { 
        
            $.fn.dataTable.ext.search.push(
                function (settings, data, dataIndex) {
                    var min = $('#min').datepicker("getDate");
                    var max = $('#max').datepicker("getDate");
                    // need to change str order before making  date obect since it uses a new Date("mm/dd/yyyy") format for short date.
                    var d = data[3].split("/");
                    var startDate = new Date(d[1]+ "/" +  d[0] +"/" + d[2]);

                    if (min == null && max == null) { return true; }
                    if (min == null && startDate <= max) { return true;}
                    if(max == null && startDate >= min) {return true;}
                    if (startDate <= max && startDate >= min) { return true; }
                    return false;
                }
            );
            $("#min").datepicker({ onSelect: function () { table.draw(); }, changeMonth: true, changeYear: true , dateFormat:"dd/mm/yy"});
            $("#max").datepicker({ onSelect: function () { table.draw(); }, changeMonth: true, changeYear: true, dateFormat:"dd/mm/yy" });
            var table = $('#timesheet_rejected_list').DataTable();

            // Event listener to the two range filtering inputs to redraw on input
            $('#min, #max').change(function () {
                table.draw();
            });
        });
     });
     </script>
     </section>
@endsection
