@extends('layouts.app')
@section('title', 'Timesheet Submitted List')
@section('content')
    <!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	Timesheet Submitted List Page
	<small></small>
	</h1>
	<ol class="breadcrumb">
	<li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i> Home</a></li>
	<li class="active">Timesheet List Page</li>
	</ol>
</section>
 <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-xs-12">
			<div class="box">		
				@foreach (['danger', 'warning', 'success', 'info'] as $key)
				 @if(Session::has($key))
				 <div class="alert alert-{{ $key }} alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong> {{ Session::get($key) }}</strong>
				 </div>
				 @endif
			   @endforeach
			  <div class="box-header">
              <h3 class="box-title">Timesheet Submitted List</h3>
              </div>
			<!-- Box Body -->
			<div class="box-body"> 
			<div class="box-body table-responsive">
				<div class="accordion" id="accordionsubmitted">
						<div class="accordion-group">
							<div class="accordion-heading-submitted custom-filter-search">
							<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordionsubmitted" href="#collapseOne">
							 Custom Filters
							</a>
							</div>
						<div id="collapseOne" class="accordion-body collapse">
							<div class="accordion-inner">
								<div class="row">
									<div class="col-md-12">
												 <div class="form-group timesheet_filter">
													<label>Project Name :</label>
													<input type='text' id="project_name_field" class='form-control filter' data-column-index='1'>
												  </div>
													<div class="form-group timesheet_filter">
													<label>Task / Ticket Name :</label>
													<input type='text' id="ticket_task_field" class='form-control filter' data-column-index='2'>
												  </div>
												  <div class="form-group timesheet_filter">
													<label>Start Date :</label>
													<div class="input-group date">
													<div class="input-group-addon">
													<i class="fa fa-calendar"></i>
													</div>
													<input type="text" name="min"  class="form-control" id="min" placeholder="Start Date" required>
													</div>
												  </div>
												   <div class="form-group timesheet_filter">
													<label>End Date :</label>
													<div class="input-group date">
													<div class="input-group-addon">
													<i class="fa fa-calendar"></i>
													</div>
													<input type="text" name="max"  class="form-control" id="max" placeholder="End Date" required>
													</div>
												  </div>
												  <div class="form-group timesheet_filter">
													<label>Employee :</label>
													<input type='text' id="employee_field" class='form-control filter' data-column-index='6'>
												  </div>
												  <div class="form-group timesheet_filter">
													  <b>Filter By Task / Ticket</b>
														  <div class="radio">
															<label>
															  <input type="radio" class='filter' name="optionsSubmitted" id="optionsSubmitted1" value="Task" <?php if(!empty(Session::get('userdetails.role')=='2')){ echo "data-column-index='8'"; }else{ echo "data-column-index='7'";}?> >
															  Task &nbsp;&nbsp;
															</label>
															<label>
															  <input type="radio" class='filter' name="optionsSubmitted" id="optionsSubmitted2" value="Ticket" <?php if(!empty(Session::get('userdetails.role')=='2')){ echo "data-column-index='8'";}else{ echo "data-column-index='7'";}?>>
															   Ticket
															</label>
														  </div>
												  </div>
												  <button id="reset_btn_id" class="pull-right">Reset Filter</button>
												  <br/>
												  <br/>
											</div>
										</div>
									</div>
								</div>
							</div>
					</div>
					  <table class="table table-bordered table-striped" id="timesheet_submitted_list">
						  <thead>
							<tr>
								<th>Sno</th>
								<th>Project Name</th>
								<th>Task Name / Ticket Name</th>
								<th>Date</th>
								<th>Hours</th>
								<th>Comments</th>
							@if(!empty(Session::get('userdetails.role')=='2'))
								<th>Submitted By</th>
								<th>Action</th>
								<th>Filter</th>
						    @endif
						    @if(!empty(Session::get('userdetails.role')=='3'))
						       <th>Submitted To</th>
						       <th>Filter</th>
						    @endif
							</tr>
						</thead>
						<tbody>				
							<?php if(!empty($submittedtimesheet_listdata)){
								$i=0;
								foreach($submittedtimesheet_listdata as $index=>$list){
									?>
									<?php $id=$list['id'];
										$associate_id=Session::get('associateuserdetails.result.id'); 
										$user_id=Session::get('userdetails.id'); 
										$i++;?>
								<tr>
								  <td><?php echo $i;?></td>
								  <?php if(!empty($list['ProjectId']['id']) && $list['isTicket']!='1'){?>
								  <td><a href="<?php echo "/project_details/".$list['ProjectId']['id'];?>"><?php echo $list['ProjectId']['Name'];?></a></td>
								  <?php }else if(!empty($list['ProjectId']['id']) && $list['isTicket']=='1'){?>
								  <td><a href="<?php echo "/project_details/".$list['ProjectId']['id'];?>"><?php echo $list['ProjectId']['Name'];?></a></td>
								  <?php }else{?>
								  <td> NA </td>	  
								  <?php }?>
								  <?php if(!empty($list['TaskId']['id']) && $list['isTicket']!='1'){?>
								  <td><a href="<?php echo "/taskdetails/".$list['TaskId']['id'];?>"><?php echo $list['TaskId']['name'];?></a></td>
								  <?php }else{?>
								  <td><a href="<?php echo "/ticketdetails/".$list['ticket']['id'];?>"><?php echo $list['ticket']['Title'];?></a></td>
								  <?php }?>
								  <td><?php echo date('d/m/Y', strtotime($list['DateAndTime']));?></td>	
								  <td><?php echo $list['hours'];?></td>
								  <td><?php echo $list['comments'];?></td>
								  @if(!empty(Session::get('userdetails.role')=='2'))
									<td><?php echo TaskManageController::getAssignName($list['associateId']['profileId']) ?></td>
									 <td> 
										<span class="edit" data-toggle="modal" title="edit" data-target="<?php echo "#approve_rejecttimeentrymodal".$list['id'];?>"><i class="fa fa-fw fa-edit"></i></span>&nbsp;&nbsp;&nbsp;
									 </td>
								 @endif
								 @if(!empty(Session::get('userdetails.role')=='3'))
									  <td><?php echo TaskManageController::getAssignName($list['approvelManager']['profileId']) ?></td>
								 @endif
								  <?php if($list['isTicket']!='1'){?>
								  <td><span class="task_name_label">Task</span></td>
								  <?php }else{?>
								  <td><span class="ticket_name_label">Ticket</span></td>
								  <?php }?>
								 
								</tr>
							<!-- Model Start -->
							<div class="modal right fade" id="<?php echo "approve_rejecttimeentrymodal".$list['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<h4 class="modal-title" id="addentryLabel1">Approved & Reject Form</h4>
									</div>
									<div class="modal-body">
										<div class="row">
												<!-- left column -->
												<div class="col-md-12">
												  <!-- general form elements -->
												  <div class="box box-primary">
													<div class="box-header with-border">
													  <h3 class="box-title">Approved & Reject Timesheet</h3>
													</div>
													<!-- /.box-header -->
													<!-- form start -->
													<form role="form" method="POST" action="/approvedandrejecttimesheet" id="approveandrejectform">
														 {{ csrf_field() }}
													  <div class="box-body">
														  <input type="hidden" name="loggedin_id" value="{{Session::get('userdetails.id')}}" id="user_id"></input>
														  <input type="hidden" name="entry_id" value="{{$list['id']}}" id="entry_id"></input>
														  <input type="hidden" name="task_id" value="{{$list['TaskId']['id']}}" id="task_id"></input>
														<div class="form-group">
														   <label for="Inputcomment">Task Comments<span class="red">*</span></label>
														  <textarea type="text" name="comments" class="form-control" id="Inputcomment"  placeholder="Task Comments" required disabled>{{$list['comments']}}</textarea>
														</div>	
														<div class="form-group">
														   <label for="Inputhours">Duration<span class="red">*</span></label>
														  <input type="text" name="hours" class="form-control" value="{{$list['hours']}}" id="Inputhours" placeholder="Task Duration" required disabled>
														</div>	
														<div class="form-group">
														    <label for="approve" id="approvedlabel">Reason for Rejection(Optional)</label>
															<label for="reasonreject" id="rejectedlabel">Reason for Rejection<span class="red">*</span></label>
														  <textarea type="text" name="reason_of_reject" class="form-control reason_comment" id="Inputcomment"  placeholder="Reason for Rejection"></textarea>
														</div>
														 <input type="hidden" name="associate_id" value="{{Session::get('associateuserdetails.result.id')}}" id="associate_id"></input>
													  </div>
													  <!-- /.box-body -->
													  <div class="box-footer">
														<button type="submit" name="action" class="btn btn-primary"  id="approvedbutton" value="timesheet_approved">Approved</button>
														<button type="submit" name="action" class="btn btn-primary" id="rejectedbutton" value="timesheet_rejected">Reject</button>
														<button type="button" class="btn btn-primary" id="button_dismiss" data-dismiss="modal" aria-label="Close">Cancel</button>
													  </div>
													</form>
												  </div>
												 </div>
											</div><!-- modal-content -->
										</div><!-- modal-dialog -->
									</div><!-- modal -->
								  </div>
								  <script>
								var $=jQuery;
							  $(function () {
								  $(document).ready(function(){
								  	$("#rejectedlabel").hide();
								  $( "#rejectedbutton" ).click(function() {
									  $("textarea.reason_comment").prop('required',true);
									  $("#rejectedlabel").show();
									  $("#approvedlabel").hide();
								  });
								  $( "#approvedbutton" ).click(function() {
									  $("textarea.reason_comment").prop('required',false);
									  $("#approvedlabel").show();
									  $("#rejectedlabel").hide();
								  });
									});
								});
								</script>
								</div>
								<!-- Model End -->
								<?php }
								}?>
						  </tbody>	
						         <tfoot>
									<tr>
										<th></th>
										<th></th>
										<th></th>
										<th></th>
										<th></th>
										<th></th>
										@if(!empty(Session::get('userdetails.role')=='2'))
										<th></th>
										@endif
										<th colspan="2"></th>
									</tr>
								</tfoot>	 
						</table>  
				  </div>
			 </div>
			<!-- Box Body -->
			</div>  
		</div>
	</div> 
          <!-- /.box -->
     </section>
     <script>
	var $=jQuery;
  $(function () {
     /* Custom filtering function which will search data in column four between two values */
        $(document).ready(function () { 
        
            $.fn.dataTable.ext.search.push(
                function (settings, data, dataIndex) {
                    var min = $('#min').datepicker("getDate");
                    var max = $('#max').datepicker("getDate");
                    // need to change str order before making  date obect since it uses a new Date("mm/dd/yyyy") format for short date.
                    var d = data[3].split("/");
                    var startDate = new Date(d[1]+ "/" +  d[0] +"/" + d[2]);

                    if (min == null && max == null) { return true; }
                    if (min == null && startDate <= max) { return true;}
                    if(max == null && startDate >= min) {return true;}
                    if (startDate <= max && startDate >= min) { return true; }
                    return false;
                }
            );
            $("#min").datepicker({ onSelect: function () { table.draw(); }, changeMonth: true, changeYear: true , dateFormat:"dd/mm/yy"});
            $("#max").datepicker({ onSelect: function () { table.draw(); }, changeMonth: true, changeYear: true, dateFormat:"dd/mm/yy" });
            var table = $('#timesheet_submitted_list').DataTable();

            // Event listener to the two range filtering inputs to redraw on input
            $('#min, #max').change(function () {
                table.draw();
            });
        });
        
     });
     </script>
@endsection
