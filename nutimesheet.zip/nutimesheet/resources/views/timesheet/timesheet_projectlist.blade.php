@extends('layouts.app')
@section('title', 'All Project List')
@section('content')
    <!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	Project Wise List Page
	<small></small>
	</h1>
	<ol class="breadcrumb">
	<li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i> Home</a></li>
	<li class="active">Project Wise List Page</li>
	</ol>
</section>
 <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-xs-12">
			<div class="box">		
				@foreach (['danger', 'warning', 'success', 'info'] as $key)
				 @if(Session::has($key))
				 <div class="alert alert-{{ $key }} alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong> {{ Session::get($key) }}</strong>
				 </div>
				 @endif
			   @endforeach
			 <div class="box-header">
              <h3 class="box-title">Project Wise List Page</h3>
              </div>
			  <div class="box-body"> 
		      <div class="box-body table-responsive">
              <table class="table table-bordered table-striped" id="project_datatable">
				  <thead>
					<tr>
					  <th>ID</th>
					  <th>Name</th>
					  <th>Start Date</th>
					  <th>End Date</th>
					  <th class="desc">Description</th>
					  <th>Status</th>
					</tr>
                </thead>
                <tbody>
					  <?php if(!empty($timesheetprojectlist)){
						foreach($timesheetprojectlist as $index=>$list){ ?>
							<?php $id=$list['id'];?>
						<tr>
						  <td><?php echo $index+1;?></td>
						  <td><a href="<?php echo "/project_details/".$id;?>"><?php echo $list['Name'];?></a></td>
						  <td><?php echo date('m-d-Y', strtotime($list['startDate']));?></td>
						  <td><?php echo date('m-d-Y', strtotime($list['endDate']));?></td>
						  <td><?php echo $list['desc'];?></td>
						  <td><?php if(!empty($list['state'])){?>
							  <?php $todaydate=date("m-d-Y");?>
							  <?php if(date('m-d-Y', strtotime($list['startDate'])) <= $todaydate){
										if($list['state']=='1'){
										$list['state']='2';?>
										<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php $loggedInUserId=Session::get('user_id'); 
												  $projectid=$list['id'];
												  $project_name=$list['Name'];
												  $project_desc=$list['desc'];
												  $project_status=$list['state'];
											if(!empty($loggedInUserId) && !empty($projectid) && !empty($project_name) && !empty($project_desc) && !empty($project_status)){	  
										      $statusid=HelperController::UpdateProjectStatus($loggedInUserId,$projectid,$project_name,$project_desc,$project_status);
											  if(!empty($statusid['state'])){
												  $list['state']=$statusid['state'];
											  }
											}?>
											<?php echo HelperController::getprojectStatus($list['state']);?>
											</span>
											<?php }else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
												<?php echo HelperController::getprojectStatus($list['state']);?>
											</span>
											<?php }
											}elseif(date('m-d-Y', strtotime($list['endDate'])) == $todaydate){
											if($list['state']!='3' || $list['state']!='4'){
												$list['state']='3';?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php $loggedInUserId=Session::get('user_id'); 
												  $projectid=$list['id'];
												  $project_name=$list['Name'];
												  $project_desc=$list['desc'];
												  $project_status=$list['state'];
													if(!empty($loggedInUserId) && !empty($projectid) && !empty($project_name) && !empty($project_desc) && !empty($project_status)){	  
													 $statusid=HelperController::UpdateProjectStatus($loggedInUserId,$projectid,$project_name,$project_desc,$project_status);
													  if(!empty($statusid['state'])){
														  $list['state']=$statusid['state'];
													  }
													}?>
													<?php echo HelperController::getprojectStatus($list['state']);?>
											</span>
											<?php }else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
												<?php echo HelperController::getprojectStatus($list['state']);?>
										    </span>
											<?php }
											}else{?>
											<span class="col-md-2 badge label_<?php echo HelperController::getprojectStatus($list['state'])?>">
											<?php echo HelperController::getprojectStatus($list['state']);?>
											</span>
											<?php }?>
											<?php }?>
						  </td>
						  <!--<td><span class="edit" data-toggle="modal" data-target="#updateprojectModal"><i class="fa fa-fw fa-edit"></i></span>&nbsp;&nbsp;&nbsp;<span class="delete"><i class="fa fa-fw fa-trash"></i></span></td>-->
						</tr>
						<?php }
						}?>
				  </tbody>				 
				</table>  
      </div>
          <!-- /.box -->
     </section>
@endsection
