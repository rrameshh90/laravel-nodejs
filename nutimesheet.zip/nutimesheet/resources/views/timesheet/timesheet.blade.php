@extends('layouts.app')
@section('title', 'Timesheet List')
@section('content')
    <!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	Timesheet List Page
	<small></small>
	</h1>
	<ol class="breadcrumb">
	<li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i> Home</a></li>
	<li class="active">Timesheet List Page</li>
	</ol>
</section>
 <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-xs-12">
			<div class="box">		
				@foreach (['danger', 'warning', 'success', 'info'] as $key)
				 @if(Session::has($key))
				 <div class="alert alert-{{ $key }} alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong> {{ Session::get($key) }}</strong>
				 </div>
				 @endif
			   @endforeach
			    <div class="box-header">
			<h3 class="box-title">Timesheet Saved List</h3>
			</div>
	      <!-- Box Body -->
			<div class="box-body"> 
			  <div class="box-body table-responsive">	 
			  <table class="table table-bordered table-striped" id="timesheet_saved_list">
						  <thead>
							<tr>
								<th>Sno</th>
								<th>Project Name</th>
								<th>Task / Ticket Name</th>
								<th>Date</th>
								<th>Hours</th>
								<th>Comments</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>		
							<?php if(!empty($associate_savedtimesheet)){
								$i=0;
								foreach($associate_savedtimesheet as $index=>$list){
										$i++;
										?>
									<?php $id=$list['id'];
										$associate_id=Session::get('associateuserdetails.result.id'); 
										$user_id=Session::get('userdetails.id'); ?>
								<tr>
								  <td><?php echo $i;?></td>
								  <?php if(!empty($list['ProjectId']['id']) && $list['isTicket']!='1'){?>
								  <td><a href="<?php echo "/project_details/".$list['ProjectId']['id'];?>"><?php echo $list['ProjectId']['Name'];?></a></td>
								  <?php }else if(!empty($list['ProjectId']['id']) && $list['isTicket']=='1'){?>
								  <td><a href="<?php echo "/project_details/".$list['ProjectId']['id'];?>"><?php echo $list['ProjectId']['Name'];?></a></td>
								  <?php }else{?>
								  <td> NA </td>	  
								  <?php }?>
								  <?php if(!empty($list['TaskId']['id']) && $list['isTicket']!='1'){ ?>
								  <td><a href="<?php echo "/taskdetails/".$list['TaskId']['id'];?>"><?php echo $list['TaskId']['name'];?></a></td>
								  <?php }else{?>
								   <td><a href="<?php echo "/ticketdetails/".$list['ticket']['id'];?>"><?php echo $list['ticket']['Title'];?></a></td>
								  <?php }?>
								  <td><?php echo date('d/m/Y', strtotime($list['DateAndTime']));?></td>	
								  <td><?php echo $list['hours'];?></td>
								  <td><?php echo $list['comments'];?></td>
								  <td> <!--<span class="edit" data-toggle="modal" title="edit" data-target="<?php //echo "#updatetimeentrymodal".$list['id'];?>"><i class="fa fa-fw fa-edit"></i></span>&nbsp;&nbsp;&nbsp;-->
									<a href="<?php echo "/removetimesheet/".$list['id'].'/'.$associate_id.'/'.$user_id.'/'.$list['TaskId']['id'];?>" title="delete" class="delete" Onclick="return ConfirmDelete();"><i class="fa fa-fw fa-trash"></i></a>&nbsp;&nbsp;&nbsp;
									<a href="<?php echo "/submittimesheet/".$list['id'].'/'.$user_id.'/'.$list['TaskId']['id'];?>" title="timesheetsubmit" class="timesheetsubmit" Onclick="return ConfirmSubmit();"><i class="fa fa-fw fa-mail-forward"></i></a>
								  </td>
								</tr>
								<?php }
								}?>
						  </tbody>				 
						</table>  
			 </div>
			</div>
			<!-- Box Body -->
				</div>
				</div>  
			</div>
		</div> 
          <!-- /.box -->
     </section>
@endsection
