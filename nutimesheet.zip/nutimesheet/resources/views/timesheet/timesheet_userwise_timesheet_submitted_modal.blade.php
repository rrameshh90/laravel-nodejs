			<!-- Model Start -->
							<div class="modal right fade" id="<?php echo "approve_rejecttimeentrymodal".$list['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<h4 class="modal-title" id="addentryLabel1">Approved & Reject Form</h4>
									</div>
									<div class="modal-body">
										<div class="row">
												<!-- left column -->
												<div class="col-md-12">
												  <!-- general form elements -->
												  <div class="box box-primary">
													<div class="box-header with-border">
													  <h3 class="box-title">Approved & Reject Timesheet</h3>
													</div>
													<!-- /.box-header -->
													<!-- form start -->
													<form role="form" method="POST" action="/approvedandrejecttimesheet" id="approveandrejectform">
														 {{ csrf_field() }}
													  <div class="box-body">
														  <input type="hidden" name="loggedin_id" value="{{Session::get('userdetails.id')}}" id="user_id"></input>
														  <input type="hidden" name="entry_id" value="{{$list['id']}}" id="entry_id"></input>
														  <input type="hidden" name="task_id" value="{{$list['TaskId']['id']}}" id="task_id"></input>
														<div class="form-group">
														   <label for="Inputcomment">Task Comments<span class="red">*</span></label>
														  <textarea type="text" name="comments" class="form-control" id="Inputcomment"  placeholder="Task Comments" required disabled>{{$list['comments']}}</textarea>
														</div>	
														<div class="form-group">
														   <label for="Inputhours">Duration<span class="red">*</span></label>
														  <input type="text" name="hours" class="form-control" value="{{$list['hours']}}" id="Inputhours" placeholder="Task Duration" required disabled>
														</div>	
														<div class="form-group">
														   <label for="approve" id="approvedlabel">Reason for Rejection(Optional)</label>
														   <label for="reasonreject" id="rejectedlabel">Reason for Rejection<span class="red">*</span></label>
														  <textarea type="text" name="reason_of_reject" class="form-control reason_comment" id="Inputcomment"  placeholder="Reason for Rejection"></textarea>
														</div>
														 <input type="hidden" name="associate_id" value="{{Session::get('associateuserdetails.result.id')}}" id="associate_id"></input>
													  </div>
													  <!-- /.box-body -->
													  <div class="box-footer">
														<button type="submit" name="action" class="btn btn-primary"  id="approvedbutton" value="timesheet_approved">Approved</button>
														<button type="submit" name="action" class="btn btn-primary" id="rejectedbutton" value="timesheet_rejected">Reject</button>
														<button type="button" class="btn btn-primary" id="button_dismiss" data-dismiss="modal" aria-label="Close">Cancel</button>
													  </div>
													</form>
												  </div>
												 </div>
											</div><!-- modal-content -->
										</div><!-- modal-dialog -->
									</div><!-- modal -->
								  </div>
								  <script>
								var $=jQuery;
							  $(function () {
								$(document).ready(function(){
								  $("#rejectedlabel").hide();
								  $( "#rejectedbutton" ).click(function() {
									  $("textarea.reason_comment").prop('required',true);
									  $("#rejectedlabel").show();
									  $("#approvedlabel").hide();
								  });
								  $( "#approvedbutton" ).click(function() {
									  $("textarea.reason_comment").prop('required',false);
									  $("#approvedlabel").show();
									  $("#rejectedlabel").hide();
								  });
								});
							  });
								</script>
								</div>
								<!-- Model End -->
