@extends('layouts.app')
@section('title', 'OnBoard Employee List')
@section('content')
    <!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	Employee List Page
	<small></small>
	</h1>
	<ol class="breadcrumb">
	<li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i> Home</a></li>
	<li class="active">OnBoard Employee List Page</li>
	</ol>
</section>
 <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-xs-12">
			<div class="box">		
				@foreach (['danger', 'warning', 'success', 'info'] as $key)
				 @if(Session::has($key))
				 <div class="alert alert-{{ $key }} alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong> {{ Session::get($key) }}</strong>
				 </div>
				 @endif
			   @endforeach
			 <div class="box-header">
              <h3 class="box-title">OnBoard Empolyee List</h3>
				 <p class="pull-right">
					<!--<button type="button" class="btn btn-success" data-toggle="modal" data-target="#userrestoremodal">
						User Restore
					</button>-->

					<a href="{{ url('/create_user') }}" class="btn btn-success">
						Add Onboard Employee
					</a>
                 </p>
              </div>
     <div class="box-body">      
		<?php if(!empty($user_onboard_listdata)){
			foreach($user_onboard_listdata as $list){ ?>
		<div class="col-md-6">
          <!-- Widget: user widget style 1 -->
          <div class="box box-widget widget-user-2">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <!-- bk color class -- bg-yellow -->
         
            <div class="widget-user-header">
              <div class="widget-user-image">
                <img class="img-circle" src="{{asset('Admin/dist/img/usericon.png')}}" alt="User Avatar">
              </div>
              <!-- /.widget-user-image -->
              <h3 class="widget-user-username"><?php echo $list['name'];?></h3>
              <h5 class="widget-user-email"><?php echo $list['email'];?></h5>
              <h5 class="widget-user-designation"><?php echo $list['designation'];?></h5>
              <div class="pull-right user-action">
               <a href="<?php echo "/userdetails/".$list['id'];?>" title="view user" class="userview"><i class="fa fa-fw fa-eye"></i></a>&nbsp;&nbsp;&nbsp;
			   <span class="edit" data-toggle="modal" title="edit" data-target="<?php echo "#updateuserModal".$list['id'];?>"><i class="fa fa-fw fa-edit"></i></span>&nbsp;&nbsp;&nbsp;
			   <a href="<?php echo "/userdelete/".$list['id'];?>" title="delete" class="delete" Onclick="return ConfirmDelete();"><i class="fa fa-fw fa-trash"></i></a>
			 </div>
            </div>
          </div>
         
          <!-- /.widget-user -->
        </div>
        <div class="modal right fade" id="<?php echo "updateuserModal".$list['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="updateuserLabel">Edit User</h4>
				</div>
				<div class="modal-body">
					<div class="row">
							<!-- left column -->
							<div class="col-md-12">
							  <!-- general form elements -->
							  <div class="box box-primary" id="updateuserdetails">
								<div class="box-header with-border">
								  <h3 class="box-title">Update User Details</h3>
								</div>
								<!-- /.box-header -->
								<!-- form start -->
								<form role="form" method="POST" action="/updateuserdetails">
									 {{ csrf_field() }}
								   <div class="box-body">
									 <input type="hidden" name="loggedInUserId" value="{{Session::get('userdetails.id')}}" id="loggedin_id"></input>
									 <input type="hidden" name="userprofileId" value="<?php echo $list['id'];?>" id="userprofile_id"></input>
									 <div class="form-group">
									  <label for="Inputusername">Name<span class="red">*</span></label>
									  <input type="text" name="employee_name" class="form-control" id="InputUsername" value="<?php echo $list['name'];?>" required>
									</div>
									<div class="form-group">
									  <label for="InputEmailaddress">Email Address<span class="red">*</span></label>
									  <input type="email" name="email_address" class="form-control" id="InputEmailaddress" value="<?php echo $list['email'];?>" required>
									</div>
									<div class="form-group">
									  <label for="InputDesignation">Designation<span class="red">*</span></label>
									  <input type="text" name="employee_designation" class="form-control" id="InputDesignation" value="<?php echo $list['designation'];?>" required>
									</div>
								  </div>
								  <!-- /.box-body -->
							
								<div class="box-footer">
									<button type="submit" class="btn btn-primary">Update</button>
									<button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Cancel</button>
								  </div>
								</form>
							  </div>
							</div>
						</div><!-- modal-content -->
					</div><!-- modal-dialog -->
				</div><!-- modal -->
				</div>
		</div>
        <?php 
        }
        }else{
			echo "<center><span class='red'>No Employee Data Right Now</span></center>";
		
		}?>
      </div>
      <!-- User Restore Modal Code Start -->
              <div class="modal right fade" id="userrestoremodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="restoreuserLabel">Restore User</h4>
				</div>
				<div class="modal-body">
					<div class="row">
							<!-- left column -->
							<div class="col-md-12">
							  <!-- general form elements -->
							  <div class="box box-primary" id="restoreuser">
								<div class="box-header with-border">
								  <h3 class="box-title">Restore Existing User</h3>
								</div>
								<!-- /.box-header -->
								<!-- form start -->
								<form role="form" method="POST" action="/restoreexistinguser">
									 {{ csrf_field() }}
								   <div class="box-body">
									 <input type="hidden" name="loggedInUserId" value="{{Session::get('userdetails.id')}}" id="loggedin_id"></input>
									<div class="form-group">
									  <label for="InputEmailaddress">Email Address<span class="red">*</span></label>
									  <input type="email" name="email_address" class="form-control" id="InputEmailaddress" required>
									</div>
								  </div>
								  <!-- /.box-body -->
							
								<div class="box-footer">
									<button type="submit" class="btn btn-primary">Restore</button>
									<button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Cancel</button>
								  </div>
								</form>
							  </div>
							</div>
						</div><!-- modal-content -->
					</div><!-- modal-dialog -->
				</div><!-- modal -->
				</div>
		</div>
          <!-- /.box -->
           <!-- User Restore Modal Code End -->
     </section>
   
@endsection
