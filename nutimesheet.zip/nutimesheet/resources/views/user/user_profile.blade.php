@extends('layouts.app')
@section('title', 'Profile')
@section('content')
    <!-- Content Header (Page header) -->
 <section class="content-header">
	<h1>
	Profile Page
	<small></small>
	</h1>
	<ol class="breadcrumb">
	<li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i> Home</a></li>
	<li class="active">User Profile</li>
	</ol>
</section>
<section class="content">
	@if(!empty(Session::get('gmaildetails') && Session::get('userdetails'))) 
      <div class="row">
        <div class="col-md-12">
          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="{!! Session::get('gmaildetails.avatar_original') !!}" alt="User profile picture">

              <h3 class="profile-username text-center">{!! Session::get('gmaildetails.name') !!}</h3>

              <p class="text-muted text-center">{!! Session::get('userdetails.designation') !!}</p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Email</b> <span class="pull-right">{!! Session::get('userdetails.email') !!}</span>
                </li>
                <li class="list-group-item">
                  <b>Created Date</b> <span class="pull-right">{{ date('d-m-Y', strtotime(Session::get('userdetails.createdAt')))}}</span>
                </li>
                <li class="list-group-item">
                  <b>Last Updated Date</b> <span class="pull-right">{{ date('d-m-Y', strtotime(Session::get('userdetails.updatedAt')))}}</span>
                </li>
              </ul>
              <!--<center><a href="#" class="btn btn-primary"><b>Update</b></a></center>-->
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
	@endif
    </section>

@endsection
