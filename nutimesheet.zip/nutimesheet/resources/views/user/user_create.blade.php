@extends('layouts.app')
@section('title', 'Empolyee Create')
@section('content')
    <!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	Employee Create Page
	<small></small>
	</h1>
	<ol class="breadcrumb">
	<li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i> Home</a></li>
	<li class="active">Employee Create Page</li>
	</ol>
</section>
 <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
			@foreach (['danger', 'warning', 'success', 'info'] as $key)
				 @if(Session::has($key))
				 <div class="alert alert-{{ $key }} alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong> {{ Session::get($key) }}</strong>
				</div>
				@endif
			 @endforeach
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Employee Creation Form</h3>
               <p class="pull-right">
					<a href="{{ url('/user_list') }}" class="btn btn-block btn-success">
						Employee List
					</a>
                 </p>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
             <form role="form"  method="POST" action="/usersubmit">
                        {{ csrf_field() }}
              <div class="box-body">
                <div class="form-group">
                  <label for="employee_email">Email address<span class="red">*</span></label>
                  <input type="email" name="email" class="form-control" id="employee_email" placeholder="Enter email" required>
                </div>
                <div class="form-group">
                  <label>Role<span class="red">*</span></label>
                  <select class="form-control" name="role" required>
					<option value="" selected >Please select role</option>
                    <option value="1">Management</option>
                    <option value="2">Manager</option>
                    <option value="3">Associate</option>
                  </select>
                </div>
                 <div class="form-group">
                  <label for="employeename">Employee Name<span class="red">*</span></label>
                  <input type="text" name="employee_name"  class="form-control" id="employee_name" placeholder="Employee Name" required>
                </div>
                 <div class="form-group">
                  <label for="designation">Designation<span class="red">*</span></label>
                  <input type="text" name="designation"  class="form-control" id="designation" placeholder="Designation" required>
                </div>
                @if(!empty(Session::get('userdetails.email')))
                  <input type="hidden" name="creator_emailid" class="form-control" id="creator_email_id" value="{{Session::get('userdetails.email')}}" required>
                  <input type="hidden" name="creator_loggedinid" class="form-control" id="creator_loggedinid" value="{{Session::get('userdetails.id')}}" required>
                @else
                 <div class="form-group">
                  <label for="create_email_id">Creator Email ID<span class="red">*</span></label>
                  <input type="email" name="creator_emailid" class="form-control" id="creator_email_id" placeholder="Creator email Id" required>
                </div>
				@endif
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Create Employee</button>
              </div>
            </form>
          </div>
      </div>
      </div>
      </div>
     </section>
@endsection
