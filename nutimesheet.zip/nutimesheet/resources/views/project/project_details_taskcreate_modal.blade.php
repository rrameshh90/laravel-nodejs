	<div class="modal right fade" id="addtaskModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
		<div class="modal-dialog" role="document">
			<div class="modal-content">

				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="addtaskLabel1">Task Creation</h4>
				</div>
		
				<div class="modal-body">
					<div class="row">
							<!-- left column -->
							<div class="col-md-12">
							  <!-- general form elements -->
							  <div class="box box-primary">
								<div class="box-header with-border">
								  <h3 class="box-title">Add New Task</h3>
								</div>
								<!-- /.box-header -->
								<!-- form start -->
								<form role="form" method="POST" action="/addtasksubmit" id="addtaskform">
									 {{ csrf_field() }}
								  <div class="box-body">
									<div class="form-group">
									  <label for="InputTaskname">Task Name<span class="red">*</span></label>
									  <input type="text" name="task_name" class="form-control" id="InputTaskname" placeholder="Task Name" required>
									</div>
									<input type="hidden" name="task_projectid" value="{{$project_data['id']}}" id="task_projectid"></input>
									<?php if(!empty($project_user)){$userlist=$project_user;}
									if(!empty($userlist)){?>
									<div class="form-group">
									  <label for="SelectAssignuser">Select Project User(optional)</label>
									  <select multiple class="form-control"  name="associateId[]">
										<?php foreach($userlist  as $list){?>
										<option value="<?php echo $list['id'].','.$list['profileId']['id'];?>"><?php echo $list['profileId']['name'];?></option>
										<?php }?>
									  </select>
									</div>
									<?php }else{?>
										<div class="form-group">
									  <label for="SelectAssignuser">Select Associate User(optional)</label>
									  <select multiple class="form-control"  name="associateId[]" disabled>
										  <option>No Associate User</option>
									  </select>
									</div>
									<?php }?>
									<div class="form-group">
									  <label for="InputTaskstartdate">Start Date<span class="red">*</span></label>
									   <div class="input-group date">
										  <div class="input-group-addon">
											<i class="fa fa-calendar"></i>
										  </div>
										<input type="text" name="task_startdate" class="form-control" id="InputTaskstartdate" placeholder="Task Start Date" required>
										</div>
									</div>
									 <div class="form-group">
									  <label for="InputTaskenddate">End Date<span class="red">*</span></label>
									   <div class="input-group date">
										  <div class="input-group-addon">
											<i class="fa fa-calendar"></i>
										  </div>
										<input type="text" name="task_enddate" class="form-control" id="InputTaskenddate" placeholder="Task End Date" required>
										</div>
									</div>
									 <input type="hidden" name="loggedin_id" value="{{Session::get('userdetails.id')}}" id="loggedin_id"></input>
								  </div>
								  <!-- /.box-body -->

								  <div class="box-footer">
									<button type="submit" class="btn btn-primary">Submit</button>
									<button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Cancel</button>
									
								  </div>
								</form>
							  </div>
					 </div>
				</div><!-- modal-content -->
			</div><!-- modal-dialog -->
		</div><!-- modal -->
	  </div>
	</div>
