@extends('layouts.app')
@section('title', 'Project Create')
@section('content')
    <!-- Content Header (Page header) -->
     <section class="content-header">
      <h1>
        Project Create Page
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Project Create Page</li>
      </ol>
    </section>
 <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
			@foreach (['danger', 'warning', 'success', 'info'] as $key)
				 @if(Session::has($key))
				<div class="alert alert-{{ $key }} alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<strong> {{ Session::get($key) }}</strong>
				</div>
				@endif
			 @endforeach
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Project Add Form</h3>
              <p class="pull-right">
					<a href="{{ url('/project_list') }}" class="btn btn-block btn-success">
						Project list
					</a>
                </p>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
             <form role="form"  method="POST" action="/projectsubmit">
                        {{ csrf_field() }}
              <div class="box-body">
                <div class="form-group">
                  <label for="project_name">Project Name<span class="red">*</span></label>
                  <input type="text" name="project_name" class="form-control" id="project_name" placeholder="Enter project name" required>
                </div>
                <div class="form-group">
                  <label>Description<span class="red">*</span></label>
                  <textarea class="form-control" name="project_desc" placeholder="Enter project description" required></textarea>
                </div>
                 <div class="form-group">
                  <label for="pro_startdate">Start Date<span class="red">*</span></label>
                   <div class="input-group date">
					  <div class="input-group-addon">
						<i class="fa fa-calendar"></i>
					  </div>
					<input type="text" name="pro_startdate"  class="form-control" id="pro_startdate" placeholder="Start Date" required>
					</div>
                </div>
                 <div class="form-group">
                  <label for="pro_enddate">End Date<span class="red">*</span></label>
                    <div class="input-group date">
					  <div class="input-group-addon">
						<i class="fa fa-calendar"></i>
					  </div>
					<input type="text" name="pro_enddate"  class="form-control" id="pro_enddate" placeholder="End Date" required>
					</div>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Create Project</button>
              </div>
            </form>
          </div>
      </div>
      </div>
      </div>
     </section>
@endsection
