@extends('layouts.app')
@section('title', 'Project Details')
@section('content')
    <!-- Content Header (Page header) -->
       <section class="content-header">
      <h1>
        Project Details Page
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{ url('/') }}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="{{ url('/project_list') }}">Project List</a></li>
        <li class="active">Project Details Page</li>
      </ol>
    </section>
 <section class="content">
      <div class="row">
        <!-- left column -->
			@foreach (['danger', 'warning', 'success', 'info'] as $key)
			 @if(Session::has($key))
			  <div class="alert alert-{{ $key }} alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				<strong>{{ Session::get($key) }}</strong>
				</div>
				@endif
			 @endforeach
         <section class="invoice">
      <!-- title row -->
      @if(!empty($project_data))
      <div class="row">
          <h2 class="page-header">
            <i class="fa fa-th-large"></i> &nbsp;{{$project_data['Name']}}
            
             <div class="pull-right">
			@if(!empty(Session::get('userdetails.role')=='2'))
				 <div class="btn-group">
					<button type="button" class="btn btn-success" data-toggle="modal" data-target="#assignprojectModal1">
						Assign User
					</button>
				</div>
				<div class="btn-group">
					<button type="button" class="btn btn-success" data-toggle="modal" data-target="#addtaskModal1">
						Add Task
					</button>
				</div>
			 @endif	
                </div>
                <br><br>
             
          </h2>
      </div>
      <!-- info row -->
      <div class="row invoice-info">
        <div class="col-sm-9 invoice-col">
		  <div class="project-desc">
          <strong>Description : </strong><br> 
				 {{$project_data['desc']}}
		  </div> 
		  <br>
		  <div class="Task-Status">
					 @if(!empty(Session::get('userdetails.role')=='1') || !empty(Session::get('userdetails.role')=='2'))
					 <?php if(!empty($project_data['tasks'])){?>
						<strong>Task Status Count: </strong><br> 
						<?php
						$taskstatus=array();
						foreach($project_data['tasks'] as $task){
							if($task['isTicket']!='1'){
							$taskstatus[]=$task['state'];
							}
						}
						$counts = array_count_values($taskstatus);
						$total='';
							foreach($counts as $count){
									$total+=$count;
							}?>
					<address class="task-count-section">
						<?php if(!empty($counts['1'])){?>
						<span class="badge new-label">New <span id="new-count">({{$counts['1']}})</span></span>
						<?php }if(!empty($counts['2'])){?>
						<span class="badge inprogress-label">InProgress <span id="inprogress-count">({{$counts['2']}})</span></span>
						<?php }if(!empty($counts['3'])){?>
						<span class="badge delayed-label">Deloyed <span id="delayed-count">({{$counts['3']}})</span></span>
						<?php }if(!empty($counts['4'])){?>
						<span class="badge closed-label">Closed <span id="closed-count">({{$counts['4']}})</span></span>
						<?php }if(!empty($counts['5'])){?>
						<span class="badge deleted-label">Deleted <span id="deleted-count">({{$counts['5']}})</span></span>
						<?php }if(!empty($total)){?>
						<span class="badge total-label">Total <span id="total-count">({{$total}})</span></span>
						<?php }
						}?>
					</address>
					@endif
					<!-- Associate Task Status Count -->
					@if(!empty(Session::get('userdetails.role')=='3'))
					@if(!empty($task_listdetail))
					<strong>Task Status Count: </strong><br> 
					<?php $taskstatus=array();?>
					@foreach($task_listdetail as $index => $task)
					@if($task['result']['isTicket']!='1')
					<?php $profile_id = Session::get('userdetails.id');?>
					<?php if(!empty($task['result']['assignedTo'])){
						$assignid=array();
						foreach($task['result']['assignedTo'] as $index => $assign){
						$assignid[]=$assign['profileId'];
						if($assign['profileId']==$profile_id){
								$taskstatus[]=$task['result']['state'];
								}
								}
								}?>
				    @endif
					@endforeach
					<?php $counts = array_count_values($taskstatus);
					$total='';
					foreach($counts as $count){
							$total+=$count;
					}
					?>
					@endif	
								<address class="task-count-section">
								<?php if(!empty($counts['1'])){?>
								<span class="badge new-label">New <span id="new-count">({{$counts['1']}})</span></span>
								<?php }if(!empty($counts['2'])){?>
								<span class="badge inprogress-label">InProgress <span id="inprogress-count">({{$counts['2']}})</span></span>
								<?php }if(!empty($counts['3'])){?>
								<span class="badge delayed-label">Deloyed <span id="delayed-count">({{$counts['3']}})</span></span>
								<?php }if(!empty($counts['4'])){?>
								<span class="badge closed-label">Closed <span id="closed-count">({{$counts['4']}})</span></span>
								<?php }if(!empty($counts['5'])){?>
								<span class="badge deleted-label">Deleted <span id="deleted-count">({{$counts['5']}})</span></span>
								<?php }if(!empty($total)){?>
								<span class="badge total-label">Total <span id="total-count">({{$total}})</span></span>
								<?php }?>
								</address>
						@endif
					<!-- Associate Task Status Count -->
		  </div>	 
        </div>
        <!-- /.col -->
        
        <!-- /.col -->
        <div class="col-sm-3 invoice-col">
		 <address class="project-date-section">
           <b>Start Date :</b> <input type="hidden" id="project_startdate" value="{{ date('Y,m,d', strtotime($project_data['startDate']))}}"/>{{ date('d-m-Y', strtotime($project_data['startDate']))}}<br>
           <b>End Date :</b>  <input type="hidden" id="project_enddate" value="{{ date('Y,m,d', strtotime($project_data['endDate']))}}">{{ date('d-m-Y', strtotime($project_data['endDate']))}}<br>
           <b>Created Date :</b>  {{ date('d-m-Y', strtotime($project_data['createdAt']))}}<br>
          <b>Last Update :</b>  {{ date('d-m-Y', strtotime($project_data['updatedAt']))}}
         </address>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- Table row -->
		<div class="row table-responsive">
			  <div class="card">
				<ul class="nav nav-tabs" role="tablist">
					<li role="presentation" class="active"><a href="#projecttask" aria-controls="projecttask" role="tab" data-toggle="tab">Project Task List</a></li>
					@if(!empty(Session::get('userdetails.role')=='2'))
					<li role="presentation"><a href="#projectassign" aria-controls="projectassign" role="tab" data-toggle="tab">Project Assigned User</a></li>
					@endif
					@if(!empty(Session::get('userdetails.role')=='3'))
					<li role="presentation"><a href="#projectticket" aria-controls="projectticket" role="tab" data-toggle="tab">Project Ticket List</a></li>
					@endif
				</ul>

				<!-- Tab panes Start-->
				<div class="tab-content">
					<div role="tabpanel" class="tab-pane active" id="projecttask">
						<br/>
						@if(!empty(Session::get('userdetails.role')=='1') || !empty(Session::get('userdetails.role')=='2'))
						  <table class="table table-bordered" id="task_datatable">
							<thead>
								<tr>
								  <th>Sno</th>
								  <th>Task</th>
								  <th>Start Date</th>
								  <th>End Date</th>
								  <th>Assignee</th>
								  <th>Status</th>
								  @if(!empty(Session::get('userdetails.role')=='2'))
								  <th>Action</th>
								  @endif
								</tr>
							</thead>
							<tbody>
							@if(!empty($task_listdetail))
							<?php $i=0;?>
							@foreach($task_listdetail as $index => $task)
							@if($task['result']['isTicket']!='1')
							<?php $id=$task['result']['id'];?>
							@if(!empty(Session::get('userdetails.role')=='1') || !empty(Session::get('userdetails.role')=='2'))
							<?php $i++;?>
								<tr>
									  <td>{{$i}}</td>
									  @if(!empty(Session::get('userdetails.role')=='2'))
									  <td><a href="<?php echo "/taskdetails/".$id;?>">{{$task['result']['name']}}</a></td>
									  @else
									  <td>{{$task['result']['name']}}</td>
									  @endif
									  <td>{{ date('d-m-Y', strtotime($task['result']['startDate']))}}</td>
									  <td>{{ date('d-m-Y', strtotime($task['result']['endDate']))}}</td>	
									  <td>@if(!empty($task['result']['assignedTo']))
										  @php
										  $assignusers=array();
										  @endphp
										  @foreach($task['result']['assignedTo'] as $index => $assign)
											  @php
												$assignusers[]=TaskManageController::getAssignName($assign['profileId']);
											  @endphp 
										  @endforeach
										  @php
											   $assignusers=array_filter($assignusers)
										  @endphp
										  @if(!empty($assignusers))
										  @php
											echo implode(",", $assignusers);
										  @endphp
										  @endif
										@else
										 No Assignee
										@endif
										</td>
									  <td>
										<?php if(!empty($task['result']['state'])){?>
										<?php $todaydate=date("m-d-Y");?>
										<?php if(date('m-d-Y', strtotime($task['result']['startDate'])) <= $todaydate){
												if($task['result']['state']=='1'){
												$task['result']['state']='2';?>
												<span class="col-md-2 badge label_<?php echo HelperController::gettaskStatus($task['result']['state'])?>">
												
													<?php $loggedInUserId=Session::get('user_id'); 
														  $taskid=$task['result']['id'];
														  $task_name=$task['result']['name'];
														  $task_status=$task['result']['state'];
													if(!empty($loggedInUserId) && !empty($taskid) && !empty($task_name) && !empty($task_status)){	  
													  $statusid=HelperController::UpdateTaskStatus($loggedInUserId,$taskid,$task_name,$task_status);
													  if(!empty($statusid['state'])){
														  $task['result']['state']=$statusid['state'];
													  }
													}?>
													<?php echo HelperController::gettaskStatus($task['result']['state']);?>
													</span>
													<?php }else{?>
													<span class="col-md-2 badge label_<?php echo HelperController::gettaskStatus($task['result']['state'])?>">
														<?php echo HelperController::gettaskStatus($task['result']['state']);?>
													</span>
													<?php }
													}elseif(date('m-d-Y', strtotime($task['result']['endDate'])) == $todaydate){
													if($task['result']['state']!='3' || $task['result']['state']!='4'){
														$task['result']['state']='3';?>
													<span class="col-md-2 badge label_<?php echo HelperController::gettaskStatus($task['result']['state']) ?>">
													<?php $loggedInUserId=Session::get('user_id'); 
														  $taskid=$task['result']['id'];
														  $task_name=$task['result']['name'];
														  $task_status=$task['result']['state'];
														   if(!empty($loggedInUserId) && !empty($taskid) && !empty($task_name) && !empty($task_status)){	  
														   $statusid=HelperController::UpdateTaskStatus($loggedInUserId,$taskid,$task_name,$task_status);
															  if(!empty($statusid['state'])){
																  $list['state']=$statusid['state'];
															  }
															}?>
															<?php echo HelperController::gettaskStatus($task['result']['state']);?>
														</span>
													<?php }else{?>
													<span class="col-md-2 badge label_<?php echo HelperController::gettaskStatus($task['result']['state'])?>">
														<?php echo HelperController::gettaskStatus($task['result']['state']);?>
													</span>
													<?php }
													}else{?>
													<span class="col-md-2 badge label_<?php echo HelperController::gettaskStatus($task['result']['state'])?>">
													<?php echo HelperController::gettaskStatus($task['result']['state']);?>
													</span>
													<?php }?>
													<?php }?>
									   </td>
									    @if(!empty(Session::get('userdetails.role')=='2'))
									   <td><span class="edit" data-toggle="modal" title="edit" data-target="<?php echo "#updatetaskmodal".$task['result']['id'];?>"><i class="fa fa-fw fa-edit"></i></span></td>
									   @endif
							</tr>
							<!-- Task Edit Modal Include start -->
							@include('project.project_details_taskedit_modal')
							<!-- Task Edit Modal Include end -->
							@endif
							@endif
							@endforeach
							@endif					
							</tbody>
							</table>
						   @endif
							<!-- AssociateWise Project Task Details Start -->
							@if(!empty(Session::get('userdetails.role')=='3'))
							 <table class="table table-bordered" id="task_datatable">
								<thead>
									<tr>
									  <th>Sno</th>
									  <th>Task</th>
									  <th>Start Date</th>
									  <th>End Date</th>
									  <th>Assignee</th>
									  <th>Status</th>
									 @if(!empty(Session::get('userdetails.role')=='2'))
									  <th>Action</th>
									 @endif
									</tr>
								</thead>
								<tbody>
								@if(!empty($task_listdetail))
								<?php $i=0;?>
								@foreach($task_listdetail as $index => $task)
								@if($task['result']['isTicket']!='1')
								<?php $id=$task['result']['id'];?>
								<?php $profile_id = Session::get('userdetails.id');?>
								<?php if(!empty($task['result']['assignedTo'])){
									$assignid=array();
									foreach($task['result']['assignedTo'] as $index => $assign){
									$assignid[]=$assign['profileId'];
									if($assign['profileId']==$profile_id){ 
										$i++;?>
									  <tr>
										  <td>{{$i}}</td>
										  <td><a href="<?php echo "/taskdetails/".$id;?>">{{$task['result']['name']}}</a></td>
										  <td>{{ date('d-m-Y', strtotime($task['result']['startDate']))}}</td>
										  <td>{{ date('d-m-Y', strtotime($task['result']['endDate']))}}</td>	
										  <td>@if(!empty($task['result']['assignedTo']))
											  @php
											  $assignusers=array();
											  @endphp
											  @foreach($task['result']['assignedTo'] as $index => $assign)
												  @php
													$assignusers[]=TaskManageController::getAssignName($assign['profileId']);
												  @endphp 
											  @endforeach
											  @php
											   $assignusers=array_filter($assignusers)
											  @endphp
											  @if(!empty($assignusers))
											  @php
												echo implode(",", $assignusers);
											  @endphp
											  @endif
											@else
											 No Assignee
											@endif
											</td>
										  <td>
											 @if(!empty($task['result']['state']))
											 <span class="col-md-2 badge label_<?php echo HelperController::gettaskStatus($task['result']['state'])?>">
											 @php
												 echo HelperController::gettaskStatus($task['result']['state']);
											 @endphp
											 </span>
											 @endif
										   </td>
										</tr>
									<?php }
									}
									}
									?>
									@endif
									@endforeach
									@endif
									  
								</tbody>
							  </table>
							 @endif
							  <!-- AssociateWise  Project Task Details End -->
					</div>
					<!--  Project Assigned User Tab Content Start -->
					<div role="tabpanel" class="tab-pane" id="projectassign">
					  @if(!empty(Session::get('userdetails.role')=='2'))
										<br/>
								<table class="table table-bordered" id="projectuser_datatable">
										<thead>
										<tr>
										  <th>Sno</th>
										  <th>Assign Name</th>
										  <th>Email Address</th>
										  <th>Designation</th>
										  <th>Actions</th>
										</tr>
										</thead>
										<tbody>
										@if(!empty($project_user))
										@foreach($project_user as $index => $user)
										<tr>
										  <td>{{$index+1}}</td>
										  <td>{{$user['profileId']['name']}}</td>
										  <td>{{$user['profileId']['email']}}</td>
										  <td>{{$user['profileId']['designation']}}</td>
										  <td><center><a href="<?php echo "/removememberfromproject/".$user['id'].'/'.$project_data['id'];?>"  class="delete" Onclick="return ConfirmDelete();"><i class="fa fa-fw fa-trash"></i></center></a></td>
										</tr>
										@endforeach
										@endif
										</tbody>
									  </table>
								  @endif 
								</div>
						<!--  Project Assigned User Tab Content End -->
					 <!-- Project Ticket Details Start -->
					 <div role="tabpanel" class="tab-pane" id="projectticket">
						 <br/>
						 @if(!empty(Session::get('userdetails.role')=='3'))
							 <table class="table table-bordered" id="ticket_datatable">
								<thead>
									<tr>
									  <th>Sno</th>
									  <th>Ticket</th>
									  <th>Start Date</th>
									  <th>End Date</th>
									  <th>Assignee</th>
									  <th>Status</th>
									</tr>
								</thead>
								<tbody>
								@if(!empty($task_listdetail))
								<?php $i=0;?>
								@foreach($task_listdetail as $index => $task)
								@if($task['result']['isTicket']=='1')
								<?php $id=$task['result']['id'];?>
								<?php $profile_id = Session::get('userdetails.id');?>
								<?php if(!empty($task['result']['assignedTo'])){
									$assignid=array();
									foreach($task['result']['assignedTo'] as $index => $assign){
									$assignid[]=$assign['profileId'];
									if($assign['profileId']==$profile_id){ 
										$i++;?>
									  <tr>
										  <td>{{$i}}</td>
										  <td>{{$task['result']['name']}}</td>
										  <td>{{ date('d-m-Y', strtotime($task['result']['startDate']))}}</td>
										  <td>{{ date('d-m-Y', strtotime($task['result']['endDate']))}}</td>	
										  <td>@if(!empty($task['result']['assignedTo']))
											  @php
											  $assignusers=array();
											  @endphp
											  @foreach($task['result']['assignedTo'] as $index => $assign)
												  @php
													$assignusers[]=TaskManageController::getAssignName($assign['profileId']);
												  @endphp 
											  @endforeach
											  @php
											   $assignusers=array_filter($assignusers)
											  @endphp
											  @if(!empty($assignusers))
											  @php
												echo implode(",", $assignusers);
											  @endphp
											  @endif
											@else
											 No Assignee
											@endif
											</td>
										  <td>
											 @if(!empty($task['result']['state']))
											 <span class="col-md-2 badge label_<?php echo HelperController::gettaskStatus($task['result']['state'])?>">
											 @php
												 echo HelperController::gettaskStatus($task['result']['state']);
											 @endphp
											 </span>
											 @endif
										   </td>
										</tr>
									<?php }
									}
									}
									?>
									@endif
									@endforeach
									@endif
									  
								</tbody>
							  </table>
							 @endif
					 </div>
					 <!-- Project Ticket Details End -->	
					 	</div> 
					</div>
				<!-- Tab panes End-->
						</div>
					</div>
				</section>
			</div>
			</section>
      @else
			<span class="red">Currently don't have project details.</span>
      @endif

                  <!-- Modal Add Task -->
						@include('project.project_details_taskcreate_modal')
				  <!-- Modal Assign Project -->
						@include('project.project_details_add_assignee_modal')
	            
     </section>
@endsection
